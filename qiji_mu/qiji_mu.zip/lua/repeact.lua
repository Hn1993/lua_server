require("TSLib") -- 导入TS LIB库
require("qiji_config_data") -- 导入TS LIB库

-- 循环练级 刷金
function do_repect(...)
	x,y = findMultiColorInRegionFuzzy( 0x97d9f1, "0|21|0xf1f9ff,-11|10|0xc2eafa,11|10|0xc2e7f8,0|12|0xccedf5", 90, 3, 64, 384, 533)
	if x >-1 then --识别创建角色的 + 号
		randomTap(x,y);
		mSleep(5000);
		randomTap(1156,26);--点击跳过动画
		mSleep(2000);
		x,y = findMultiColorInRegionFuzzy( 0x7d7575, "47|0|0xb2783e,105|-17|0xf7f5ed,105|-11|0xece8d8,105|-7|0xe6e1cc,105|-4|0xe1dcc2,126|-4|0xe1dcc3,126|-9|0xeae6d4,151|-13|0xf1efe3", 90, 955, 606, 1260, 703)
		if x > -1 then --识别创建角色
			index = math.random(1,4);
			if index == 1 then
				randomTap(  127,  128);
			elseif index == 2 then
				--randomTap(  154,  243);
				randomTap(  127,  128);
			elseif index == 3 then
				--randomTap(  187,  362);
				randomTap(  127,  128);
			elseif index == 4 then
				--randomTap(  169,  479);
				randomTap(  127,  128);
			end	
			mSleep(3000);
			randomTap(1156,26);--点击跳过动画
			mSleep(3000);
			randomTap(1156,26);--点击跳过动画
			
			randomTap(x,y);
			mSleep(2000);
		end	
	else -- 所有角色都已经创号
		
		str = baidu_ai_text(140, 113, 224, 147); --第一个号的级别位置  判断第一个号有没有等级，没有的话就从第一个开始
		if str == nil or tonumber(str) == nil then
			randomTap(140,113);-- 点击角色1
			insert_into_table("selected_account",1);
			mSleep(2000);
			randomTap(1120,650);-- 点击开始游戏
			mSleep(2000);
			return;
		end
		
		if find_value_from_table('account_1') == nil or find_value_from_table('account_1') == false then
			str = baidu_ai_text(140, 113, 224, 147); --第一个号的级别位置
			if str ~= nil and tonumber(str) ~= nil and tonumber(str) >= 160 then --第一个号的等级 到了160级
				insert_into_table("is_level_160",true);
			else
				insert_into_table("is_level_160",false);
			end	
			randomTap(140,113);-- 点击角色1
			insert_into_table("selected_account",1);
			mSleep(2000);
			randomTap(1120,650);-- 点击开始游戏
			mSleep(2000);
			return;
		end	
		
		if find_value_from_table('account_2') == nil or find_value_from_table('account_2') == false then
			str = baidu_ai_text(185, 223, 272, 257);--第2个号的级别位置
			if str ~= nil and tonumber(str) ~= nil and tonumber(str) >= 160 then --第2个号的等级 到了160级
				insert_into_table("is_level_160",true);
			else
				insert_into_table("is_level_160",false);
			end	
			randomTap(185,223);-- 点击角色2
			insert_into_table("selected_account",2);
			mSleep(2000);
			randomTap(1120,650);-- 点击开始游戏
			mSleep(2000);
			return;
		end	
		
		if find_value_from_table('account_3') == nil or find_value_from_table('account_3') == false then
			str = baidu_ai_text(204, 340, 295, 371);--第3个号的级别位置
			if str ~= nil and tonumber(str) ~= nil and tonumber(str) >= 160 then --第3个号的等级 到了160级
				insert_into_table("is_level_160",true);
			else
				insert_into_table("is_level_160",false);
			end	
			randomTap(204,340);-- 点击角色3
			insert_into_table("selected_account",3);
			mSleep(2000);
			randomTap(1120,650);-- 点击开始游戏
			mSleep(2000);
			return;
		end	
		
		if find_value_from_table('account_4') == nil or find_value_from_table('account_4') == false then
			str = baidu_ai_text(183, 458, 275, 492);--第4个号的级别位置
			if str ~= nil and tonumber(str) ~= nil and tonumber(str) >= 160 then --第3个号的等级 到了160级
				insert_into_table("is_level_160",true);
			else
				insert_into_table("is_level_160",false);
			end	
			randomTap(183,458);-- 点击角色4
			insert_into_table("selected_account",4);
			mSleep(2000);
			randomTap(1120,650);-- 点击开始游戏
			mSleep(2000);
			return;
		end	
		
		
	end	
end

function baidu_ai_text(x1,y1,x2,y2)
	local code,access_token = getAccessToken("HAeaib82Z3RcmWLEdRIesiRt","fepjE9oUA0wcecPwfNpmYCp108Hjt6C6");
	if code then
		-- 设置图片保存路径
		local pic_name = userPath() .. "/res/baidu_ai_level.jpg"
		-- 截取识别区域
		snapshot(pic_name,x1,y1,x2,y2);
		-- 请求百度 AI 进行文字识别
		local code, body = baiduAI(access_token,pic_name);
		if code then
			length = string.len(tostring(body)); 
			str = string.sub(tostring(body),length-9,length-7);
			nLog("str="..tostring(str))
			return str;
		else
			return nil;
		end
	end	
end

