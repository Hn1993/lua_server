require("TSLib") -- 导入TS LIB库
require("quanli_page") -- 导入TS LIB库
require("quanli_config_data")
require("hongdian")
require("quanli_logic")
init(1); -- 代表横屏

function Split(szFullString, szSeparator)  
	local nFindStartIndex = 1  
	local nSplitIndex = 1  
	local nSplitArray = {}  
	while true do  
		local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)  
		if not nFindLastIndex then  
			nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))  
			break  
		end  
		nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)  
		nFindStartIndex = nFindLastIndex + string.len(szSeparator)  
		nSplitIndex = nSplitIndex + 1  
	end  
	return nSplitArray  
end



function build_soldier_task(...)
	while (true) do
		x,y = findMultiColorInRegionFuzzy( 0xfbfbfb, "0|5|0xfbfbfb,1|11|0xf3f3f3,7|4|0xf5f5f5,13|14|0xfbfbfb,35|-4|0xfafafa,26|14|0xf9f9f9", 90, 87, 41, 163, 94)
		nLog("兵营训练页-x="..x)
		if x > -1 then

			--x,y = findMultiColorInRegionFuzzy( ", 90, 1110, 203, 1196, 241)
			text = ocrText(1110, 203, 1196, 241, 0)
			nLog("text-x="..text)
			if string.len(text) >= 6 then 
				list = Split(text,",");
				nLog("list="..list[1])
				if list[1] > 24 then
					nLog("大于24")
					break;
				else

				end

			end

			while (true) do
				if isColor(  976,  691, 0xfc4646 )  == false or isColor( 1199,  670, 0x3d7140) then
					mSleep(2000);
					tap_and_sleep(    706,  366); --点击轻步兵
					tap_and_sleep(    706,  366); --点击轻步兵
					mSleep(2000);
					--tap_and_sleep(  1142,  680); --点击训练	
					tap_and_sleep(  1142,  680); --点击训练	
				else
					tap_and_sleep(  1214,  691);--点击加速
				end

				x,y = findMultiColorInRegionFuzzy( 0xb16b13, "-45|72|0x99312c,1|54|0x4d7b45,70|72|0x417596,16|70|0x4d7c44,-45|92|0x99312c", 90, 20, 100, 206, 258)
				nLog("兵营-训练x="..x);
				if x > -1 then
					x,y = findMultiColorInRegionFuzzy( 0xecca97, "11|-10|0xe3c384,11|24|0xfffdbb,29|7|0xf1e2a1,1|16|0xfcf6b1", 90, 805, 548, 899, 614)
					nLog("造兵的材料不够-x="..x)
					if x > -1 then
						tap_and_sleep( 1157,  682);--点击训练
					else
						break
					end

				end

				x,y = findMultiColorInRegionFuzzy( 0xbba780, "-1|8|0xc2ae85,0|6|0xc1ad84,-212|318|0x735a3c,-212|359|0xa48b59,-12|320|0x755c3c,309|321|0x995b34,62|11|0xb8a67f", 90, 290, 176, 995, 636)
				nLog("提示消息对话框-x="..x)
				if x > -1 then
					tap_and_sleep(  482,  556);--点击加速当前队列
				end

				x,y = findMultiColorInRegionFuzzy( 0xf3e29e, "12|8|0xddc58d,3|8|0x9b7a4b,0|36|0x775644,24|17|0xad8f66,38|16|0xaf8e69,18|2|0xe3c98d,19|32|0x7c614a", 90, 158, 301, 232, 384)
				nLog("一件加速-x="..x);
				if x > -1 then
					tap_and_sleep( 1023,  337);--点击一键加速
					mSleep(1000);
					tap_and_sleep(  778,  620);--点击确定
					mSleep(1000);
					tap_and_sleep(1150,120);--点击关闭
					mSleep(1000);
					tap_and_sleep(1240,70);--点击关闭
				else
					
				end


			end

		end	
	end
	
end
