require("TSLib") -- 导入TS LIB库
require("quanli_logic")
require("quanli_config_data")
require("hongdian2")

init(1); -- 代表横屏

--moveZoomIn(  403,  469,    537,  391); --放大

--x,y = findMultiColorInRegionFuzzy( 0xaa5947, "78|-24|0xb35e4d,20|40|0x506271,-34|73|0x8e4e3a,85|9|0xffffef,-15|57|0xddbaa3", 90, 377, 450, 596, 626)
--nLog("兵营-x="..x)
--insert_into_table("is_level_6",true);
--game_start();

x,y = findMultiColorInRegionFuzzy( 0x447699, "-67|-19|0x4d7b45,-62|-128|0xfefefe,-57|-119|0xfafafa,-41|-136|0xf8f8f8,-35|-136|0xfafafa,-43|-118|0xf5f5f5,900|-128|0x67bde1,-69|-71|0xb06b13,-124|5|0x99312c", 90, 2, 37, 1142, 251)
nLog("兵营训练页-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xb5b6b6, "10|-2|0xa8aaad,40|-6|0xa7a8a8,39|1|0x888a8b,50|-3|0xadadaf,51|-4|0xabacad,59|-3|0xb3b4b5,71|-5|0xb3b4b5,97|2|0x87898b", 90, 631, 386, 759, 423)
nLog("护盾-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xcaaf82, "15|-15|0xd2ba8d,9|0|0xc0a678,13|-23|0xddcc9a,-15|20|0xb49d70,46|-33|0xb92515,23|-34|0xb72513", 90, 816, 656, 904, 748)
nLog("邮件-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xda9728, "5|-11|0xde982b,37|-14|0xdd8c20,86|-13|0xeb8121,87|8|0xdf761a", 90, 185, 149, 1172, 218)
toast("品质提升-x="..x,1)
nLog("品质提升-x")


--[[text = ocrText(656, 124, 708, 176, 0)
nLog("text-x="..text)

text3 = ocrText(70, 459, 85, 473,0)
nLog("text3-x="..text3)

text2 = ocrText(68, 542, 85, 555,0)
nLog("text2-x="..text2)
]]

insert_into_table("guide_finished",true);

while (true) do
	now_time = getNetTime();
	now_time_hh = os.date("%H",time);--时
	now_time_mm = os.date("%M",time);--分

	if now_time_hh == 00 and now_time_mm == 10 then --12点 10分
		insert_into_table("qishen",false);
	end	
	
	--[[if find_value_from_table('is_level_6') ~= nil and find_value_from_table('is_level_6') == true then
		game_start()
		mSleep(1000); 
	else
		upgrade_6_level();
	end]]

	upgrade_6_level();
	
end




x,y = findMultiColorInRegionFuzzy( 0x74593d, "200|3|0x765c3f,202|41|0xa18a57,0|37|0xa68b59,678|-4|0x73593c,719|-3|0x74593c,714|34|0xae915e,590|16|0x52ce56,553|17|0x51ca55", 90, 99, 625, 986, 740)
nLog("建兵-x="..x)


choice = dialogRet("清空配置文件：", "确定", "取消", "", 0);
if choice == 0 then      --取消
 dialog("确定",0);
 mSleep(1000);
elseif choice == 1 then  --男
 dialog("取消",0);
 mSleep(1000);
end


fwShowWnd("wid",100,100,500,500,1);
--fwShowTextView("wid","textid","这是一个文本视图","center","FF0000","FFDAB9",20,0,0,0,200,100,0.5);
fwShowButton("wid","button_id","清空配置文件","647087","9a5241" ,userPath().."/res/guide_finger_0.jpg",25,150,150,300,300);
--显示一个文字视图
mSleep(5000);

x,y = findMultiColorInRegionFuzzy( 0xac5a43, "40|-2|0xa55a44,74|-25|0xc46c4c,84|-27|0xb35f4e,-38|78|0x8c4e3c,76|5|0xa8c2f3", 90, 327, 464, 623, 674)
nLog("兵营-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xf5cb41, "144|5|0xf9d35a,-145|-196|0xc64037,289|-224|0xc43f36,423|-320|0xdebc8a,-474|-121|0x82582c,335|24|0x7a5227", 90, 206, 134, 1174, 660)
nLog("邀请好友-x="..x)

text = ocrText(702, 357, 796, 389, 0)
nLog("text="..text)
if string.len(text) >= 5 then
	nLog("大于1W")
end



--[[moveZoomIn(  403,  469,    537,  391); --放大
tap(  469,  511); --点击兵营
tap(  878,  392); --点击轻骑兵
tap(  1142,  680); --点击训练
tap(  1242,   70); --点击关闭
]]

--[[while (true) do
	x,y = findMultiColorInRegionFuzzy( 0xa38a5e, "-47|-27|0xe6cd9f,-26|-40|0xe6d0a0,-13|-22|0x1a232e,11|-16|0x1b242e,-21|7|0xaa9063,-47|0|0xc4ab81", 90, 3, 629, 138, 758)
    nLog("回城-x="..x)
	tap(x,y)
	mSleep(3000);
	
	x,y = findMultiColorInRegionFuzzy( 0xc7b284, "-4|-11|0xd8c293,30|-5|0x11191a,14|-7|0xcfbe92,23|16|0xb69a6d,24|-9|0xd7bf90,-16|-9|0x162026", 90, 2, 621, 125, 753)
	nLog("出城-x="..x)
	tap(x,y)
	mSleep(3000);
end]]





x,y = findMultiColorInRegionFuzzy( 0x303a49, "3|134|0x283849,848|133|0x283749,848|133|0x283749,506|49|0x56d25b,496|50|0x5fe963,528|57|0x5de462,547|50|0x5de962", 90, 47, 403, 994, 636)
nLog("侦查敌情-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xffeea0, "342|2|0xdab275,115|332|0xb6a37b,136|332|0xb7a37c,183|335|0xc0ac85,183|331|0xb7a47d,183|327|0xb4a27c", 90, 270, 67, 954, 768)
nLog("升级对话框-x="..x)

x,y = findMultiColorInRegionFuzzy( 0x2f3a49, "818|2|0x303a49,818|140|0x293849,-36|103|0x2c3849,416|81|0x5be160,448|88|0x5feb64,449|80|0x5ce25f,464|93|0x5adf5f", 90, 48, 426, 1018, 629)
nLog("加速训练-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xe7c98a, "-26|11|0xedd291,27|12|0xf0cf90,-7|41|0xffffb7,1|66|0xffffe7", 90, 634, 404, 1278, 745)
nLog("手势操作2-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xffffd1, "-1|35|0xfff9ae,-5|73|0xe5ca8c,8|71|0xe7ca8e,-27|67|0xeecc8d,25|71|0xedcc89", 90, 630, 112, 1268, 763)
nLog("手势操作-x="..x)

x,y = findMultiColorInRegionFuzzy( 0x303a49, "0|135|0x283849,847|137|0x283749,849|2|0x303a49,710|70|0x51c956,711|78|0x5adf5e,745|72|0x5ce360,765|68|0x5be160", 90, 80, 422, 995, 627)
nLog("训练士兵")

x,y = findMultiColorInRegionFuzzy( 0xfff8c7, "-16|-15|0xfef5c4,-57|-57|0xe4c98a,-73|-50|0xdfc582,-46|-32|0xf8db99,-27|-49|0xf8dc9a", 90, 1027, 145, 1262, 538)
nLog("手势-x="..x)


x,y = findMultiColorInRegionFuzzy( 0xc4b086, "11|7|0xc5b087,10|17|0xc1ac84,-1|17|0xc5b086,32|2|0xc1ad85,38|17|0xbda981,-509|-16|0x2c2f34,529|1|0xceaf81,548|580|0x27272f", 90, 87, 63, 1185, 721)
nLog("公告-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xc0ac84, "34|-9|0xc5b087,58|-9|0xc3ae85,87|2|0xbeab83,-29|326|0x876b48,131|329|0x8a6f48,0|3|0xc1ad84", 90, 289, 170, 999, 636)
nLog("实名认证-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xfef3d1, "0|7|0xfdf2cc,6|4|0xfdf2cf,43|-4|0xf5edd3,68|-3|0xf6eecd,68|3|0xfaedcb,97|1|0xd8d0b6,142|-3|0xd4ccb1,177|-2|0xf3ebc9", 90, 1025, 8, 1258, 81)
nLog("点击此处跳过-x="..x)

--snapshot(userPath() .. "/res/jump_down.jpg", 1171, 667, 1238, 757)

x,y = findMultiColorInRegionFuzzy( 0xc7b38c, "28|0|0xc5b088,14|0|0xc6b38a,15|14|0xc6b38a", 90, 1176, 677, 1234, 758)
nLog("下三角-x="..x)
	
x,y = findMultiColorInRegionFuzzy( 0x3e5065, "6|-45|0x5e6f82,165|-41|0x445365,165|-9|0x3f5069,85|-29|0xe8e8e9,85|-24|0xe9e9ea,64|-30|0xe2e2e3", 90,290, 188, 1050, 629)
nLog("请点击空地-x="..x)

x,y = findMultiColorInRegionFuzzy( 0x3c4f67, "7|-43|0x455365,169|-42|0x455365,169|-7|0x405069,16|-9|0x3f5069,47|-31|0xe4e4e5,44|-29|0xb1b3b4,44|-19|0xd7d7d8,50|-27|0xbfc0c1",90, 396, 563, 749, 759)
nLog("免费建造-x="..x);

x,y = findMultiColorInRegionFuzzy( 0x465667, "2|38|0x405069,90|48|0x3c4f69,180|3|0x455365,177|37|0x405069,40|13|0xe0e1e2,37|14|0xbcbdc0,43|13|0xbebfc1", 90, 1060, 191, 1279, 491)
nLog("请选择长弓兵-x="..x)

x,y = findMultiColorInRegionFuzzy( 0x415169, "-170|-39|0x455365,-11|-42|0x445365,-168|-9|0x405069,-47|-31|0xeeeeee,-45|-24|0xe1e1e2,-88|-26|0xb5b5b8", 90, 859, 542, 1271, 759)
nLog("请开始训练-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xe7cc8d, "42|-41|0xfffbca,58|-58|0xffffcc,37|-23|0xffefbb,-20|-10|0xe6c482", 90, 1051, 10, 1279, 203)
nLog("引导手势-x="..x)

x,y = findMultiColorInRegionFuzzy( 0x435166, "14|-21|0x455667,173|-18|0x445365,172|18|0x3f5069,16|18|0x3f5069,50|-7|0xbfc1c3,56|-8|0xb5b6b9,57|2|0xd9d9da", 90, 124, 639, 377, 740)
nLog("请点击出城-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xffffca, "-48|-41|0xe8cc8e,-39|-53|0xe6cb8c,-36|-27|0xfede98,-64|-49|0xe2c687,-19|-57|0xefcd96,-56|-19|0xeed494", 90, 854, 99, 1275, 517)
nLog("前往 引导-x="..x)

x,y = findMultiColorInRegionFuzzy( 0x3e4f67, "10|-44|0x455364,150|-45|0x455567,149|-8|0x3f5069,25|-7|0x405069,46|-32|0xdddede,46|-29|0xdadada,41|-24|0xc7c8c9,51|-24|0xd1d2d3", 90, 246, 173, 973, 659)
nLog("点击主堡-x ="..x)

x,y = findMultiColorInRegionFuzzy( 0x3d5067, "10|-42|0x445365,188|-39|0x455365,186|-6|0x405069,23|-7|0x405069,49|-29|0xe5e6e6,44|-24|0xe0e1e1", 90, 198, 571, 626, 752)
nLog("进入升级界面-x="..x)

x,y = findMultiColorInRegionFuzzy( 0x3d5067, "8|-42|0x455365,142|-40|0x455365,142|-5|0x3f5069,19|-6|0x3f5069,44|-30|0xe4e5e6,42|-21|0xbcbec0", 90, 17, 524, 665, 753)
nLog("点击升级-x="..x)

x,y = findMultiColorInRegionFuzzy( 0xfdfbca, "50|56|0xe7cb8c,50|43|0xedd394,29|66|0xefcd95,72|62|0xdec484,69|32|0xebd08f,28|17|0xfff0bd", 90, 1047, 628, 1238, 768)
nLog("右下角手势引导-x="..x)

x,y = findMultiColorInRegionFuzzy( 0x445367, "-157|-21|0x465767,-19|-19|0x455365,-17|20|0x3f5168,-154|16|0x405069,-116|-1|0xadafb2,-116|1|0xb5b6b9", 90, 882, 137, 1257, 523)
nLog("领取奖励-x="..x)

x,y = findMultiColorInRegionFuzzy( 0x2f3a49, "852|-8|0x303a49,852|135|0x2a3749,2|131|0x283849,497|77|0x5ee762,521|77|0x5de661,460|80|0x5be160,473|79|0x54d159", 90, 55, 408, 994, 628)
nLog("升级城墙-x="..x)
