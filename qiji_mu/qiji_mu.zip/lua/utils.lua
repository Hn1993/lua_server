require("TSLib") -- 导入TS LIB库
no_response_time = 0;
no_response_page = "";

--百度ocr文字识别  一天50000次
function baidu_text_ocr(x1,y1,x2,y2,content)
	local code,access_token = getAccessToken("HAeaib82Z3RcmWLEdRIesiRt","fepjE9oUA0wcecPwfNpmYCp108Hjt6C6");
	if code then
		-- 设置图片保存路径
		local pic_name = userPath() .. "/res/baiduAI.jpg"
		-- 截取识别区域
		snapshot(pic_name,x1,y1,x2,y2);
		-- 请求百度 AI 进行文字识别
		local code, body = baiduAI(access_token,pic_name);
		if code then
			if string.find(body,content) ~= nil then
				return true;
			end
		else
			return false;
		end
	else
		return false;
	end
end

--检测长时间无响应,游戏重进
function detect_no_response(page,time)
	if no_response_page == "" then
		no_response_page = page;
	end	
	
	if (no_response_time == 0) then
		no_response_time = time;
	end
	
	if no_response_page == page then
		if time - no_response_time >= 3 * 60   then
			-- 5分钟在同一界面
			nLog("检测长时间无响应")
			if no_response_page == "个人信息页" then
				randomTap(630,340);
				mSleep(1000);
			elseif no_response_page == "挂机试炼页"	then
				if isColor(965,737,0xab5c1e) == false then
					tap_and_sleep(965,737);--点击自动战斗
				end	
			end	
		end	
	else
		no_response_page = page;
		no_response_time = time;
	end
	nLog("page="..page);
	nLog("time="..time);
	nLog("no_response_time="..no_response_time);
	nLog("no_response_page="..no_response_page);
	nLog("time - no_response_time="..tostring((time - no_response_time)));

end