-- 游戏封装 本界面用于游戏逻辑
require("TSLib") -- 导入TS LIB库
require("qiji_page")
require("utils")
require("repeact")
is_today_clickd_experience = false;
is_today_hang_up_experience = false;
zhuxian_click_index = 0;
is_119_zhuanzhi = false;
ronglian_time = 0;
qianghua_time = 0;
qianghua_index = 0;
is_guaji_task_end = false;
is_jiaoyi_task_end = false;

function game_start(...)
	while (true) do
		-- body
		

		skip_boot();
		reward_dialog();
		center_dialog();
		center_big_dialog();
		activite_dialog();
		mSleep(3000);
		
		--insert_account_deal_info();
		page = get_page(page_list);
		detect_no_response(page,getNetTime());
		
		nLog("page="..page);
		if page == "游戏首页" then
			--nLog("find_value_from_table('selected_account')="..find_value_from_table('selected_account'))
			nLog("is_jiaoyi_task_end="..tostring(is_jiaoyi_task_end))
			nLog("is_guaji_task_end="..tostring(is_guaji_task_end))
			if find_value_from_table('selected_account') == nil then
				logout();
			end
			
			if is_jiaoyi_task_end == true then
				--如果选中的是第四个号 则去挂机
				if find_value_from_table('selected_account') ~= nil and find_value_from_table('selected_account') == 4 then
					
					tap_and_sleep(1200,70);
					tap_and_sleep(1200,70);
					count = math.random(1,5);
					if count == 1 then
						tap_and_sleep(1145,  358);
					elseif count == 2 then
						tap_and_sleep( 1141,  394);
					elseif count == 3 then
						tap_and_sleep(  1141,  434);	
					elseif count == 4 then
						tap_and_sleep(  1152,  473);	
					elseif count == 5 then
						tap_and_sleep(  1147,  510);		
					end
					tap_and_sleep(40,60);--点击返回
					
					while (true) do
						skip_boot();
						reward_dialog();
						center_dialog();
						center_big_dialog();
						activite_dialog();
						
						time = getNetTime();
						now_time_hh = os.date("%H",time);--时
						now_time_mm = os.date("%M",time);--分

						if tostring(now_time_hh) == "00" and tostring(now_time_mm) == "10" then --12点10 分，把所有的账号操作置为false
							insert_into_table("account_1",false);
							insert_into_table("account_2",false);
							insert_into_table("account_3",false);
							insert_into_table("account_4",false);
							break;
						end	
					end
					--insert_account_deal_info();--12.10分重置任务
				else
					logout();--换号
				end
				
			else
				if find_value_from_table('is_level_160') ~= nil and find_value_from_table('is_level_160') == true then
					--点击背包
					if getNetTime()-ronglian_time > 10 * 60 then
						--点击背包
						tap_and_sleep(871,749);--点击背包
						mSleep(2000);
					end

					if getNetTime()-qianghua_time > 16 * 60 then
						tap_and_sleep(40,60);--点击头像
						mSleep(2000);
					end

					--tap_and_sleep(活动);
					if is_guaji_task_end == true then --挂机任务结束 做交易任务
						--tap_and_sleep(40,60);--点击头像  换账号
						jiaoyi_task(); 
					else
						tap_and_sleep( 1073,   31);--点击活动
					end	
				else
					
					if is_today_hang_up_experience == true then
						logout();
						is_today_hang_up_experience = false;
						is_today_clickd_experience = false;
					end
					
					if ronglian_time == 0 then
						ronglian_time = getNetTime();
					end	

					if qianghua_time == 0 then
						qianghua_time = getNetTime();
					end	

					if getNetTime()-ronglian_time > 10 * 60 then
						--点击背包
						tap_and_sleep(871,749);--点击背包
					else
						do_task(getNetTime());
					end

					if getNetTime()-qianghua_time > 16 * 60 then
						tap_and_sleep(40,60);--点击头像
					else
						do_task(getNetTime());
					end	
					
					
				end
			end
			
			
			
			
		elseif page == "游戏解锁页" then
			touch():on(488,364):move(802,364):off();
		elseif page == "游戏副本页" then
			tap_and_sleep(332,370);--点击左边的目标
			
			if isColor(965,737,0xab5c1e) == false then
				tap_and_sleep(965,737);--点击自动战斗
			end	
			
			x,y = findMultiColorInRegionFuzzy( 0xffffb2, "1|0|0xffffb2,1|1|0xffffb0,0|2|0xffffae,-2|3|0xffffac,-3|3|0xffffac,-3|5|0xffffa9,-2|6|0xffffa7,-2|7|0xffffa6", 90, 1064, 84, 1136, 218)
			nLog("离开的光标-x="..x);
			if x > -1 then--是否有离开的光标
				tap_and_sleep(1100,40); --点击离开
			end	
		elseif page == "游戏副本页2" then
			tap_and_sleep(332,370);--点击左边的目标
		elseif page == "游戏活动页" then
			if find_value_from_table('is_level_160') ~= nil and find_value_from_table('is_level_160') == true then
				
				x,y = findMultiColorInRegionFuzzy( 0xb8c8d7, "0|8|0xc5cdd8,15|-3|0xf1f3f6,24|-3|0xf2f4f6,31|1|0xd1d9e1,56|-3|0xb9c2ce,60|8|0xb9c3ce,23|64|0xf7dd4f", 90, 171, 420, 507, 549)
				if x >-1 then --判断有没有刷金副本
					tap_and_sleep(x+240,y+70);--点击前往
					mSleep(3000);
				end
				
				
				x,y = findMultiColorInRegionFuzzy( 0xe6eaef, "1|0|0xe2e7ed,20|6|0xcfd6df,17|-2|0xf1f3f5,36|-1|0xe8ecf0,48|1|0xe4e8ed,22|47|0x19e055,21|77|0x0ddb35", 90, 508, 173, 836, 294)
				x1,y1 = findMultiColorInRegionFuzzy( 0xebeef2, "-5|11|0xb3c0ce,10|8|0xc7cfd9,19|7|0xcdd4dd,17|-1|0xeff2f4,35|0|0xe9ecf0,53|3|0xe0e4ea,48|2|0xe4e8ed,23|48|0x16e054", 90, 165, 151, 852, 420)
				if x > -1 or x1 >-1 then --判断有没有试炼之地
					if x > -1 then
						tap_and_sleep(x+240,y+70);--点击前往
					end	
					if x1 > -1 then
						tap_and_sleep(x1+240,y1+70);--点击前往
					end	
					--mSleep(0.5 * 60 * 60 * 1000)
				else
					tap_and_sleep(40,60);--点击返回
					--交易金币- 选择角色
					is_guaji_task_end = true;--做完挂机试炼任务	
				end		
			else
				tap_and_sleep(1045,685);--点击领取
				mSleep(2000);
				tap_and_sleep(1045,685);--点击空白页 关闭对话框
				mSleep(2000);
				tap_and_sleep(85,190);--点击活动
				mSleep(2000);
				x,y = findMultiColorInRegionFuzzy( 0xdbe2e9, "12|4|0xd2d9e1,32|7|0xbfc9d4,54|-2|0xedeff3,23|46|0x14de51,22|79|0x41f45a", 90, 172, 166, 506, 293)
				nLog("经验副本-x="..x..y);
				if x > -1 then --判断是不是经验副本
					tap_and_sleep(x+240,y+70);--点击前往
				else --没有了经验副本，代表做完了
					is_today_clickd_experience = true;
					x,y = findMultiColorInRegionFuzzy( 0xe6eaef, "1|0|0xe2e7ed,20|6|0xcfd6df,17|-2|0xf1f3f5,36|-1|0xe8ecf0,48|1|0xe4e8ed,22|47|0x19e055,21|77|0x0ddb35", 90, 508, 173, 836, 294)
					x1,y1 = findMultiColorInRegionFuzzy( 0xebeef2, "-5|11|0xb3c0ce,10|8|0xc7cfd9,19|7|0xcdd4dd,17|-1|0xeff2f4,35|0|0xe9ecf0,53|3|0xe0e4ea,48|2|0xe4e8ed,23|48|0x16e054", 90, 165, 151, 852, 420)
					if x > -1 or x1 >-1 then --判断有没有试炼之地
						if x > -1 then
							tap_and_sleep(x+240,y+70);--点击前往
						end	
						if x1 > -1 then
							tap_and_sleep(x1+240,y1+70);--点击前往
						end	
						--mSleep(0.5 * 60 * 60 * 1000)
					else
						is_today_hang_up_experience = true;
						tap_and_sleep(40,60);--点击返回
					end		
					
					--is_jiaoyi_task_end = true ;
				end	
		
			end
			
			
		elseif page == "游戏物资页" or page == "游戏物资页2" or page == "游戏物资页3" then
			do_game_goods();
			
			
		elseif page == "游戏物资_转职" or page == "游戏物资_转职2" then
			tap_and_sleep( 1179,  651);--点击转职
			tap_and_sleep(40,60);--点击返回
		elseif page == "游戏登录页" then
			tap_and_sleep(640,580);--点击登录游戏
		elseif page == "游戏商城页" then
			tap_and_sleep( 628,223);--红药水
			mSleep(1000);
			tap_and_sleep(803,581);--最大
			mSleep(1000)
			tap_and_sleep(683,680);--购买
			mSleep(1000)
			tap_and_sleep(683,680);--点击购买处关闭
			
			tap_and_sleep(1088,215);--蓝药水
			mSleep(1000);
			tap_and_sleep(803,581);--最大
			mSleep(1000)
			tap_and_sleep(683,680);--购买
			mSleep(1000)
			tap_and_sleep(683,680);--点击购买处关闭
			mSleep(1000);
			
			tap_and_sleep(40,60);--点击返回
			
		elseif page == "选择角色页" then
			do_repect();--根据内容选择

		elseif page == "个人信息页" then
			if qianghua_index % 2 == 0 then
				x,y = findMultiColorInRegionFuzzy( 0xff5f3b, "4|0|0xf7482b,4|-3|0xf8563a,-4|-3|0xff744f,-4|1|0xf64527,1|4|0xf93919", 90, 4, 156, 192, 238) --识别技能小红点
				if x > -1 then
					tap_and_sleep(x,y); --点击小红点						mSleep(1000);
					tap_and_sleep(79,311); --点击升级
					mSleep(1000);
					tap_and_sleep(79,311);

					for var= 1, 10 do
						--x,y = findMultiColorInRegionFuzzy( 0xff5f3b, "4|0|0xf7482b,4|-3|0xf8563a,-4|-3|0xff744f,-4|1|0xf64527,1|4|0xf93919", 90, 157, 94, 1275, 758)
						x,y = findMultiColorInRegionFuzzy( 0xf43d1e, "0|-7|0xff8e67,5|-7|0xfb5b40,7|-2|0xff4122,4|1|0xf83818,3|-3|0xff5a38,8|-3|0xff4323", 93, 264, 114, 1205, 733)
						if x > -1 then --找到内容里的小红点
							tap_and_sleep(x,y);
							mSleep(1000);
							tap_and_sleep(587,600);--点击一键升级
							mSleep(1000);
							tap_and_sleep(771,488);--点击确定
							mSleep(4000);
						else
							tap_and_sleep(40,60);
							qianghua_time = getNetTime();
							break;
						end	
					end	
						
				end
			else
				x,y = findMultiColorInRegionFuzzy( 0xff5f3b, "4|0|0xf7482b,4|-3|0xf8563a,-4|-3|0xff744f,-4|1|0xf64527,1|4|0xf93919", 90, 17, 253, 173, 345 ) --强化的小红点
				if x > -1 then
					tap_and_sleep(x,y); --点击小红点
					mSleep(1000);
					tap_and_sleep(79,192); --点击强化
					mSleep(1000);
					tap_and_sleep(79,192);

					while (true) do
						x,y = findMultiColorInRegionFuzzy( 0xff5f3b, "4|0|0xf7482b,4|-3|0xf8563a,-4|-3|0xff744f,-4|1|0xf64527,1|4|0xf93919", 90, 1072, 98, 1277, 748) 
						if x > -1 then --找到内容里的小红点
							tap_and_sleep(x,y);
							mSleep(1000);
							tap_and_sleep(840,707);--点击强化
							mSleep(4000);
						else
							tap_and_sleep(40,60);
							qianghua_time = getNetTime();
							break;
						end	
					end
				end
			end

			qianghua_index = qianghua_index + 1;
				
		elseif page == "技能强化页" then
			while (true) do
				x,y = findMultiColorInRegionFuzzy( 0xff5f3b, "4|0|0xf7482b,4|-3|0xf8563a,-4|-3|0xff744f,-4|1|0xf64527,1|4|0xf93919", 90, 1072, 98, 1277, 748) 
				if x > -1 then --找到内容里的小红点
					tap_and_sleep(x,y);
					mSleep(1000);
					tap_and_sleep(840,707);--点击强化
					mSleep(4000);
				else
					tap_and_sleep(40,60);
					qianghua_time = getNetTime();
					break;
				end	
			end
			
		elseif page == "挂机试炼页" or page == "挂机试炼页2" then

			if isColor(965,737,0xab5c1e) == false then
				tap_and_sleep(965,737);--点击自动战斗
				
				tap_and_sleep(1216,80);--点击地图
				tap_and_sleep(1216,80);--点击地图
				tap_and_sleep(1216,80);--点击地图

				random_monster = math.random(1,10);
				if random_monster == 1 then
					tap_and_sleep( 1140,  240);
				elseif random_monster == 2 then
					tap_and_sleep( 1140,  280);
				elseif random_monster == 3 then
					tap_and_sleep( 1140,  320);
				elseif random_monster == 4 then
					tap_and_sleep( 1140,  360);
				elseif random_monster == 5 then
					tap_and_sleep( 1140,  395);
				elseif random_monster == 6 then
					tap_and_sleep( 1140,  435);
				elseif random_monster == 7 then
					tap_and_sleep( 1140,  470);
				elseif random_monster == 8 then
					tap_and_sleep( 1140,  510);
				elseif random_monster == 9 then
					tap_and_sleep( 1140,  545);
				elseif random_monster == 10 then
					tap_and_sleep( 1140,  585);
				end	
				
				tap_and_sleep(1150,650);--点击传送门
				mSleep(1000);
				tap_and_sleep(40,60);--点击返回
				mSleep(10 * 1000);

				--mSleep(0.5 * 60 * 60 * 1000)--等待30分钟
				is_guaji_task_end = true;--做完挂机试炼任务	
			end	

				
			
		elseif page == "游戏战盟页" or page == "游戏战盟页2" or page == "游戏战盟页3" or page == "游戏战盟页4"  then
			
			x7,y7 = findMultiColorInRegionFuzzy( 0xdededf, "0|-4|0xebebec,6|-3|0xf7f7f7,17|-3|0xe3e2e3,21|2|0xdbdbdb,17|6|0xb7b6b8", 85, 45, 316, 92, 343)--战盟
			x8,y8 = findMultiColorInRegionFuzzy( 0x82b6e3, "6|1|0x85bbed,0|4|0x7cadd9,17|1|0x7daedb,18|6|0x79a8d3,21|6|0x79a9d4", 85, 45, 316, 92, 343)--战盟
			x9,y9 = findMultiColorInRegionFuzzy( 0xfaf6ee, "0|4|0xf4eee2,6|1|0xfcfaf8,17|1|0xf1ede6,20|0|0xefebe0,21|6|0xeae6de", 85, 45, 316, 92, 343)--战盟3
			x11,y11 = findMultiColorInRegionFuzzy( 0x82e19d, "0|4|0x7cd596,6|1|0x85eba2,14|1|0x81e29d,14|7|0x87eea3,21|6|0x76cf92", 85, 45, 316, 92, 343)--战盟4
			x13,y13 = findMultiColorInRegionFuzzy( 0xb277dd, "6|1|0xbc7ce9,14|1|0xac75d7,18|6|0x986abe,21|10|0x9e6dc4,24|10|0x9e6dc4", 85, 45, 316, 92, 343)--战盟5
			x14,y14 = findMultiColorInRegionFuzzy( 0xc3cae0, "6|1|0xccd3ea,14|7|0xcfd7ed,24|9|0xb7bed3,18|6|0xb5bdd1,7|7|0xc6cee3", 85, 45, 316, 92, 343)--战盟6
			if x7 > -1 or x8 > -1 or x9 >-1 or x11 > -1 or x13 > -1 or x14 > -1 then
				if x7 > -1 then
					tap_and_sleep(x7,y7);
				elseif x8 > -1 then
					tap_and_sleep(x8,y8);
				elseif x9 > -1 then
					tap_and_sleep(x9,y9);
				elseif x11 > -1 then
					tap_and_sleep(x11,y11);
				elseif x13 > -1 then
					tap_and_sleep(x13,y13);
				elseif x14 > -1 then
					tap_and_sleep(x14,y14);	
				end
				mSleep(3000);
				
			else
				tap_and_sleep(1100,40);--点击离开
				
				--[[zhu_x,zhu_y = findMultiColorInRegionFuzzy( 0xdca24d, "0|4|0xd99f4d,16|0|0xd7a04e,11|2|0xe5a950,0|9|0xd8a04c,18|7|0xd99f4d", 85, 47, 193, 91, 306);
				if zhu_x > -1 then--识别主线2个字
					tap_and_sleep(zhu_x,zhu_y);--点击主线
				end	]]
			end
		elseif page == "金币副本页" then
			if isColor(965,737,0xab5c1e) == false then
				tap_and_sleep(965,737);--点击自动战斗
			end	
			
		else
			
			
			x,y = findMultiColorInRegionFuzzy( 0xb9bdc5, "3|0|0xadb2bc,-7|0|0xacb1bb,12|5|0xe8e9ec,19|5|0xe8e9ec,30|2|0xb2b7c0,64|5|0x6fc676,75|5|0x74d478,92|5|0x6ab974,103|5|0x6dbf75", 80,  913, 17, 1053, 60)
			if x >-1 then -- 找到右上角离开时间为 00:00 
				tap_and_sleep(1100,40);--点击离开
			end	
			
			x,y = findMultiColorInRegionFuzzy( 0xeff0f2, "14|-1|0xf7f8f9,40|-5|0xfefefe,58|-3|0xf6f6f7,67|-3|0x78dd79,74|-3|0x77db79,77|-3|0x79df7a,85|-3|0x78df79,94|-3|0x77db79,112|-3|0x78de79", 90, 910, 21, 1060, 62)
			if x > -1 then -- 找到右上角离开时间为 00:00 
				tap_and_sleep(1100,40);--点击离开
			end	
			
			
			
			
			x,y = findMultiColorInRegionFuzzy( 0x735252, "-15|2|0xffffff,-15|19|0xd0c0af,-8|20|0xccbba4,5|18|0xd1c0af", 90, 726, 609, 827, 689);
			if x >-1 then --找到 背包已满图标
				tap_and_sleep(x,y);
			end	
			
			
			x,y = findMultiColorInRegionFuzzy( 0xa8a897, "0|-20|0xdcdcdc,15|-10|0xb3afa2,18|-10|0xafaf9e,13|0|0xa5a594,13|-20|0xcbcbc3", 90, 1046, 6, 1144, 96)
			if x > -1 then
				if isColor(965,737,0xab5c1e) == false then
					tap_and_sleep(965,737);--点击自动战斗
				end	
			end	
			
			
		end	
		
	end
end

--插入账号是否执行过操作信息
function insert_account_deal_info(...)
	-- body
	time = getNetTime();
	now_time_hh = os.date("%H",time);--时
	now_time_mm = os.date("%M",time);--分
	
	if tostring(now_time_hh) == "00" and tostring(now_time_mm) == "10" then --12点10 分，把所有的账号操作置为false
		insert_into_table("account_1",false);
		insert_into_table("account_2",false);
		insert_into_table("account_3",false);
		insert_into_table("account_4",false);
		--break;
	end	
end

--提示对话框
function center_dialog(...)
	x,y = findMultiColorInRegionFuzzy( 0xc2b28a, "20|29|0xa09888,755|21|0x9e9686,690|24|0xfff1d0,689|34|0xbe954b,50|254|0x8d8d8d,700|254|0x818181", 85, 190, 199, 1045, 598)
	nLog("提示对话框的外框-x="..x)
	if x > -1 then --识别 提示对话框的外框  （如果有一样的对话框根据内容做区分）1.穿戴
		--1.穿戴
		x,y = findMultiColorInRegionFuzzy( 0xcad2dc, "21|-1|0xcdd4dd,43|1|0xc6ced8,235|-6|0xefede0,256|-3|0xe9e5d4,281|-3|0xe9e5d3,300|-1|0xe4e0ca,322|1|0xe0dbc2", 90, 407, 444, 913, 539)
		if x > -1 then
			tap_and_sleep(771,488);--点击穿戴并传承
		end	
		--2.战斗未结束的提示
		x,y = findMultiColorInRegionFuzzy( 0xfefefe, "16|-3|0xfefefe,38|-8|0xfefefe,54|-1|0xfefefe,189|-3|0xfafafa,196|-3|0xfdfdfd,120|1|0xfdfdfd,152|-7|0xfbfbfc", 90, 503, 324, 814, 377)
		if x >-1 then
			tap_and_sleep(510,488);--点击取消
		end	
		--3.加入战盟提示
		x,y = findMultiColorInRegionFuzzy( 0xe1e2e3, "19|-7|0xfefefe,25|1|0xf5f5f6,36|-5|0xfafafa,40|-5|0xf9f9fa,42|2|0xfdfdfd,51|-5|0xf4f4f4,75|-4|0xfdfdfd", 85, 501, 317, 852, 379)
		if x > -1 then
			tap_and_sleep(771,488);--点击确定
		end	
		--4.无法捡起道具的提示
		x,y = findMultiColorInRegionFuzzy( 0xffffff, "21|2|0xfdfdfe,33|2|0xfdfdfd,33|-3|0xf9f9fa,53|-4|0xfefefe,70|3|0xfdfdfd", 85, 529, 319, 754, 375)
		if x >-1 then
			tap_and_sleep(771,488);--点击ok
		end	
		

	end	
	x,y = findMultiColorInRegionFuzzy( 0xb6a67f, "246|5|0xb0a07a,-17|413|0x7a7467,255|420|0x767166,119|-61|0xd6c79c,228|-47|0xc8bb90,268|-59|0xc8bb98,-24|-60|0xc9bd99", 90, 373, 63, 1020, 726)
	if x > -1 then --识别 贵族外框
		x,y = findMultiColorInRegionFuzzy( 0xfffccc, "-8|1|0xfffccd,18|-1|0xfffccc,20|-9|0xeed699,70|22|0xd3b275,50|14|0xdabe87,78|37|0xc99047,-5|24|0xd2b27c,35|21|0xe3cf8c", 90, 556, 181, 715, 261)
		if x > -1 then --1.贵族 字
			tap_and_sleep(821,618);--点击空白区域
		end	
	end	
	x,y = findMultiColorInRegionFuzzy( 0xfef1d5, "3|-9|0xfffbf2,7|8|0xffe9bc,11|-2|0xfef3dc,39|-6|0xfef7e8,39|-10|0xfffcf5,44|2|0xfdeecf,469|42|0xfdedcc,-461|17|0x978b70", 90, 49, 12, 1260, 387)
	nLog("充值对话框-x="..x);
	if x > -1 then --充值对话框
		tap_and_sleep(1090,160);--点击关闭
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0x871513, "650|18|0xfff1d0,664|362|0x690300,-2|360|0x600200,665|136|0x8d151a,103|245|0x7f0405,106|419|0x7bb539,438|415|0xececdb", 90, 259, 144, 1083, 675)
	if x >-1 then--活跃度粉钻红包
		tap_and_sleep(955,215);--点击关闭
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xfdfefe, "147|35|0xf1f2f4,578|86|0xfffe03,449|-3|0xd1cdcf,620|113|0x8e3c3c,1068|602|0x6d6d7d,1133|598|0xf0eee1,1154|596|0xf3f1e9", 80, 0, 0, 1279, 799)
	if x >-1 then
		tap_and_sleep(1175,715);--点击退出活动
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xe0dac1, "-6|1|0xddd7bc,6|-2|0xe4dfc9,21|-7|0xedebdd,22|-7|0xedeadd,45|-8|0xf0eee1,45|-4|0xe7e3d1,66|-11|0xf6f4ed,61|0|0xe0dbc1", 85, 1086, 681, 1268, 757)
	if x > -1 then --识别到退出活动4个字
		tap_and_sleep(1175,715);--点击退出活动
	end
	--5.版本更新提示
	x,y = findMultiColorInRegionFuzzy( 0xfefefe, "15|4|0xf7f7f8,32|2|0xfbfbfb,50|-2|0xfdfdfd,92|-5|0xfefefe,92|5|0xfdfdfd", 85, 383, 304, 618, 358)
	if x > -1 then
		tap_and_sleep(771,488);--点击确定
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xfaf8f5, "0|4|0xfbf9f7,18|3|0xffffff,18|-2|0xffffff,18|8|0xfefdfc,37|8|0xa67038,-27|8|0xa67138,68|-20|0xbbb3b3", 90, 553, 583, 719, 646)
	if x >-1 then --识别确定按钮 （停服公告）
		tap_and_sleep(x,y);--点击确定
	end	
	
	--5.断开连接
	x,y = findMultiColorInRegionFuzzy( 0xfefefe, "0|10|0xfefefe,0|12|0xf0f1f1,15|6|0xfafafb,38|2|0xfafafa,60|4|0xfdfdfe,60|0|0xfdfdfd", 90, 667, 345, 801, 383)
	if x > -1 then
		tap_and_sleep(650,488);--点击ok
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0x735252, "-15|2|0xffffff,-15|19|0xd0c0af,-8|20|0xccbba4,5|18|0xd1c0af", 90, 726, 609, 827, 689);
	if x >-1 then --找到 背包已满图标
		tap_and_sleep(x,y);
		return
	end		
		
	x,y = findMultiColorInRegionFuzzy( 0xffffff, "-7|-9|0xffffff,9|-10|0xffffff,17|-10|0xffffff,15|6|0xf9f3f3,9|15|0xbaaa91,0|8|0xf2eae4,0|5|0xf9f9f9", 90, 735, 616, 815, 687)
	if x > -1 then --找到 药不足的图标
		tap_and_sleep(x,y);
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xe0dcc4, "0|3|0xcfc9b0,25|-7|0xf0eee2,39|-4|0x65657d,-180|48|0xfbe237,-96|92|0xfefefd,-151|91|0xb08959,-67|93|0xaf8a5c", 90, 511, 547, 853, 711)
	if x >-1 then
		tap_and_sleep(803,583);--点击最大
		mSleep(1000);
		tap_and_sleep(680,680);--点击购买
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xfcfcfc, "0|-5|0xffffff,0|8|0xcfc7b6,-15|-5|0xffffff,14|1|0xfefcf8,-5|24|0xffffff,-7|-1|0xbf411b", 90, 656, 611, 767, 689)
	if x > -1 then --转职的图标
		tap_and_sleep(x,y);
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x5a6065, "707|-30|0x6b7a82,673|-77|0xfff1d0,314|-81|0xffffff,435|-65|0xffffff,444|371|0xa5733a,557|372|0xa8763d,493|372|0xf5f3cf,506|372|0xf4f2ce,528|377|0xf0ecb8", 90, 181, 67, 1171, 718)
	if x > -1 then --转职对话框
		tap_and_sleep(  786,  608);
	end
end

--交易金币，选择角色
function logout(...)
	
	if find_value_from_table('selected_account') == 1 then
		insert_into_table('account_1',true);
	elseif find_value_from_table('selected_account') == 2 then
		insert_into_table('account_2',true);
	elseif find_value_from_table('selected_account') == 3 then
		insert_into_table('account_3',true);
	elseif find_value_from_table('selected_account') == 4 then
		insert_into_table('account_4',true);
	end
	
	tap_and_sleep(40,60);--点击头像
	mSleep(1000);
	tap_and_sleep( 1096,  680);--点击设置
	mSleep(1000);
	tap_and_sleep(398,  632);
	mSleep(1000);  
	
	is_jiaoyi_task_end = false;
end
--交易任务
function jiaoyi_task(...)
	-- body
	--is_jiaoyi_task_end
	--1.点地图
	nLog("jiaoyi_task")
	tap_and_sleep(1200,70);
	tap_and_sleep(1200,70);
	tap_and_sleep(1200,70);
	tap_and_sleep(1200,70);
	tap_and_sleep(1200,70);
	mSleep(3000);
	x,y = findMultiColorInRegionFuzzy( 0xe3e3e2, "-1|5|0xbdbdbd,155|3|0x818ea0,167|2|0x818ea0,192|5|0x808d9f,-9|598|0x30343d", 90, 0, 22, 314, 782);--地图页
	nLog("地图页-x = "..x..y)
	if x > -1 then 
		tap_and_sleep(74,310);--点击世界地图
		mSleep(1000);
		tap_and_sleep(420,293);--点击狄牛特
		mSleep(20 * 1000);
		
		tap_and_sleep(1200,70);
		tap_and_sleep(1200,70);
		tap_and_sleep(1200,70);
		tap_and_sleep(29,200);--点击 区域地图
		tap_and_sleep(29,200);--点击 区域地图
		tap_and_sleep(29,200);--点击 区域地图
		mSleep(1000);
		x,y = findMultiColorInRegionFuzzy( 0xe6e6e6, "-2|5|0xbdbdbd,257|59|0xfff9e0,319|57|0xfff9e0,263|119|0xfffeeb,292|116|0xfffeee,325|119|0xfefdea,300|126|0xfefee2", 90, 2, 33, 454, 248)
		nLog("帝纽特 地图-x="..x)
		if x > -1 then --帝纽特 地图
			tap_and_sleep(573,349);--点击一个小点
			mSleep(1000);
			tap_and_sleep(40,60);
			mSleep(3000);
		end		
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0x132942, "11|0|0x87cbf6,11|-4|0x84c6f1,28|2|0x89cef9,41|-6|0x89cef9,52|-3|0x89cdf8,52|4|0x8acef9", 80, 506, 161, 899, 483)--找到中级骑士几个字
	nLog("中级骑士-x="..x)
	if x > -1 then
		randomTap(x+70,y+30)--点击人物
		mSleep(1000);
		x,y = findMultiColorInRegionFuzzy( 0xab2510, "15|0|0xab2510,35|0|0xab250f,87|-15|0x616171,87|-9|0x575762,119|-22|0x6b6b7b", 90, 514, 0, 755, 88)--找到人物血条
		if x > -1 then --说明建立了对话
			flag = baidu_text_ocr(585, 15, 649, 38, "Yeraz1");
			if flag then --如果是要交易的人
				tap_and_sleep(555,44);--点击头像
				mSleep(2000);
				tap_and_sleep(635,257);--点击请求交易
				jiaoyi_index = 0;
				while (true) do
					x,y = findMultiColorInRegionFuzzy( 0x626172, "816|30|0xfdf2d0,316|0|0xeef0f4,-223|570|0x6f6f6c,324|584|0x20b2cd,818|571|0x6e6e6b", 90, 17, 67, 1185, 724)
					if x > -1 then --找到与Yeraz1交易的对话框
						if jiaoyi_index <= 5 then
							if isColor(  697,  267, 0x151c25 ) == false then --第一个物品框
								tap_and_sleep(697,  267);

							elseif isColor(  785,  267, 0x151c25 ) == false then --第二个物品框
								tap_and_sleep(785,  267);

							elseif isColor(  872,  267, 0x151c25 ) == false then --3
								tap_and_sleep(872,  267);

							elseif isColor(  961,  267, 0x151c25 ) == false then --4
								tap_and_sleep(961,  267);

							elseif isColor(  1045,  267, 0x151c25 ) == false then --5
								tap_and_sleep(1045,  267);
							else
	
							end
							
							x,y = findMultiColorInRegionFuzzy( 0xf9e845, "299|38|0xfefefe,291|42|0xfdfdfe,316|40|0xffffff,161|-10|0x86a3bf,179|-1|0x6c809b,-42|-11|0x88a5c1,-47|-11|0x839fba", 90, 499, 571, 937, 697)
							if x > -1 then -- 放入的框
								tap_and_sleep(880,645);--点击放入
							else
								tap_and_sleep( 1240, 50);--点击关闭
							end	
							
							jiaoyi_index = jiaoyi_index + 1;
							
						else
							break;
						
						end
						
						--[[x,y = findMultiColorInRegionFuzzy( 0xa7bfdc, "40|0|0xa4bbd7,58|0|0xa7bfda,30|272|0xf8e142,88|305|0x6b7daa,120|309|0xd2d8e2,120|317|0xb0bbca", 90, 511, 313, 850, 695)
						if x > -1 then --出售的框
							tap_and_sleep(681,650);--点击出售
						end	]]
						
						
					end	
				end
				
				
				
				while (true) do
					mSleep(1000);
					if isColor(  236,  626, 0x69798a) then
						tap_and_sleep(270,630);--点击锁定
						mSleep(1000);
						tap_and_sleep(771,480);--点击确定
						mSleep(1000);
						break;
					end
				end
				
				while (true) do
					mSleep(1000);
					if isColor(  499,  626, 0x687889 ) then
						tap_and_sleep(512,630);--点击交易
						mSleep(1000);
						tap_and_sleep(771,480);--点击确定
						mSleep(1000);
						break;
					end	
				end
				
				tap_and_sleep( 1136,  144);--点击关闭
				
				tap_and_sleep(1200,70);
				tap_and_sleep(1200,70);--点击地图
				mSleep(3000);
				tap_and_sleep(74,310);--点击世界地图
				tap_and_sleep(74,310);--点击世界地图
				mSleep(1000);
				tap_and_sleep(177,  448);
				mSleep(10 * 1000);
				
				-- 回去勇者大陆  如果当前选中的是第四个英雄
				--[[if find_value_from_table('selected_account') ~= nil and find_value_from_table('selected_account') == 4 then
					
					tap_and_sleep(1200,70);
					tap_and_sleep(1200,70);
					count = math.random(1,5);
					if count == 1 then
						tap_and_sleep(1145,  358);
					elseif count == 2 then
						tap_and_sleep( 1141,  394);
					elseif count == 3 then
						tap_and_sleep(  1141,  434);	
					elseif count == 4 then
						tap_and_sleep(  1152,  473);	
					elseif count == 5 then
						tap_and_sleep(  1147,  510);		
					end
					tap_and_sleep(40,60);--点击返回
				else
					tap_and_sleep(1200,70);
					tap_and_sleep(1200,70);--点击地图
					mSleep(3000);
					tap_and_sleep(74,310);--点击世界地图
					tap_and_sleep(74,310);--点击世界地图
					mSleep(1000);
					tap_and_sleep(177,  448);
					mSleep(10 * 1000);
				end]]
				
			end	
		end	
	end	

	
	is_jiaoyi_task_end = true;
	return
end

--奖励对话框
function reward_dialog(...)
	--1.恭喜获得
	x,y = findMultiColorInRegionFuzzy( 0x999968, "-8|3|0x938b62,86|3|0x938b62,-446|11|0x898968,529|14|0x87766a,-459|-298|0xe2d389,537|-299|0xe6d68d", 90, 78, 148, 1228, 610)
	if x >-1 then --恭喜获得
		tap_and_sleep(643,733);--点击空白区域
	end	
	--2.副本战斗结束领取界面
	x,y = findMultiColorInRegionFuzzy( 0xffffff, "387|3|0xffffff,-22|-67|0xffffff,413|-70|0xffffff,179|115|0xffff0a,593|526|0xa27137", 80, 0, 0, 1279, 799)
	nLog("副本战斗结束领取界面-x="..x);
	if x > -1 then
		tap_and_sleep( 1040,710);--点击领取
	end	
	--3.挂机时间奖励对话框
	x,y = findMultiColorInRegionFuzzy( 0x585861, "79|17|0x474757,498|2|0x4f4f57,511|13|0x4c4c54,34|-141|0x59627f,440|-115|0x596a8d,213|17|0xa0763d,307|20|0xa8763c", 90, 288, 352, 1031, 719)
	if x > -1 then
		tap_and_sleep(640,630);--点击领取
	end	
	--4.冥想收益
	x,y = findMultiColorInRegionFuzzy( 0x616161, "510|-7|0xfdedcc,498|-9|0xd9b86e,-32|527|0x525a6b,578|528|0x485869,8|439|0x4c4c54,216|462|0xa37940,317|469|0xa6743a", 90, 240, 54, 1081, 775)
	if x > -1 then
		tap_and_sleep(640,670);--点击领取
	end	
end
--选择任务,只有主线的时候就做主线
function do_task()
		
	x,y = findMultiColorInRegionFuzzy( 0xe2ac5b, "5|5|0xdea652,33|1|0x907652,46|3|0xd8a454,-36|24|0xf1f1f2,19|17|0xf65f58,29|16|0xf55f55,24|23|0xec5a52,35|23|0xf86e5b,41|23|0xcd6456", 90, 47, 200, 232, 249)
	if x > -1 then --135 一个账号35级完成
		
		--insert_into_table("account_number","");
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xe2d9ab, "7|0|0xd1c9a3,13|0|0xe2d9aa,17|-3|0xd5ceab,11|3|0xded5a1,17|4|0xd8cf9b", 90, 208, 58, 264, 81)
	if x > -1 then--118级
		--tap_and_sleep(110,280);--点击日常
		is_today_clickd_experience = false;
		is_today_hang_up_experience = false;
		--is_119_zhuanzhi = false;
	end
	
	x_119,y_119 = findMultiColorInRegionFuzzy( 0xe2d9ab, "7|0|0xd1c9a3,11|-1|0xe1d9ad,17|-1|0xe2d9ad,17|2|0xdcd3a2,12|5|0xcac194", 90, 209, 61, 261, 78)
	x_119_2,y_119_2= findMultiColorInRegionFuzzy( 0xbbb491, "7|0|0xcfc79c,11|0|0xc6be96,17|0|0xdad1a5,12|5|0xafa57c,11|3|0x756e5a", 90, 209, 61, 261, 78)
	x_159,y_159 = findMultiColorInRegionFuzzy( 0xdfd8af, "0|6|0xada985,10|5|0xbfb990,5|3|0xd1c99d,13|3|0xd2cb9f,14|7|0x969376", 90, 209, 61, 261, 78)
	x_159_2,y_159_2= findMultiColorInRegionFuzzy( 0xf0e8b9, "5|3|0xd7d4a8,4|5|0x2f4d5d,19|4|0xcdc99d,13|3|0xe6e0ad,13|5|0x34515b", 90, 199, 58, 276, 82)
	nLog("x_119-x="..x_119..x_119_2)
	if x_119 >-1 or x_119_2 > -1 or x_159 > -1 or x_159_2 > -1 then --119,159级了  转职  
		--[[tap_and_sleep(50,40);--点击头像
		mSleep(1500);
		tap_and_sleep(120,110);--点击角色
		mSleep(1500);
		tap_and_sleep(45,515);--点击转职
		mSleep(1500);
		tap_and_sleep(1162,652);--点击转职
		mSleep(1500);
		tap_and_sleep(40,60);--点击返回
		]]
		--is_119_zhuanzhi = true;
		is_today_clickd_experience = false;
		is_today_hang_up_experience = false;
	end	
	
	
	--[[if is_119_zhuanzhi == true then
		x,y = findMultiColorInRegionFuzzy( 0xf6bc57, "0|1|0xf8bd58,0|2|0xdaa852,16|-5|0xf0b857,16|-3|0xf0b857,16|-1|0xefb757,15|4|0xe5b056", 90, 44, 314, 92, 342)
		if x > -1 then--识别 采集2字
			tap_and_sleep(x,y);
			mSleep(5500); --采集一个需要 5s
			return
		end	
	end]]
	
	x,y = findMultiColorInRegionFuzzy( 0x77dc78, "9|0|0x77dd79,17|3|0x75d677,21|3|0x77dc78,37|-3|0x7ae37a,38|5|0x77de78", 85, 178, 258, 268, 428)
	if x > -1 then--找到 已完成 三个字
		tap_and_sleep(x,y);--点击已完成
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x6fce72, "9|-1|0x63b66a,20|-4|0x74d776,22|3|0x6bc670,37|-3|0x74d875,38|5|0x72d574,17|5|0x6ecb71,-1|5|0x65ba6b", 85, 184, 308, 276, 421)
	if x > -1 then --找到 已完成 三个字
		tap_and_sleep(x,y);--点击已完成
		return
	end	
	
	--keepScreen(true)	
	zhu_x,zhu_y = findMultiColorInRegionFuzzy( 0xdca24d, "0|4|0xd99f4d,16|0|0xd7a04e,11|2|0xe5a950,0|9|0xd8a04c,18|7|0xd99f4d", 85, 47, 193, 91, 306);
	zhu_x2,zhu_y2 = findMultiColorInRegionFuzzy( 0xdda44f, "0|4|0xdba251,0|9|0xdba34f,16|0|0xd59e51,17|3|0xd49e52,18|7|0xdaa251", 85, 47, 193, 91, 306);
	nLog("主线-x="..zhu_x..zhu_x2)
	nLog("is_today_clickd_experience="..tostring(is_today_clickd_experience))
	nLog("is_today_hang_up_experience="..tostring(is_today_hang_up_experience))
	if zhu_x > -1 or zhu_x2 >-1 then--识别主线2个字
		mSleep(3000);--等待 3S再点
		x,y = findMultiColorInRegionFuzzy( 0xf1f1f1, "-3|-5|0xf3f3f4,29|-6|0xfffef9,40|-1|0xffffff,12|-9|0xf4f3f1,39|-9|0xf7f5f2", 85, 43, 224, 122, 248)
		nLog("等级达到4个字-x="..x);
		if x >-1 then  --主线任务提示 等级达到 说明卡任务
			x1,y1 = findMultiColorInRegionFuzzy( 0x80b0e1, "8|0|0x7ba8d5,19|3|0x80afdf,19|4|0x7ba6d3,-1|-5|0x79a5cf,0|6|0x7dacdb,8|6|0x7aa4d0,24|5|0x77a1cd", 80, 41, 259, 94, 286)--日常1
			x2,y2 = findMultiColorInRegionFuzzy( 0xb578e0, "0|-5|0xb277dd,8|-5|0xa772d0,8|0|0xaa73d3,19|2|0xb177dd,19|5|0x9f6fc7,23|0|0xa973d2,19|-5|0xa572ce", 80, 41, 259, 94, 286)--日常2
			x3,y3 = findMultiColorInRegionFuzzy( 0x72c38f, "0|-5|0x72c390,0|5|0x71c18e,9|5|0x70be8d,9|0|0x74c792,20|2|0x7ad397,20|4|0x73c490,20|-4|0x6cb58a", 80, 41, 259, 94, 286)--日常3
			x4,y4 = findMultiColorInRegionFuzzy( 0xacb3cc, "0|-5|0xabb2cc,9|-5|0xaab2cb,9|0|0xaeb6cf,20|2|0xb7bfd8,20|4|0xabb3cc,20|-4|0x9ea6c0,9|5|0xa5adc7", 80, 41, 259, 94, 286)--日常4
			x10,y10 = findMultiColorInRegionFuzzy( 0xedb65a, "8|0|0xf4bb5a,19|3|0xf4b957,15|0|0xf2b95a,14|4|0xfdc159,25|-3|0xdaaa5c", 80, 41, 259, 94, 286)--日常5
			x12,y12 = findMultiColorInRegionFuzzy( 0xe1ae59, "8|0|0xcfa257,16|1|0x9c7f53,22|2|0x897252,19|3|0xddac57,20|-4|0xb99255", 80, 41, 259, 94, 286)--日常6
			nLog("x1-x4="..x1..x2..x3..x4..x10)
			if x1 > -1 or x2 >-1 or x3 > -1 or x4 >-1 or x10 > -1 or x12 > -1  then
				
				tap_and_sleep(110,280);--点击日常
				return
			end
			
			x5,y5 = findMultiColorInRegionFuzzy( 0x0adf0f, "17|2|0x08e10e,33|5|0x0ecf17,33|8|0x08e60c,51|-2|0x05f008,51|-1|0x01fb02,51|6|0x0ae50e,33|8|0x08e60c", 80, 43, 258, 188, 309)--经验副本
			nLog("x1-x4="..x5)
			if x5 > -1 then
				tap_and_sleep(x5,y5);
				return
			end
			
			
			x7,y7 = findMultiColorInRegionFuzzy( 0xdededf, "0|-4|0xebebec,6|-3|0xf7f7f7,17|-3|0xe3e2e3,21|2|0xdbdbdb,17|6|0xb7b6b8", 85, 45, 316, 92, 343)--战盟
			x8,y8 = findMultiColorInRegionFuzzy( 0x82b6e3, "6|1|0x85bbed,0|4|0x7cadd9,17|1|0x7daedb,18|6|0x79a8d3,21|6|0x79a9d4", 85, 45, 316, 92, 343)--战盟
			x9,y9 = findMultiColorInRegionFuzzy( 0xfaf6ee, "0|4|0xf4eee2,6|1|0xfcfaf8,17|1|0xf1ede6,20|0|0xefebe0,21|6|0xeae6de", 85, 45, 316, 92, 343)--战盟3
			x11,y11 = findMultiColorInRegionFuzzy( 0x82e19d, "0|4|0x7cd596,6|1|0x85eba2,14|1|0x81e29d,14|7|0x87eea3,21|6|0x76cf92", 85, 45, 316, 92, 343)--战盟4
			x13,y13 = findMultiColorInRegionFuzzy( 0xb277dd, "6|1|0xbc7ce9,14|1|0xac75d7,18|6|0x986abe,21|10|0x9e6dc4,24|10|0x9e6dc4", 85, 45, 316, 92, 343)--战盟5
			x14,y14 = findMultiColorInRegionFuzzy( 0xc3cae0, "6|1|0xccd3ea,14|7|0xcfd7ed,24|9|0xb7bed3,18|6|0xb5bdd1,7|7|0xc6cee3", 85, 45, 316, 92, 343)--战盟6
			if x7 > -1 or x8 > -1 or x9 >-1 or x11 > -1 or x13 > -1 or x14 >-1 then
				if x7 > -1 then
					tap_and_sleep(x7,y7);
				elseif x8 > -1 then
					tap_and_sleep(x8,y8);
				elseif x9 > -1 then
					tap_and_sleep(x9,y9);
				elseif x11 > -1 then
					tap_and_sleep(x11,y11);
				elseif x13 > -1 then
					tap_and_sleep(x13,y13);
				elseif x14 > -1 then
					tap_and_sleep(x14,y14);	
				end
				mSleep(2000);
				return
			end
			
			x6,y6 = findMultiColorInRegionFuzzy( 0x0db819, "0|4|0x0db918,4|4|0x08d50f,11|3|0x07d80e,20|3|0x09d90f,28|6|0x07e10c,45|-1|0x08dd0c,50|-1|0x08df0c", 80, 43, 255, 118, 283)--每日必做
			if  x6 > -1 then
				if is_today_clickd_experience == false or is_today_hang_up_experience == false then
					--tap_and_sleep(110,280);--点击日常
					tap_and_sleep(x6,y6);--点击每日必做
					mSleep(2000);
				else
					tap_and_sleep(zhu_x,zhu_y);--点击主线
				end	
			else
				tap_and_sleep(zhu_x,zhu_y);--点击主线
			end	
				
		else
			tap_and_sleep(zhu_x,zhu_y);
		end	
		--keepScreen(false)
		
		
		--[[x1,y1 = findMultiColorInRegionFuzzy( 0x80b0e1, "8|0|0x7ba8d5,19|3|0x80afdf,19|4|0x7ba6d3,-1|-5|0x79a5cf,0|6|0x7dacdb,8|6|0x7aa4d0,24|5|0x77a1cd", 80, 41, 259, 94, 286)--日常1
		x2,y2 = findMultiColorInRegionFuzzy( 0xb578e0, "0|-5|0xb277dd,8|-5|0xa772d0,8|0|0xaa73d3,19|2|0xb177dd,19|5|0x9f6fc7,23|0|0xa973d2,19|-5|0xa572ce", 80, 41, 259, 94, 286)--日常2
		x3,y3 = findMultiColorInRegionFuzzy( 0x72c38f, "0|-5|0x72c390,0|5|0x71c18e,9|5|0x70be8d,9|0|0x74c792,20|2|0x7ad397,20|4|0x73c490,20|-4|0x6cb58a", 80, 41, 259, 94, 286)--日常3
		x4,y4 = findMultiColorInRegionFuzzy( 0xacb3cc, "0|-5|0xabb2cc,9|-5|0xaab2cb,9|0|0xaeb6cf,20|2|0xb7bfd8,20|4|0xabb3cc,20|-4|0x9ea6c0,9|5|0xa5adc7", 80, 41, 259, 94, 286)--日常4
		x10,y10 = findMultiColorInRegionFuzzy( 0xedb65a, "8|0|0xf4bb5a,19|3|0xf4b957,15|0|0xf2b95a,14|4|0xfdc159,25|-3|0xdaaa5c", 80, 41, 259, 94, 286)--日常5
		x5,y5 = findMultiColorInRegionFuzzy( 0x0adf0f, "17|2|0x08e10e,33|5|0x0ecf17,33|8|0x08e60c,51|-2|0x05f008,51|-1|0x01fb02,51|6|0x0ae50e,33|8|0x08e60c", 80, 43, 258, 188, 309)--经验副本
		x6,y6 = findMultiColorInRegionFuzzy( 0x0db819, "0|4|0x0db918,4|4|0x08d50f,11|3|0x07d80e,20|3|0x09d90f,28|6|0x07e10c,45|-1|0x08dd0c,50|-1|0x08df0c", 80, 43, 255, 118, 283)--每日必做
		x7,y7 = findMultiColorInRegionFuzzy( 0xdededf, "0|-4|0xebebec,6|-3|0xf7f7f7,17|-3|0xe3e2e3,21|2|0xdbdbdb,17|6|0xb7b6b8", 90, 45, 316, 92, 343)--战盟
		x8,y8 = findMultiColorInRegionFuzzy( 0x82b6e3, "6|1|0x85bbed,0|4|0x7cadd9,17|1|0x7daedb,18|6|0x79a8d3,21|6|0x79a9d4", 90, 45, 316, 92, 343)--战盟
		x9,y9 = findMultiColorInRegionFuzzy( 0xfaf6ee, "0|4|0xf4eee2,6|1|0xfcfaf8,17|1|0xf1ede6,20|0|0xefebe0,21|6|0xeae6de", 90, 45, 316, 92, 343)--战盟3
		
		if x1 > -1 or x2 >-1 or x3 > -1 or x4 >-1 or x5 > -1  then
			nLog("x1>-1")
			tap_and_sleep(110,280);--点击日常
		else
			nLog("x1<-1="..zhu_x..zhu_y)
			if x7 > -1 or x8 > -1 or x9 >-1 then
				if x7 > -1 then
					tap_and_sleep(x7,y7);
				elseif x8 > -1 then
					tap_and_sleep(x8,y8);
				elseif x9 > -1 then
					tap_and_sleep(x9,y9);
				end
			else
				if  x6 > -1 then
					if is_today_clickd_experience == false or is_today_hang_up_experience == false then
						tap_and_sleep(110,280);--点击日常
					else
						tap_and_sleep(zhu_x,zhu_y);--点击主线
					end	
				else
					tap_and_sleep(zhu_x,zhu_y);--点击主线
				end	
			end
			
			
			
		end	]]
		
	end
	

end

-- x 掉活动提示
function activite_dialog(...)
	x,y = findMultiColorInRegionFuzzy( 0x868174, "0|465|0x868072,862|465|0x858173,863|1|0x858173,831|25|0xfff1d0,845|23|0xc59c4a,817|23|0xd7b674,830|10|0xe7cd82,831|39|0xbf8e44", 90, 146, 123, 1125, 673)
	nLog("activite_dialog-x="..x)
	if x > -1 then --找到 活动提示的对话框 只需要点X关掉
		tap_and_sleep(1035,200);--点x
	end	
end
--跳过引导
function skip_boot(...)
	-- body

	x,y = findMultiColorInRegionFuzzy( 0x8f8f93, "21|8|0xd0d0d5,15|27|0x98989e,-72|2|0xe1f1f9,-73|3|0xcedee6,-48|3|0xdeeef6,-28|8|0xe0f0f8,-106|8|0xe1f1f9,-99|2|0xcfdee7", 90, 1074, 0, 1277, 67)
	if x > -1 then --找到跳过动画按钮
		tap_and_sleep(x,y);
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0x818185, "35|12|0x909096,16|32|0xe1f1f9,15|32|0xe0f1f9,-32|21|0xe1f1f9,-75|29|0xe1f1f9,-81|37|0xe1f1f9,-23|28|0xe1f1f9", 90, 1102, 28, 1279, 83)
	if x > -1 then --找到跳过引导按钮
		tap_and_sleep(x,y);
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0x7c818a, "-1|0|0x7e858e,-1|1|0x7f8690,0|22|0x727983,-9|112|0x565961,-20|197|0x4f535d,-23|197|0x50535d,-14|203|0x383a45,-35|204|0x4f525a", 90, 1222, 518, 1279, 787)
	if x > -1 then --剧情对话
		tap_and_sleep(1130,740);--点击领取的位置
	end
	x,y = findMultiColorInRegionFuzzy( 0x747a83, "-1|18|0x727982,8|49|0x5e626b,-7|96|0x3a3c47,-7|114|0x3b3d49,-4|166|0x373a45,29|194|0x5d606a,8|152|0x54575f", 90, 0, 525, 58, 758)
	if x > -1 then--剧情对话
		tap_and_sleep(1130,740);--点击领取的位置
	end	
end
--如 经验副本
function center_big_dialog(...)
	--[[x,y = findMultiColorInRegionFuzzy( 0xbcb493, "218|-4|0x616171,762|-4|0x5e5e6e,970|15|0xfff1d0,1029|-12|0x99917f,1|554|0x6d6d6d,1002|554|0x6d6d6d,418|567|0x5c5c5c,574|567|0x5c5c5c", 90, 0, 0, 1300, 800)
	nLog("center_big_dialog-x="..x)
	if x > -1 then --识别外边框
		mSleep(2000);
		x,y = findMultiColorInRegionFuzzy( 0xfdfdfd, "0|7|0xfefefe,18|-3|0xffffff,30|-14|0xfbfbfc,48|2|0xfcfcfc,54|2|0xf9f9f9,83|4|0xfdfdfd,82|4|0xfefefe,82|-11|0xffffff", 90, 190, 181, 347, 243)
		nLog("经验副本对话框-x="..x..y)
		if x > -1 then --识别经验副本四个字
			tap_and_sleep(460,660); --点击进入活动
		end	
	end	]]
	--识别经验副本对话框
	x,y = findMultiColorInRegionFuzzy( 0xffffff, "0|7|0xffffff,18|-4|0xffffff,48|2|0xffffff,82|4|0xffffff,82|-11|0xffffff,869|-61|0xfff1d0,-133|-87|0x928a79", 90, 64, 88, 1243, 744)
	if x > -1 then
		tap_and_sleep(460,660); --点击进入活动
	end
	--[[x,y = findMultiColorInRegionFuzzy( 0x41444b, "1239|3|0x43464e,1|668|0x313439,1248|656|0x4a4a59,1216|651|0xdbcbb7,1202|651|0xddcdb9,1202|654|0xe3d5bf,247|-9|0x525463", 90, 0, 0, 1300, 800)
	nLog("center_big_dialog-x="..x)
	if x > -1 then --识别点击了头像
		tap_and_sleep(650,350);
	end	]]
end
--游戏物资页需要做的操作  熔炼
function do_game_goods(...)
	nLog("do_game_goods")	
	
	x,y = findMultiColorInRegionFuzzy( 0xdededd, "1|5|0xbdbdbd,157|8|0x818ea0,156|8|0x818ea0,157|-1|0x808c9f,155|13|0x818ea0,164|9|0x818ea0,165|5|0x818ea0,817|580|0x383373,1171|594|0xa8763d", 90, 0, 0, 1279, 799)
	if x > -1 then
		tap_and_sleep( 1179,  651);--点击转职
		tap_and_sleep(40,60);--点击返回
		return
	end
	
	
	--keepScreen(true)	
	--2.选中背包
	if isColor(24,  301, 0xffffff) then
		if isColor( 1015,  674, 0x69798a ) then
			tap_and_sleep(1047,  682);--点熔炼	
		else
			ronglian_time = getNetTime();
			tap_and_sleep(40,60);--点击返回
		end
		return
	end
	--3.选中魂器
	if isColor(24,  406, 0xffffff) then
		-- 白绿是否选中
		if isColor( 854,  314, 0xc4f7ff )  == false then
			tap_and_sleep(854,  314);
		end
		-- 蓝色是否选中
		if isColor( 946,  314, 0xc4f7ff )  == false then
			tap_and_sleep(946,  314);
		end
		-- 紫色是否选中
		if isColor( 1038,  314, 0xc4f7ff )  == false then
			tap_and_sleep(1038,  314);
		end
		-- 橙色是否选中
		if isColor( 1130,  314, 0xc4f7ff )  == false then
			tap_and_sleep(1130,  314);
		end
		-- 红色是否选中
		if isColor( 1222,  314, 0xc4f7ff )  == false then
			tap_and_sleep(1222,  314);
		end
		
		tap_and_sleep(478,711);--点击熔炼
		tap_and_sleep(771,488);--点击熔炼
		--[[for var= 1, 5 do
			tap_and_sleep(478,711);--点击熔炼
			tap_and_sleep(771,488);--点击熔炼
			--tap_and_sleep(40,60);--点击返回
		end]]
		ronglian_time = getNetTime();
		tap_and_sleep(40,60);--点击返回
		return
	end	
	
	tap_and_sleep(40,60);--点击返回
	--keepScreen(false)
end

-- 点击
function tap_and_sleep(x,y)
	-- body
	randomTap(x,y);
	mSleep(math.random(0.1 * 1000, 1 * 1000));
end

-- 获取当前界面
function get_page(page_list)
	-- body
	for k,v in pairs(page_list) do
		--nLog(v.."");
		x, y = findMultiColorInRegionFuzzy(v.features[2], v.features[3], v.features[4], v.features[5], v.features[6], v.features[7], v.features[8]); 
		if x > -1 or y > -1 then
			return v.features[1];
		end

	end

	return "没找到界面";
end


