require("TSLib") -- 导入TS LIB库


init(1); -- 代表横屏


-- 点击
function tap_and_sleep(x,y)
	-- body
	randomTap(x,y);
	mSleep(math.random(0.1 * 1000, 0.5 * 1000));
end


function upgrade(...)
	x,y = findMultiColorInRegionFuzzy( 0xbfaa83, "31|-2|0xbfaa82,57|-4|0xbda982,82|2|0xb6a37c,-28|450|0x896d49", 90, 376, 96, 903, 717)
	nLog("叛军营地-x="..x)
	if x > -1 then
		tap_and_sleep(  646,  589);--点击前往
		--return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0x445165, "13|-19|0x455465,11|17|0x405069,173|-20|0x455465,92|-2|0xf6f6f6,92|-6|0xf5f5f5,113|-2|0xf9f9f9", 90, 11, 616, 401, 739)
	nLog("出城-x="..x)
	if x > -1 then	
		tap_and_sleep(68,680);
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xfcf8da, "7|0|0xfff8d1,29|-1|0xfff7c5,81|-12|0xebcf8e,83|10|0xe9cc8e,66|-8|0xfbdb98,103|-8|0xe0c588", 90, 0, 87, 227, 575)
	nLog("天赋-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xf6f0ca, "0|5|0xfbf8cb,0|15|0xfefdca,9|47|0xffeeb2,-10|88|0xe7ca8c,8|86|0xe8cc8e,-1|86|0xe8cc8e,7|103|0xe0c488", 90, 761, 69, 956, 291)
	nLog("手指向上的箭头-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0x495365, "-5|32|0xe9e9e9,4|43|0x405069,152|27|0xc9393c,172|26|0xd43737,172|29|0xd53737", 90, 377, 274, 702, 478)
	nLog("出征-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		tap_and_sleep(x,y);
		tap_and_sleep(x,y);
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xfbfaca, "0|-3|0xfefcca,0|-9|0xfefecb,0|-22|0xfffac9,-8|-79|0xebce90,7|-82|0xe8cc8c,25|-83|0xe7cc8b", 90, 297, 168, 1166, 676)
	nLog("向下手指-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xffffca, "-7|-73|0xebd090,-9|-44|0xffe9a6,3|-50|0xfae29f,8|-53|0xf9e19d,25|-80|0xe5cc8a", 90, 609, 452, 1258, 712)
	nLog("侦查泉水镇-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfcfcc9, "8|-7|0xffffcc,43|-55|0xf1d796,60|-53|0xe9cc8f,48|-35|0xf9df9d,33|-70|0xf0ce9b", 90, 17, 59, 210, 241)
	nLog("快速选择-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xfcfcc9, "3|-3|0xffffca,6|-6|0xffffcc,52|-61|0xeacd90,58|-55|0xe9cb8e,64|-50|0xe9cc8d", 90, 766, 573, 1244, 732)
	nLog("快速选择-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end		
	
	x,y = findMultiColorInRegionFuzzy( 0xffffcc, "0|2|0xffffcb,0|-44|0xfce8a4,-8|-44|0xffe6a1,-4|-79|0xe7ca8e", 90, 0, 517, 149, 748)
	nLog("回城手指-x="..x)
	if x > -1 then
		tap_and_sleep(68,680)
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x3f4f68, "-9|-39|0x455365,-193|-43|0x455365,-190|-7|0x405069,-36|-8|0x3f5069", 90, 417, 462, 777, 579)
	nLog("加入队伍集结-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xfffffc, "18|19|0xffffc8,39|27|0xfffbb0,61|47|0xedd292,54|63|0xe9cc8e,43|78|0xe5cc8a", 90, 664, 164, 1150, 693)
	nLog("使用-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xfbfac9, "4|-4|0xfffec9,8|-8|0xfffecb,50|-60|0xebd091,64|-54|0xe7cb8c,51|-34|0xf8de9c", 90, 58, 581, 631, 739)
	nLog("升级-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end	
	
	
	x,y = findMultiColorInRegionFuzzy( 0xfffffc, "18|19|0xffffc8,39|27|0xfffbb0,61|47|0xedd292,54|63|0xe9cc8e,43|78|0xe5cc8a", 90, 367, 178, 872, 587)
	nLog("使用2-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfffbe1, "-64|57|0xe7cb8d,-53|66|0xe7ca8e,-57|59|0xe8cd8e,-37|51|0xfcdd98,-52|79|0xdecd89", 90, 1009, 125, 1173, 269)
	nLog("升级指挥官-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x3e4f67, "-9|-39|0x455365,-171|-42|0x455365,-169|-9|0x405069,-95|-23|0xececed,-65|-23|0xeaeaea,-47|-31|0xe2e3e4", 90, 930, 75, 1141, 166)
	nLog("升级指挥官-x2="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x3c5067, "8|-43|0x445465,17|-10|0x3f5069,205|-14|0x415065,205|-40|0x455364,81|-29|0xe7e7e7,81|-24|0xe5e5e6,102|-24|0xdddddf,111|-20|0xdcdcde", 90, 103, 206, 1136, 331)
	nLog("查看指挥官详情-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xffffce, "1|-16|0xffffcf,-9|-53|0xffe7a3,-4|-82|0xe7cc8e,9|-73|0xedd492", 90, 979, 419, 1250, 754)
	nLog("放技能-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xffffff, "-24|-22|0xfff7c4,-20|-19|0xfffbc6,-69|-64|0xe3c88a,-55|-64|0xe7cb8c,-57|-42|0xf6d996,-43|-56|0xf3d996", 90, 1133, 589, 1277, 758)
	nLog("右下角手势-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y);--点击前往
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xffffff, "0|-23|0xfffec9,1|-51|0xfff8ad,-8|-51|0xfff8ae,12|-66|0xfcdd98", 90, 132, 545, 551, 748)
	nLog("选择指挥官-x="..x)
	if x > -1 then
		tap_and_sleep(   x,  y);--点击前往
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xffffcc, "9|9|0xfffbc9,26|48|0xf8de9b,52|54|0xe7ca8c,54|45|0xebd091,8|9|0xfffbc9", 90, 587, 450, 725, 574)
	nLog("心树-x="..x)
	if x > -1 then
		tap_and_sleep(   602,  445);--点击前往
		--return
	end
	
	chengwai_x,chengwai_y = findMultiColorInRegionFuzzy( 0xe6cda0, "20|-3|0xdcc496,33|6|0x222e37,43|27|0xa68c61,10|35|0xb1996c,20|-14|0xe8cda1", 90, 14, 627, 124, 752)
	nLog("回城 - 搜索-x="..chengwai_x)
	
	x,y = findMultiColorInRegionFuzzy( 0xfffecb, "8|-9|0xfffbc9,36|-47|0xf5da98,62|-52|0xe5c98b,32|-30|0xffe7a4", 90, 309, 578, 577, 732)
	nLog("免费升级手指-x="..x)
	if x > -1 then
		tap_and_sleep(464,  673);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfffacd, "-51|-4|0xfffbb0,39|-14|0xfbbf81,-25|-25|0xffffcb,-67|-61|0xeccf8f", 90, 1047, 347, 1264, 592)
	nLog("前往手指-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x27272f, "301|1|0x27272f,31|107|0x27272f,304|25|0x746c65,304|14|0x27272f,238|38|0x27272f", 90, 447, 581, 846, 758)
	nLog("对话-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		 --return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfffff9, "0|20|0xffffc9,0|31|0xffffc6,0|47|0xffffb0,9|47|0xffffb0,-1|48|0xffffb1,-9|60|0xffe59d", 90, 630, 266, 1268, 511)
	nLog("兵营-建兵-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		 --return
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xffffe6, "-4|-44|0xffff84,-65|-59|0xf9dc96,-39|-66|0xffeca0,41|-14|0xffff9b", 90, 751, 529, 987, 704)
	nLog("任务手指-x="..x.."-y="..y)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0x838383, "22|-3|0x878787,21|-3|0x858585,21|2|0x848484,47|2|0x7f7f7f,62|3|0x868686", 95, 571, 707, 717, 742)
	nLog("点击屏幕继续-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end

	x,y = findMultiColorInRegionFuzzy( 0x807f7f, "0|3|0x7e7e7e,20|5|0x858585,44|5|0x848484,44|9|0x848484,55|9|0x858585,79|2|0x6d6d6d,103|0|0x7e7e7e", 95, 563, 712, 725, 755)
	nLog("点击屏幕继续-x2="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end

	x,y = findMultiColorInRegionFuzzy( 0x868686, "-5|9|0x777778,22|5|0x8e8e8e,22|13|0x878787,47|10|0x8c8c8c,110|-1|0x898989,90|4|0x8e8e8e", 97, 571, 690, 719, 728)
	nLog("点击屏幕继续-x3="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end

	x,y = findMultiColorInRegionFuzzy( 0x7a7a7b, "0|2|0x7b7b7c,21|5|0x858585,20|0|0x838384,45|5|0x898989,84|4|0x8d8d8d,103|-1|0x828282", 97, 580, 692, 707, 719)
	nLog("点击屏幕继续-x4="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end

	x,y = findMultiColorInRegionFuzzy( 0x797979, "1|8|0x7e7e7e,20|5|0x868686,20|12|0x818181,34|1|0x808080,60|9|0x7f7f7f,84|5|0x8d8d8d,103|0|0x818181", 97, 583, 683, 703, 707)
	nLog("点击屏幕继续-x5="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfdfccb, "-9|-72|0xecd191,8|-75|0xe8cd8e,0|-75|0xeace91,-6|-44|0xffe9a6,2|-50|0xfbe49f,17|-56|0xf9de9c,-26|-69|0xefce94", 90, 354, 547, 548, 728)
	nLog("免费建造的手指-x="..x)
	if x > -1 then
		tap_and_sleep( x,  y);
		mSleep(1000)
		tap_and_sleep(  1080,  722);
		mSleep(1000)
		tap_and_sleep(640,400)
		mSleep(1000)
		tap_and_sleep(  637,  593)--点战斗
		mSleep(1000)
		tap_and_sleep(  903,  686);--点击快速选择
		tap_and_sleep( 1074,  681);--点击出征
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xe3c98a, "7|20|0xeed593,33|42|0xfff1c1,54|49|0xfffbca,14|-3|0xe8cc8c,-9|24|0xeecc98,31|25|0xffe7a5", 90, 708, 497, 853, 629)
	nLog("任务提示那里的手指-x="..x)
	if x > -1 then
		tap_and_sleep( 1236,  622);
		tap_and_sleep( x,  y);
		tap_and_sleep( x-50,  y-50);
		tap_and_sleep( x-50,  y+50);
		tap_and_sleep( x+50,  y+50);
		tap_and_sleep( x+50,  y-50);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xe3c88a, "-3|-13|0xe1c689,4|14|0xecd191,35|5|0xfdde99,48|42|0xffffc7,30|36|0xffffb3", 90, 760, 515, 1002, 692)
	nLog("任务提示那里的手指-x2="..x)
	if x > -1 then
		tap_and_sleep( 1236,  622);
		tap_and_sleep( x,  y);
		tap_and_sleep( x-50,  y-50);
		tap_and_sleep( x-50,  y+50);
		tap_and_sleep( x+50,  y+50);
		tap_and_sleep( x+50,  y-50);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfef6c5, "-7|-63|0xe9ce91,-6|-45|0xf8de9a,6|-42|0xf9df9d,16|-48|0xf4da98,9|-84|0xe2c38d,-12|-66|0xe8ce90", 90, 481, 278, 726, 541)
	nLog("升级主堡那里的手指-x2="..x)
	if x > -1 then
		tap_and_sleep(  599,  436);
		--return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xfdf2ce, "40|-9|0xf5edd3,65|-2|0xfaedcb,87|-4|0xeae2c0,135|0|0xd6cdab,174|-7|0xf3ebc9", 90, 1033, 12, 1265, 77)
	nLog("点击跳过-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfce49f, "60|-5|0xd9c98b,80|-2|0xdac588,160|-5|0xd5c58c,125|2|0xb7a780", 90, 1041, 56, 1253, 110)
	nLog("点击跳过2-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
		--return
	end

	x,y = findMultiColorInRegionFuzzy( 0xb462dd, "40|117|0xad8473,121|29|0xc3a397,198|-7|0x7f878e,40|226|0x98764e,38|259|0x442f1d", 90, 492, 178, 779, 517) -- 解锁指挥官
	nLog("解锁指挥官A-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xb2b3b3, "6|1|0xa2a3a3,22|2|0xb6b7b7,22|-3|0xb8b9b9,88|-3|0xa7a8a8,128|4|0xbcbdbd,151|1|0xbbbcbc,150|2|0xb8b8b8", 93, 549, 695, 735, 733)
	nLog("点击任意位置关闭-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x8c8870, "20|1|0x8c8870,19|5|0x8a876f,42|6|0x8d8871,64|4|0x87836a,124|7|0x979379,159|0|0x847f69", 93, 528, 677, 756, 704)
	nLog("点击任意位置解锁指挥官-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end
	
	
	--[[x1, y1 = findColorInRegionFuzzy(0xfada99, 100, 0, 0, 1280, 800); --手指箭头
	nLog("中间向下的箭头-x1="..x1.."y1="..y1)
	if x1 > -1 then		
		tap_and_sleep(x1,y1);
	end
	
	x2, y2 = findColorInRegionFuzzy(0xc6b38a, 98, 1169, 677, 1238, 753); --对话向下箭头
	nLog("中间向下的箭头-x2="..x2)
	if x2 > -1 then
		tap_and_sleep(x2,y2);
		return
	end
	
	x3,y3 = findMultiColorInRegionFuzzy( 0x27272f, "272|-2|0x27272f,-490|125|0x27272f,772|120|0x27272f", 95, 1, 607, 1279, 774)
	if x3 > -1 then
		tap_and_sleep(1200,713);
		return
	end
	
	x4,y4 = findMultiColorInRegionFuzzy( 0x303a49, "-11|127|0x283749,843|3|0x2f3a49,846|134|0x283749,445|2|0x303a49,447|132|0x283849", 99, 75, 420, 995, 633)
	if x4 >-1 then
		tap_and_sleep(x4,y4);
		return
	end
	
	x5,y5 = findMultiColorInRegionFuzzy( 0x465667, "0|38|0x3f5069,210|-11|0x4c5365,422|1|0x455467,422|39|0x3f5069,245|15|0x58d660", 99, 213, 395, 696, 477)
	if x5 > -1 then
		tap_and_sleep(x5,y5);
		return
	end
	]]
	 
	x,y = findMultiColorInRegionFuzzy( 0x4f7f47, "19|0|0x588b51,36|0|0x517e46,36|38|0x436b39,1|38|0x406937,18|18|0xffffff", 90, 553, 641, 641, 722)
	--希拉
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end

	x,y = findMultiColorInRegionFuzzy( 0xa6b3b5, "371|-11|0x3c4b61,12|8|0x303a49,21|140|0x283749,864|138|0x283849,862|8|0x2f3a49,485|156|0xa7aabc", 90, 50, 425, 988, 623)
	nLog("中间的阴影对话-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xa9a9a9, "0|8|0x535353,109|8|0x424242,107|3|0x9d9d9d,21|95|0x75bc65,31|106|0x65a758,48|99|0x8abf6b,78|110|0x65a64a,114|105|0x66b658", 90, 1008, 545, 1227, 750)
	nLog("一键通关-x="..x)
	if x > -1 then
		tap_and_sleep( 1108,  636);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xdbdbdb, "34|5|0xd3aa60,45|62|0xfdfdfd,108|10|0x555555,22|95|0x9af587,42|108|0x8ce672,80|105|0x8ee373,114|105|0x88ee76", 90, 980, 534, 1205, 721)
	nLog("一键通关-x2="..x)
	if x > -1 then
		tap_and_sleep( 1108,  636);
		--return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0x4b5390, "136|-2|0x753b3f,532|-6|0x2e5477,542|3|0xffffff,738|-1|0x38618a,822|3|0x355d86,799|-43|0x2c82c2,888|-59|0xbe1b32", 90, 229, 39, 1273, 157)
	nLog("领主天赋页-x="..x)
	if x > -1 then
		tap_and_sleep( 1242,   71);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xa5a5a5, "27|-50|0xc2c2c2,54|-54|0xc3c3c3,86|-49|0xbebebe,172|-7|0x373e6d,308|-7|0x582b2e,-48|4|0xadadad,-47|3|0xafafaf,-17|0|0xa6a6a8", 90, 0, 37, 558, 150)
	nLog("领主天赋页2-x="..x)
	if x > -1 then
		tap_and_sleep( 8,  738);
		mSleep(2000)
		tap_and_sleep(  22,  165);
		--return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xfafafa, "-11|-3|0xf7f7f8,17|-2|0xf6f6f6,27|6|0xfefefe,328|2|0xb1b2b2,327|2|0xb4b5b5,298|-1|0xb2b3b3,238|-2|0xaeb0b0", 90, 2, 33, 614, 102)
	nLog("商城页-x="..x)
	if x > -1 then
		tap_and_sleep( 1242,   71);
		--return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0x455365, "266|-1|0x455364,271|73|0x3f5069,-3|67|0x405069,61|58|0x5bde61,60|65|0x59d662,90|64|0x5ee465,90|58|0x59d264,113|64|0x5be062", 90, 758, 387, 1122, 526)
	nLog("未知操作-x="..x)
	if x > -1 then
		tap_and_sleep( 1139,  568);
		--return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfcfcc7, "0|-10|0xffffcc,1|-25|0xfff9c6,-8|-38|0xffeeba", 90, 1051, 521, 1262, 739)
	nLog("兵营训练-x="..x)
	if x > -1 then
		tap_and_sleep( 1147,  686);
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfcf9cb, "-14|13|0xfff8c5,-57|50|0xe5ca8a,-45|55|0xebd08f,-62|54|0xe4c98b", 90, 1120, 30, 1275, 178)
	nLog("点右上角-x="..x)
	if x > -1 then
		tap_and_sleep( 1240,  69);
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfddd97, "41|1|0xfffed8,48|-21|0xfff6b7,72|-41|0xeed294", 90, 1, 602, 219, 755)
	nLog("回城亮光-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
	end

	x,y = findMultiColorInRegionFuzzy( 0xfffff6, "0|-16|0xffffcd,0|-47|0xfffbaa,-8|-63|0xfcda98,3|-74|0xeacf8f", 90, 165, 591, 576, 762)
	nLog("升级亮光-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
	end

	x,y = findMultiColorInRegionFuzzy( 0xb4b5b5, "12|0|0xb2b3b3,12|5|0xb4b5b5,24|-2|0xbbbcbc,35|1|0xb0b0b0,555|-64|0x66c3f5,651|-74|0xbe1c32", 90, 419, 1, 1204, 154)
	nLog("目标任务页-x="..x)
	if x > -1 then		
		while (true) do
			x,y = findMultiColorInRegionFuzzy( 0x78603c, "134|1|0x755b43,2|39|0xa68c59,133|40|0xa58c5a,72|23|0xf4f3f1,68|19|0x977b52", 90, 1074, 156, 1238, 608)
			if x > -1 then
				tap_and_sleep(x,y);
			else
				break
			end
		end
		
		x,y = findMultiColorInRegionFuzzy( 0x38608b, "42|-70|0x4dc150,-473|-7|0xa9aaab,-446|-12|0xa4a6a8,-434|-13|0xb9b9b9,-406|-10|0x919395,-359|-9|0xbebebf", 90, 473, 231, 1263, 380)
		nLog("新兵指导任务-x="..x)
		if x > -1 then
			tap_and_sleep(x,y);
			mSleep(1000)
			tap_and_sleep(  535,  392);--点击学士塔
			mSleep(2000);
			tap_and_sleep( 1022,  367);--点击基础兵种
			mSleep(1000);
			tap_and_sleep(  166,  411);--新兵指导
			mSleep(1000);
			tap_and_sleep( 1072,  645);
			mSleep(1000);
			tap_and_sleep( 1150,   120);
			mSleep(1000);
			tap_and_sleep( 1242,   71);
			
		end	
		
		
		if isColor(  1198,  193, 0x886d49) then --领取
			tap_and_sleep(1198,193);
		elseif 	isColor(  1198,  264, 0x886d49) then
			tap_and_sleep(1198,  264);
		elseif 	isColor(  1198,  338, 0x886d49) then
			tap_and_sleep(1198,  338);
		elseif 	isColor(  1198,  410, 0x886d49) then
			tap_and_sleep(1198,  410);	
		elseif 	isColor(  1198,  481, 0x886d49) then
			tap_and_sleep(1198,  481);	
		elseif 	isColor(  1198,  553, 0x886d49) then
			tap_and_sleep(1198,  553);	
		elseif 	isColor(  1208,  683, 0x886d49) then
			tap_and_sleep(1208,  683);	
		else 
			if isColor(  1198,  193, 0x335981) then --前往
				tap_and_sleep(1198,193);
			elseif 	isColor(  1198,  264, 0x335981) then
				tap_and_sleep(1198,  264);
			elseif 	isColor(  1198,  338, 0x335981) then
				tap_and_sleep(1198,  338);
			elseif 	isColor(  1198,  410, 0x335981) then
				x,y = findMultiColorInRegionFuzzy( 0xb5b6b6, "10|-2|0xa8aaad,40|-6|0xa7a8a8,39|1|0x888a8b,50|-3|0xadadaf,51|-4|0xabacad,59|-3|0xb3b4b5,71|-5|0xb3b4b5,97|2|0x87898b", 90, 631, 386, 759, 423)
				nLog("护盾-x="..x)
				if x > -1 then
					tap_and_sleep(1198,  410);	
					mSleep(1000);
					tap_and_sleep( 1253,  302);
					mSleep(1000);
					tap_and_sleep( 1056,  402);--查看
					mSleep(1000);
					tap_and_sleep( 1054,  291);--使用
					mSleep(1000);
					tap_and_sleep(1150,120);--关闭
					mSleep(1000);
					tap_and_sleep(1240,70);--关闭
				else
					tap_and_sleep(1198,  410);	
				end
			elseif 	isColor(  1198,  481, 0x335981) then
				x,y = findMultiColorInRegionFuzzy( 0xb2b3b4, "0|4|0xb4b6b6,20|4|0xa5a7a7,36|3|0xb9b9b9,61|10|0xc4c5c5,61|6|0xc5c6c6,58|2|0xb2b3b3", 90, 533, 458, 621, 495)
				nLog("击溃叛军-x="..x)
				
				tap_and_sleep(1198,  481);	
			elseif 	isColor(  1198,  553, 0x335981) then
				tap_and_sleep(1198,  553);	
			elseif 	isColor(  1208,  683, 0x335981) then
				tap_and_sleep(1208,  683);	
			end
		end
		--return
	end

		
	x,y = findMultiColorInRegionFuzzy( 0xb87150, "18|20|0xc87d43,-5|27|0xd58c4c,18|5|0xffffff,-2|14|0xffffff,6|21|0xffffff", 85, 1197, 588, 1266, 656)
	nLog("完成任务的颜色-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
		tap_and_sleep(x,y)
		mSleep(1000)
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xe3c495, "-87|311|0xdb6152,-32|288|0xa72f1e,-14|164|0x51160f,-56|18|0x684f36", 90, 974, 124, 1206, 643)
	nLog("首充-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
		mSleep(1000)
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xc16144, "-2|3|0xba594d,137|11|0xbcdcff,9|87|0xf5cbac,199|-3|0x905150,-72|98|0xad5f51", 90, 416, 296, 832, 594)
	nLog("兵营-x="..x)
	--兵营
	if x > -1 then
		tap_and_sleep(x,y);
		mSleep(5000)
		index = math.random(1,2);
		if index == 1 then
			tap_and_sleep(  882,  381)--点击亲戚手
		else
			tap_and_sleep(   1194,  383)--点击长弓兵
		end
		
		mSleep(1000)
		tap_and_sleep( 1189,  680)--点击训练
		mSleep(1500)
		tap_and_sleep( 1211,  674)--点击加速
		mSleep(1000)
		tap_and_sleep(  972,  326);--点击一键加速
		tap_and_sleep( 1150,   120);
		tap_and_sleep( 1242,   71);
		
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfafafa, "-11|-3|0xf7f7f8,17|-2|0xf6f6f6,27|6|0xfefefe,328|2|0xb1b2b2,327|2|0xb4b5b5,298|-1|0xb2b3b3,238|-2|0xaeb0b0", 90, 2, 33, 614, 102)
	nLog("商城页-x="..x)
	if x > -1 then
		tap_and_sleep( 1242,   71);
		
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfffbe2, "17|18|0xfff6c3,61|44|0xebd090,58|67|0xe3c88a,55|57|0xeacc8f,56|79|0xe1c689", 90, 102, 231, 1142, 416)
	nLog("指挥官-x="..x)
	if x > -1 then
		tap_and_sleep( x, y);
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xffffd1, "9|11|0xffffc7,54|50|0xe8ca8e,52|54|0xe5c98b,49|58|0xe5c98c,29|18|0xffffb4", 90, 15, 107, 231, 264)
	nLog("快速选择-x="..x)
	if x > -1 then
		tap_and_sleep( x, y);
	end		
	
	x,y = findMultiColorInRegionFuzzy( 0xfcf8ce, "2|2|0xfbf9cb,4|4|0xfffcc9,6|6|0xfffcca,9|8|0xfefdca,37|25|0xffedb5,36|38|0xffe7a4", 90, 1007, 637, 1244, 755)
	nLog("出征-x="..x)
	if x > -1 then
		tap_and_sleep( x, y);
	end		
	
	
	x,y = findMultiColorInRegionFuzzy( 0xb4a17c, "-5|8|0xbda981,0|10|0xb3a07b,11|10|0xc2ae85,32|-4|0xbaa67f,32|5|0xbaa780,38|10|0xc2ae85", 90, 606, 92, 685, 147)
	nLog("商店-x="..x)
	if x > -1 then
		x,y = findMultiColorInRegionFuzzy( 0xf3e29e, "12|8|0xddc58d,3|8|0x9b7a4b,0|36|0x775644,24|17|0xad8f66,38|16|0xaf8e69,18|2|0xe3c98d,19|32|0x7c614a", 90, 158, 301, 232, 384)
		nLog("一件加速-x="..x);
		if x > -1 then
			tap_and_sleep( 1023,  337);--点击一键加速
			mSleep(1000);
			x,y = findMultiColorInRegionFuzzy( 0xb8a47e, "4|0|0xb7a37d,4|-3|0xb4a17b,21|-5|0xbaa77f,57|3|0xc2af85", 90, 572, 120, 704, 162)
			nLog("加速对话框-x="..x)
			if x > -1 then
				tap_and_sleep(  778,  620);--点击确定
				mSleep(1000);
			end


			tap_and_sleep(1150,120);--点击关闭
			--mSleep(1000);
			--tap_and_sleep(1240,70);--点击关闭

		else
			tap_and_sleep(1150, 120); --关闭页面
			tap_and_sleep(1242,  70);--点击关闭
			tap_and_sleep(1242,  70);--点击关闭
			
		end
	end

	
	x,y = findMultiColorInRegionFuzzy( 0xe9c695, "8|-9|0xeccb8a,-10|-9|0xeacb8f,-11|10|0xcaa976,9|10|0xccab77", 90, 1215, 35, 1271, 102)
	--如果上面的操作都没找到  点击x
	if x > -1 then
		tap_and_sleep(x,y)
	end
end





while (true) do
	upgrade();
end