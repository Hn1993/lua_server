--游戏配置文件
require("TSLib") -- 导入TS LIB库

function ToStringEx(value)
    if type(value)=='table' then
       return TableToStr(value)
    elseif type(value)=='string' then
        return "\'"..value.."\'"
    else
       return tostring(value)
    end
end
--table 转 String
function tableToStr(t)
    if t == nil then return "" end
    local retstr= "{"

    local i = 1
    for key,value in pairs(t) do
        local signal = ","
        if i==1 then
          signal = ""
        end

        if key == i then
            retstr = retstr..signal..ToStringEx(value)
        else
            if type(key)=='number' or type(key) == 'string' then
                retstr = retstr..signal..'['..ToStringEx(key).."]="..ToStringEx(value)
            else
                if type(key)=='userdata' then
                    retstr = retstr..signal.."*s"..TableToStr(getmetatable(key)).."*e".."="..ToStringEx(value)
                else
                    retstr = retstr..signal..key.."="..ToStringEx(value)
                end
            end
        end

        i = i+1
    end

     retstr = retstr.."}"
     return retstr
end
--string 2 table
function strToTable(str)
    if str == nil or type(str) ~= "string" then
        return
    end
    
    return loadstring("return " .. str)()
end


--读取 配置文件
function get_config_data(...)
	-- body
	local config = io.open(userPath().."/res/config/config_qiji.txt", "r")
	if config ~= nil then 
		local str = config:read("*a")
		config:close()
		table = strToTable(str);
		return table
	else
		return nil
	end
end
--存取 配置文件
function save_config_data(table)
	-- body
	os.execute("mkdir "..userPath().."/res/config");
	writeFileString(userPath().."/res/config/config_qiji.txt",tableToStr(table),"w");
end
--删除 配置文件
function delete_config_data(...)
	-- body
	if isFileExist(userPath().."/res/config/config_qiji.txt") == true then
		delFile(userPath().."/res/config/config_qiji.txt");
	end
end

--向现在的表里新增数据
function insert_into_table(key,value)
	-- body
	table_temp = {}
	if isFileExist(userPath().."/res/config/config_qiji.txt") == true then
		config_data = get_config_data();
		if config_data ~= nil then
			for k,v in pairs(config_data) do
				table_temp[k] = v
			end
		end
	end	

	table_temp[key] = value;
	save_config_data(table_temp);
end
--从当前存储的文件里找到某个key
function find_value_from_table(key)
	-- body
	table_config = get_config_data();
	if table_config ~= nil then
		if table_config[key] ~= nil then
			return table_config[key];
		end
	end	 
end

--判断文件是否存在
function isFile_exist(path)
	-- body
	local file = io.open(path, "rb")
	if file then 
		file:close() 
		return true
	else
		return false
	end
end