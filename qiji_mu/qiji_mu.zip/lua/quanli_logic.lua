require("TSLib") -- 导入TS LIB库
require("quanli_page") -- 导入TS LIB库
require("quanli_config_data")
require("hongdian")
require("hongdian2")

build_soldier_time = 0;--造兵开始时间
mining_type = 0;--采集类型
is_mining = false;-- 是否在采集中
is_building = false;-- 是否在造兵中
is_zoom = false;-- 是否在造兵中

guide_find_index=0;
guide_finished = false;
fight_rebels_task = false;--击溃叛军任务
look_team_time = 0;--查看队列总览时间

function game_start(...)
	
	while (true) do
		--dialog_tap();
		
		--guide_finger_tap();
		
		being_attacked();
		dialog_tap2();
		mining_task();
		-- 15
		
		page = get_page(page_list);
		nLog("page="..page)
		if page == "游戏登录页" then
			if find_value_from_table('is_level_6') ~= nil and find_value_from_table('is_level_6') == true then
				choice = dialogRet("清空配置文件：", "确定", "取消", "", 0);
				if choice == 0 then      
					toast("清空成功",1)
					mSleep(1000);
					insert_into_table("is_level_6",false);
				elseif choice == 1 then  
					toast("取消清空",1)
					mSleep(1000);
				end
			end
			
			tap_and_sleep( 960, 600); --点击开始游戏
		elseif page == "游戏建兵页" or page == "游戏建兵页2" or page == "游戏建兵页3" or page == "游戏建兵页4" then
			
			while (true) do
				if isColor(  976,  691, 0xfc4646 )  == false or isColor( 1199,  670, 0x3d7140) then
					mSleep(2000);
					tap_and_sleep(    706,  366); --点击轻步兵
					tap_and_sleep(    706,  366); --点击轻步兵
					mSleep(2000);
					--tap_and_sleep(  1142,  680); --点击训练	
					tap_and_sleep(  1142,  680); --点击训练	
				else
					tap_and_sleep(  1214,  691);--点击加速
					mSleep(1000)
				end

				x,y = findMultiColorInRegionFuzzy( 0xb16b13, "-45|72|0x99312c,1|54|0x4d7b45,70|72|0x417596,16|70|0x4d7c44,-45|92|0x99312c", 90, 20, 100, 206, 258)
				nLog("兵营-训练x="..x);
				mSleep(1000)
				if x > -1 then
					x,y = findMultiColorInRegionFuzzy( 0xecca97, "11|-10|0xe3c384,11|24|0xfffdbb,29|7|0xf1e2a1,1|16|0xfcf6b1", 90, 805, 548, 899, 614)
					nLog("造兵的材料不够-x="..x)
					if x > -1 then
						tap_and_sleep(1242,   70);--点击关闭
						build_soldier_time = getNetTime();
						break
					else
						tap_and_sleep( 1157,  682);--点击训练
					end

				end

				x,y = findMultiColorInRegionFuzzy( 0xbba780, "-1|8|0xc2ae85,0|6|0xc1ad84,-212|318|0x735a3c,-212|359|0xa48b59,-12|320|0x755c3c,309|321|0x995b34,62|11|0xb8a67f", 90, 290, 176, 995, 636)
				nLog("提示消息对话框-x="..x)
				if x > -1 then
					tap_and_sleep(  482,  556);--点击加速当前队列
					mSleep(2000)
				end
				
				
				x,y = findMultiColorInRegionFuzzy( 0xb4a17c, "-5|8|0xbda981,0|10|0xb3a07b,11|10|0xc2ae85,32|-4|0xbaa67f,32|5|0xbaa780,38|10|0xc2ae85", 90, 606, 92, 685, 147)
				nLog("商店-x="..x)
				if x > -1 then
					x,y = findMultiColorInRegionFuzzy( 0xf3e29e, "12|8|0xddc58d,3|8|0x9b7a4b,0|36|0x775644,24|17|0xad8f66,38|16|0xaf8e69,18|2|0xe3c98d,19|32|0x7c614a", 90, 158, 301, 232, 384)
					nLog("一件加速-x="..x);
					if x > -1 then
						tap_and_sleep( 1023,  337);--点击一键加速
						mSleep(1000);
						x,y = findMultiColorInRegionFuzzy( 0xb8a47e, "4|0|0xb7a37d,4|-3|0xb4a17b,21|-5|0xbaa77f,57|3|0xc2af85", 90, 572, 120, 704, 162)
						nLog("加速对话框-x="..x)
						if x > -1 then
							tap_and_sleep(  778,  620);--点击确定
							mSleep(1000);
						end
						
						
						tap_and_sleep(1150,120);--点击关闭
						--mSleep(1000);
						--tap_and_sleep(1240,70);--点击关闭

					else
						tap_and_sleep(1150, 120); --关闭页面
						tap_and_sleep(1242,  70);--点击关闭
						tap_and_sleep(1242,  70);--点击关闭
						build_soldier_time = getNetTime();
						break
					end
				end
				
				


			end
			
			
		elseif page == "游戏首页" then
			
			x,y = findMultiColorInRegionFuzzy( 0x7b413a, "-2|3|0x82483f,-18|33|0x6e3c32,82|1|0x814438,47|-28|0x9f9e9e,51|-30|0xa8a9a9,75|-34|0x929494,140|-1|0x9d4e4f", 90, 257, 610, 484, 738)
			nLog("驻扎地-x="..x)
			if x > -1 then
				
			end
			
			if find_value_from_table('is_level_6') == nil or find_value_from_table('is_level_6') == false then
				nLog("is_level_6=false")
				upgrade_6_level();
				mSleep(10 * 1000);
			end
			
			local duilie = ocrText(68, 542, 85, 555,0);
			if isColor (33,  564, 0x457a43)  and isColor (   75,  573, 0x45884d) and duilie ~= nil and tostring(duilie) ~= "1" then
				nLog("时间间隔="..(getNetTime() - build_soldier_time))
				nLog("is_zoom="..tostring(is_zoom))
				level = find_value_from_table('is_level_6');
				if level ~= nil and level == true then
					if getNetTime() - build_soldier_time > 15 * 60 then
						build_task();
					else
						set_clicked_false();
						mSleep(1000);
						red_point_click();--点击红点
					end
				end
			else
				tap_and_sleep(70,680);--出城
			end	
			
		end
		
	end
end

--受到攻击
function being_attacked(...)
	x,y = findMultiColorInRegionFuzzy( 0xffffff, "-23|-44|0xb72513,-5|-43|0xba2414,2|-11|0xffffff,20|-6|0xffffff,-1|-19|0xbb261e,17|-38|0xffffff", 90, 1142, 258, 1218, 340)
	nLog("受到攻击的图标-x="..x)
	if x > -1 then
		tap_and_sleep(   50,  573);
		mSleep(2000);
		while (true) do
			x,y = findMultiColorInRegionFuzzy( 0x365f89, "129|2|0x305279,2|35|0x3c6791,128|33|0x3e6890,69|14|0xecedee,80|19|0xf6f6f6", 90, 957, 146, 1139, 526)
			x1,y1 = findMultiColorInRegionFuzzy( 0x365f89, "123|1|0x30547a,119|30|0x406c96,8|30|0x3a638d,49|16|0xeaeaec,59|18|0xe8e9ea,61|32|0x5a8dbd", 90, 969, 159, 1110, 494)
			if x > -1 then
				tap_and_sleep(x,y);
				mSleep(2000);
				x,y = findMultiColorInRegionFuzzy( 0x8c724b, "-10|6|0xf9f9f9,-100|-16|0x755c3f,-101|22|0xa68e5b,100|-17|0x745b3c,95|18|0xa58a59,-113|-339|0xbfaa83,-200|-322|0xc5b187", 90, 271, 162, 987, 641)
				if x > -1 then
					tap_and_sleep(x,y)
				end
			elseif x1 > -1 then
				tap_and_sleep(x1,y1);
				mSleep(2000);
				x,y = findMultiColorInRegionFuzzy( 0x8c724b, "-10|6|0xf9f9f9,-100|-16|0x755c3f,-101|22|0xa68e5b,100|-17|0x745b3c,95|18|0xa58a59,-113|-339|0xbfaa83,-200|-322|0xc5b187", 90, 271, 162, 987, 641)
				if x > -1 then
					tap_and_sleep(x,y)
				end
			else
				tap_and_sleep(1150,120);--点击关闭
				break
			end
		end
	end
end

--  升级 主堡，兵营的固定操作
function upgrade_build(...)
	::start_task::
	tap_and_sleep(640,400);--点击中心
	mSleep(1000);
	tap_and_sleep(312,693);--点击升级
	mSleep(1000);
	
	x,y = findMultiColorInRegionFuzzy( 0x755840, "4|44|0xa48b59,468|2|0x543776,470|45|0x664893,337|10|0x5aaedb,96|15|0xefefee,361|12|0xcecdd4", 90, 47, 652, 567, 730)
	-- 升级 ，免费升级
	if x > -1 then
		tap_and_sleep(  547,  716);--点击免费升级
		tap_and_sleep(1240,70);--点击关闭
	else
		
		x,y = findMultiColorInRegionFuzzy( 0x72593c, "0|42|0xa48b59,460|2|0x9d5b33,465|41|0xc17445,87|18|0xeae9e8,93|18|0xe8e8e7,104|17|0xdedcda,112|18|0xe8e6e4", 90, 62, 655, 560, 728)
		if x > -1 then --升级  钻石升级
			x,y = findMultiColorInRegionFuzzy( 0x366088, "0|22|0x3d6790,97|-1|0x2d5479,99|20|0x3e6993,32|9|0xe3e4e5,39|11|0xe5e6e7,57|10|0xf3f3f3,64|10|0xeeeff0", 90, 1123, 422, 1244, 549)--前往
			if x > -1 then --某个任务没完成
				tap_and_sleep(x,y);--点击前往
				goto start_task
			else
				tap_and_sleep(  203,  685);--点击升级
				if isColor(  536,  673, 0x3c7140) then
					tap_and_sleep(  536,  673);--点击加速
					mSleep(2000)
					x,y = findMultiColorInRegionFuzzy( 0xf3e29e, "12|8|0xddc58d,3|8|0x9b7a4b,0|36|0x775644,24|17|0xad8f66,38|16|0xaf8e69,18|2|0xe3c98d,19|32|0x7c614a", 90, 158, 301, 232, 384)
					nLog("一件加速-x="..x);
					if x > -1 then
						tap_and_sleep( 1023,  337);--点击一键加速
						mSleep(1000);
						tap_and_sleep(  778,  620);--点击确定
						mSleep(1000);
						tap_and_sleep(1150,120);--点击关闭
						mSleep(1000);
						tap_and_sleep(1240,70);--点击关闭
					end
					
				end
				
				
				tap_and_sleep(1240,70);--点击关闭
			end
		end
		
	end
	
	
end


--升级到6
function upgrade_6_level(...)
	nLog("upgrade_6_level")
	randomTap( 1266,  788);
	
	if find_value_from_table('guide_finished') == nil then
		if guide_find_index > 10 then
			x, y = findColorInRegionFuzzy(0xffd155, 98, 0, 0, 1280, 800); --手指箭头
			nLog("for 中间向下的箭头-x="..x.."-y="..y)
			if x > -1 then
				tap_and_sleep(x,y);
				guide_find_index = 0;
				return
			end
		end
	end

	
	x, y = findColorInRegionFuzzy(0xffd155, 99, 0, 0, 1280, 800); --手指箭头
	nLog("中间向下的箭头-x="..x.."-y="..y)
	if x > -1 and find_value_from_table('guide_finished') == nil then
		if isColor(x,y+20,0xffffff) == false then
			tap_and_sleep(x,y);
			guide_find_index = 0;
			return
		end
	else
		guide_find_index = guide_find_index + 1;
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xbba780, "-1|7|0xc1ac84,36|7|0xbca780,62|7|0xb8a67f,42|180|0xbd3233,194|181|0xd4d4d4,246|181|0xc8c8c9,68|179|0xbe3132", 90, 417, 178, 961, 617)
	nLog("7级主堡的升级提示-x="..x)
	if x > -1 then
		tap_and_sleep(  822,  543);--点击确定
		return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xc7b284, "-4|-11|0xd8c293,30|-5|0x11191a,14|-7|0xcfbe92,23|16|0xb69a6d,24|-9|0xd7bf90,-16|-9|0x162026", 90, 2, 621, 125, 753)
	nLog("出城-x="..x)-- 在城内  造兵
	if x > -1 then
		
		being_attacked();
		
		if find_value_from_table('guide_finished') ~= nil and find_value_from_table('guide_finished') == true then
			x,y = findMultiColorInRegionFuzzy( 0x7b413a, "-2|3|0x82483f,-18|33|0x6e3c32,82|1|0x814438,47|-28|0x9f9e9e,51|-30|0xa8a9a9,75|-34|0x929494,140|-1|0x9d4e4f", 90, 257, 610, 484, 738)
			nLog("驻扎地-x="..x)
			if x > -1 then
				 -- 613,  401
				if find_value_from_table('qishen') == nil or find_value_from_table('qishen') == false then
					tap_and_sleep(  613,  401);--点击七神殿堂
					mSleep(2000);
					x,y = findMultiColorInRegionFuzzy( 0xfafafa, "0|8|0xf9f9f9,23|2|0xf4f4f4,34|1|0xeaebeb,58|-1|0xfbfbfb,86|8|0xfcfcfc,129|77|0xeffbef,45|68|0xd4e0e5", 90, 4, 35, 293, 166)
					if x > -1 then
						while (true) do
							x,y = findMultiColorInRegionFuzzy( 0x5d3e85, "1|44|0x654891,205|1|0x543776,206|43|0x684995,91|22|0xfafafa,110|16|0xe7e6e9,114|17|0xeae9eb,86|18|0xf2f1f4", 90, 35, 630, 1243, 737)
							if x > -1 then
								tap_and_sleep(x+20,y+20);
								tap_and_sleep(849,643);
								insert_into_table("qishen",true);
							else
								break
							end
						end
					end
				end
			else
				tap_and_sleep(70,680); --出城
				tap_and_sleep(70,680); --出城
				tap_and_sleep(70,680); --出城
			end
		end
	
		x,y = findMultiColorInRegionFuzzy( 0xfffecb, "0|-85|0xe3c78a,-10|-75|0xe9cc8c,14|-68|0xedd191,1|-47|0xfbe3a1,9|-47|0xfbe3a1,-8|-39|0xffeaa8", 90, 488, 303, 726, 466)
		nLog("111111111111-x="..x);
		if x > -1 then
			tap_and_sleep(x,y)
		end
		
		
		
		
		if getNetTime() - build_soldier_time > 15 * 60 then
			x,y = findMultiColorInRegionFuzzy( 0x7b413a, "-2|3|0x82483f,-18|33|0x6e3c32,82|1|0x814438,47|-28|0x9f9e9e,51|-30|0xa8a9a9,75|-34|0x929494,140|-1|0x9d4e4f", 90, 257, 610, 484, 738)
			nLog("驻扎地-x="..x)
			if x > -1 then
			--1.增加兵营一直造兵功能
			tap_and_sleep(  460,  446);
			mSleep(15 * 1000);

			while (true) do
				x,y = findMultiColorInRegionFuzzy( 0xf3f3f3, "12|3|0xfafafa,6|-5|0xf6f6f6,36|-6|0xfafafa,436|276|0x9fc9f5,137|608|0x816744", 90, 45, 34, 593, 751)
				nLog("兵营-选兵种页-x="..x)
				if x > -1 then
					if isColor(  976,  691, 0xfc4646 )  == false or isColor( 1199,  670, 0x3d7140) then
						mSleep(2000);
						tap_and_sleep(    706,  366); --点击轻步兵
						tap_and_sleep(    706,  366); --点击轻步兵
						mSleep(2000);
						--tap_and_sleep(  1142,  680); --点击训练	
						tap_and_sleep(  1142,  680); --点击训练	
					else
						tap_and_sleep(  1214,  691);--点击加速
						mSleep(1000)
					end

				end


				x,y = findMultiColorInRegionFuzzy( 0xb16b13, "-45|72|0x99312c,1|54|0x4d7b45,70|72|0x417596,16|70|0x4d7c44,-45|92|0x99312c", 90, 20, 100, 206, 258)
				nLog("兵营-训练x="..x);
				mSleep(1000)
				if x > -1 then
					x,y = findMultiColorInRegionFuzzy( 0xecca97, "11|-10|0xe3c384,11|24|0xfffdbb,29|7|0xf1e2a1,1|16|0xfcf6b1", 90, 805, 548, 899, 614)
					nLog("造兵的材料不够-x="..x)
					if x > -1 then
						tap_and_sleep(1242,   70);--点击关闭
						build_soldier_time = getNetTime();
						break
					else
						tap_and_sleep( 1157,  682);--点击训练
					end

				end

				x,y = findMultiColorInRegionFuzzy( 0xbba780, "-1|8|0xc2ae85,0|6|0xc1ad84,-212|318|0x735a3c,-212|359|0xa48b59,-12|320|0x755c3c,309|321|0x995b34,62|11|0xb8a67f", 90, 290, 176, 995, 636)
				nLog("提示消息对话框-x="..x)
				if x > -1 then
					tap_and_sleep(  482,  556);--点击加速当前队列
					mSleep(2000)
				end


				x,y = findMultiColorInRegionFuzzy( 0xb4a17c, "-5|8|0xbda981,0|10|0xb3a07b,11|10|0xc2ae85,32|-4|0xbaa67f,32|5|0xbaa780,38|10|0xc2ae85", 90, 606, 92, 685, 147)
				nLog("商店-x="..x)
				if x > -1 then
					x,y = findMultiColorInRegionFuzzy( 0xf3e29e, "12|8|0xddc58d,3|8|0x9b7a4b,0|36|0x775644,24|17|0xad8f66,38|16|0xaf8e69,18|2|0xe3c98d,19|32|0x7c614a", 90, 158, 301, 232, 384)
					nLog("一件加速-x="..x);
					if x > -1 then
						tap_and_sleep( 1023,  337);--点击一键加速
						mSleep(1000);
						x,y = findMultiColorInRegionFuzzy( 0xb8a47e, "4|0|0xb7a37d,4|-3|0xb4a17b,21|-5|0xbaa77f,57|3|0xc2af85", 90, 572, 120, 704, 162)
						nLog("加速对话框-x="..x)
						if x > -1 then
							tap_and_sleep(  778,  620);--点击确定
							mSleep(1000);
						end
						
						--如果有免费，点击
						if isColor(  940,  230, 0x674687 ) or isColor( 1033,  254, 0xfcf9ce) then
							tap_and_sleep( 1033,  254)
						end

						tap_and_sleep(1150,120);--点击关闭
						--mSleep(1000);
						--tap_and_sleep(1240,70);--点击关闭

					else
						tap_and_sleep(1150, 120); --关闭页面
						tap_and_sleep(1242,  70);--点击关闭
						tap_and_sleep(1242,  70);--点击关闭
						build_soldier_time = getNetTime();
						break
					end
				end



			end
		end
		
		end
		
		
		if isColor(  22,  241, 0x835da0 ) then --第一个建筑队列颜色为免费
			tap_and_sleep(22,  241); --点击第一个免费
		end
		
		
		
		-- isColor(  19,  488, 0x44884e,90) or
		if  isColor( 25,  406, 0x42874b,90) or isColor(25,  324, 0x1c262b ,90) == false or isColor(   25,  241, 0x4a8b5a ,90) then
			nLog("有升级主堡任务在队列中-x="..x)
			if find_value_from_table('guide_finished') ~= nil and find_value_from_table('guide_finished') == true then
				if isColor (33,  564, 0x468559) == false and isColor (   75,  573, 0x4f905f) == false then
					tap_and_sleep(70,680); --出城
					mSleep(1000)
					return
				end	
				
				-- 红点
				set_red_point_clicked();
				mSleep(1000);
				click_red_point();
				
				
			
				while (true) do
					x,y = findMultiColorInRegionFuzzy( 0xffffff, "19|-9|0xffffff,10|-20|0xaf603d,-12|-2|0xd08955,28|-1|0xcd8758,11|16|0xdc9960,-26|7|0x995037", 90, 1017, 514, 1265, 579)
					if x> -1 then
						tap_and_sleep(x,y);--领取完成任务的奖励
						mSleep(1000)
					else
						break;
					end	
				end
				
				if isColor (   24,  488, 0x468953) and isColor (   77,  488, 0x3f854c) then --判断队列总览是不是绿色
					
					if getNetTime() - look_team_time > 20 * 60  then
						
						tap_and_sleep(50,  488); --点击队列
						mSleep(1000);
						look_team_time = getNetTime();
						x,y = findMultiColorInRegionFuzzy( 0xe2e2e3, "17|2|0xf6f6f6,16|2|0xeaeaeb,16|-2|0xe0e0e0,59|-5|0xe6e6e7,51|5|0xbebebf,64|-5|0xd1d1d1,0|6|0xdadada", 90, 162, 277, 255, 307)
						nLog("任务完成-x="..x);
						if x > -1 then
							tap_and_sleep(  561,  293);--点击前往
							mSleep(2000);
							tap_and_sleep(  147,  688);--领取奖励
							mSleep(1000);
							tap_and_sleep(1240,70);--点击关闭
							mSleep(2000)
							return
						else
							tap_and_sleep(1240,70);--点击关闭
							mSleep(2000)
						end
						
					end
					
				end	
				
				
			end
			
			return
			
			
		else
			--tap_and_sleep( 1232,  624);--点击接受任务
			if find_value_from_table('guide_finished') ~= nil and find_value_from_table('guide_finished') == true then
				tap_and_sleep(    751,  250);--点击主堡
			else
				tap_and_sleep( 1232,  624);--点击接受任务
			end
		end
	else
		x,y = findMultiColorInRegionFuzzy( 0xf0ceab, "16|-4|0xe3cf9f,31|0|0xd7ba90,35|16|0xb59772,30|29|0xa98866,15|36|0xa98865,0|32|0xb89f76", 90, 472, 663, 813, 734)
		nLog("更多的图标-x="..x)
		if x > -1 then
			
		else
			x,y = findMultiColorInRegionFuzzy( 0x838383, "22|-3|0x878787,21|-3|0x858585,21|2|0x848484,47|2|0x7f7f7f,62|3|0x868686", 93, 571, 707, 717, 742)
			nLog("点击屏幕继续-x="..x)
			if x > -1 then
				tap_and_sleep(x,y);
				return
			end
			
			x,y = findMultiColorInRegionFuzzy( 0x807f7f, "0|3|0x7e7e7e,20|5|0x858585,44|5|0x848484,44|9|0x848484,55|9|0x858585,79|2|0x6d6d6d,103|0|0x7e7e7e", 93, 563, 712, 725, 755)
			nLog("点击屏幕继续-x2="..x)
			if x > -1 then
				tap_and_sleep(x,y);
				return
			end

			x,y = findMultiColorInRegionFuzzy( 0x868686, "-5|9|0x777778,22|5|0x8e8e8e,22|13|0x878787,47|10|0x8c8c8c,110|-1|0x898989,90|4|0x8e8e8e", 97, 571, 690, 719, 728)
			nLog("点击屏幕继续-x3="..x)
			if x > -1 then
				tap_and_sleep(x,y);
				return
			end

			x,y = findMultiColorInRegionFuzzy( 0x7a7a7b, "0|2|0x7b7b7c,21|5|0x858585,20|0|0x838384,45|5|0x898989,84|4|0x8d8d8d,103|-1|0x828282", 93, 580, 692, 707, 719)
			nLog("点击屏幕继续-x4="..x)
			if x > -1 then
				tap_and_sleep(x,y);
				return
			end

			x,y = findMultiColorInRegionFuzzy( 0x797979, "1|8|0x7e7e7e,20|5|0x868686,20|12|0x818181,34|1|0x808080,60|9|0x7f7f7f,84|5|0x8d8d8d,103|0|0x818181", 90, 583, 683, 703, 707)
			nLog("点击屏幕继续-x5="..x)
			if x > -1 then
				tap_and_sleep(x,y);
				return
			end
		end
		
		x,y = findMultiColorInRegionFuzzy( 0xa6b3b5, "371|-11|0x3c4b61,12|8|0x303a49,21|140|0x283749,864|138|0x283849,862|8|0x2f3a49,485|156|0xa7aabc", 90, 50, 425, 988, 623)
		nLog("中间的阴影对话-x="..x)
		if x > -1 then
			tap_and_sleep(x,y);
			return
		end
		
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xa38a5e, "-47|-27|0xe6cd9f,-26|-40|0xe6d0a0,-13|-22|0x1a232e,11|-16|0x1b242e,-21|7|0xaa9063,-47|0|0xc4ab81", 90, 3, 629, 138, 758)
    nLog("回城-x="..x)-- 在城外  挖矿	
	if x > -1 then
		being_attacked();
		nLog("fight_rebels_task-x="..tostring(fight_rebels_task));
		if fight_rebels_task == true then	
			while (true) do
				if isColor (33,  564, 0x468559) == false and isColor (   75,  573, 0x4f905f) == false then
					tap_and_sleep(  365,  699);--点击搜索
					mSleep(1000);
					tap_and_sleep( 1033,  706);--点击搜索
					tap_and_sleep(640,400);--点击中心
					tap_and_sleep(640,400);--点击中心
					mSleep(1000);
					tap_and_sleep(  699,  599);--点击战斗
					mSleep(1 * 1000);
					tap_and_sleep(  903,  679);--点击快速选择
					mSleep(1000);
					tap_and_sleep( 1116,  687);--点击出征
					mSleep(10 * 1000);
					fight_rebels_task = false;
					break
				end
			end
			return
		end
		
		if find_value_from_table('guide_finished') ~= nil and find_value_from_table('guide_finished') == true then
			if isColor (33,  564, 0x468559) == false and isColor (   75,  573, 0x4f905f) == false then
				
				--x,y = findMultiColorInRegionFuzzy( 0xe7cea1, "20|-4|0xddc597,17|23|0xbfa577,46|27|0xa68b5e,334|43|0x9f8658,315|30|0x1f2a26", 90, 13, 614, 432, 749)
				::search2::
				x,y = findMultiColorInRegionFuzzy( 0xe6cda0, "20|-3|0xdcc496,33|6|0x222e37,43|27|0xa68c61,10|35|0xb1996c,20|-14|0xe8cda1", 90, 14, 627, 124, 752)
				nLog("回城 - 搜索-x="..x)
				if x > -1 then
					mSleep(2000);
					tap_and_sleep(  364,  699);--点击搜索图标
					mSleep(2000);
					--tap_and_sleep(  888,  573);--点击铁矿场
					--tap_and_sleep(  888,  573);--点击铁矿场
					local index = math.random(1,5);
					if index == 1 then
						x,y = findMultiColorInRegionFuzzy( 0x465635, "-16|17|0xbe6e4d,-18|27|0xeac8a6,-9|26|0xb97150,-16|66|0xe1b835,13|30|0x65552f,-13|34|0xfbf8ef,62|42|0x4e673e", 90, 142, 486, 1124, 666)
						nLog("农田-x="..x)
						if x > -1 then
							tap_and_sleep(x,y);
							tap_and_sleep(x,y);
						end
					elseif index == 2 then
						x,y = findMultiColorInRegionFuzzy( 0xe9d99c, "15|-7|0x766644,-3|-4|0xefde9f,7|-1|0xebdda4,-26|36|0x506938,-21|-2|0xfffefa,11|16|0xf1c097", 90, 407, 512, 1195, 655)
						nLog("伐木厂-x="..x)
						if x > -1 then
							tap_and_sleep(x,y);
							tap_and_sleep(x,y);
						end
					elseif 	index == 3 then
						x,y = findMultiColorInRegionFuzzy( 0xacacac, "20|-39|0xd3d3cc,44|1|0xc18f68,43|4|0xd09d74,46|3|0xd9a77d,13|16|0xe4e4e4,62|12|0xc5c5c0", 90, 397, 483, 1163, 670)
						nLog("采石厂-x="..x)
						if x > -1 then
							tap_and_sleep(x,y);
							tap_and_sleep(x,y);
						end
					elseif index == 4 then
						x,y = findMultiColorInRegionFuzzy( 0xcfcdde, "-20|26|0xe9e9f0,15|65|0x938c72,28|64|0x9f967e,9|36|0xe5b988", 90, 412, 496, 1206, 652)
						nLog("铁矿厂-x="..x)
						if x > -1 then
							tap_and_sleep(x,y);
							tap_and_sleep(x,y);
						end	
					else 
						x,y = findMultiColorInRegionFuzzy( 0xd7c765, "-1|1|0xcdbb58,25|-22|0xe9b18f,35|-29|0x684736,53|-26|0xecc852,66|-23|0xe6bb57,74|34|0xeaea84", 90, 142, 486, 1124, 666)
						nLog("铸币厂-x="..x)
						if x > -1 then
							tap_and_sleep(x,y);
							tap_and_sleep(x,y);
						end
					end
					
					mSleep(2000);
					
					local kuang_index = math.random(1,2);
					if kuang_index == 1 then					  
						tap_and_sleep(    402,  720);--选择3级旷   
					else
						tap_and_sleep(    575,  719);--选择4级旷 
					end
					
					mSleep(1000);
					tap_and_sleep( 1153,  718);--点击搜索
					mSleep(1000);
					tap_and_sleep(640,400);--点击中心
					tap_and_sleep(640,400);--点击中心
					mSleep(1000);
					--tap_and_sleep(  633,  540);--点击采集

					text = ocrText(702, 357, 796, 389, 0)
					--nLog("text="..text)
					if string.len(text) >= 6 then
						nLog("大于1W")
						x,y = findMultiColorInRegionFuzzy( 0xfbfbfb, "22|3|0xf8f8f7,11|-16|0x775e3f,-92|-22|0x73573d,115|-22|0x73563e,115|23|0xa98e5d,-92|21|0xa78653", 90, 516, 499, 777, 574)
						nLog("采集对话框-x="..x)
						if x > -1 then
							tap_and_sleep(  635,  533);--点击采集
						else
							
							goto search2
						end
				
						
						--tap_and_sleep(  635,  533);--点击采集
						mSleep(1500);

						x,y = findMultiColorInRegionFuzzy( 0xf0dfa7, "34|0|0xf7e6a3,17|-17|0xe4c483,17|17|0xfffcbb", 90, 190, 315, 267, 500)
						nLog("有兵-x="..x)
						if x > -1 then
							tap_and_sleep(  903,  679);--点击快速选择
							mSleep(1000);
							tap_and_sleep( 1116,  687);--点击出征
						else
							tap_and_sleep(1240,70)--点击关闭
							mSleep(1000);
							tap_and_sleep(70,680); --回城	
						end


					else
						nLog("goto search")
						goto search2;
					end

					return
					
					
					--[[duilie = ocrText(68, 542, 85, 555,0);
					if duilie ~= nil and duilie == "1" then
						
					else
						tap_and_sleep(70,680); --回城	
					end]]
					
				end
			else
				::search3::
				x,y = findMultiColorInRegionFuzzy( 0xa38a5e, "-47|-27|0xe6cd9f,-26|-40|0xe6d0a0,-13|-22|0x1a232e,11|-16|0x1b242e,-21|7|0xaa9063,-47|0|0xc4ab81", 90, 3, 629, 138, 758)
				nLog("回城-x="..x)-- 在城外  挖矿	
				if x > -1 then
					duilie = ocrText(68, 542, 85, 555,0);
					if duilie ~= nil and duilie == "1" then
						tap_and_sleep(  364,  699);--点击搜索图标
						mSleep(2000);
						--tap_and_sleep(  888,  573);--点击铁矿场
						--tap_and_sleep(  888,  573);--点击铁矿场
						local index = math.random(1,5);
						if index == 1 then
							x,y = findMultiColorInRegionFuzzy( 0x465635, "-16|17|0xbe6e4d,-18|27|0xeac8a6,-9|26|0xb97150,-16|66|0xe1b835,13|30|0x65552f,-13|34|0xfbf8ef,62|42|0x4e673e", 90, 142, 486, 1124, 666)
							nLog("农田-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);
								tap_and_sleep(x,y);
							end
						elseif index == 2 then
							x,y = findMultiColorInRegionFuzzy( 0xe9d99c, "15|-7|0x766644,-3|-4|0xefde9f,7|-1|0xebdda4,-26|36|0x506938,-21|-2|0xfffefa,11|16|0xf1c097", 90, 407, 512, 1195, 655)
							nLog("伐木厂-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);
								tap_and_sleep(x,y);
							end
						elseif 	index == 3 then
							x,y = findMultiColorInRegionFuzzy( 0xacacac, "20|-39|0xd3d3cc,44|1|0xc18f68,43|4|0xd09d74,46|3|0xd9a77d,13|16|0xe4e4e4,62|12|0xc5c5c0", 90, 397, 483, 1163, 670)
							nLog("采石厂-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);
								tap_and_sleep(x,y);
							end
						elseif index == 4 then
							x,y = findMultiColorInRegionFuzzy( 0xcfcdde, "-20|26|0xe9e9f0,15|65|0x938c72,28|64|0x9f967e,9|36|0xe5b988", 90, 412, 496, 1206, 652)
							nLog("铁矿厂-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);
								tap_and_sleep(x,y);
							end	
						else 
							x,y = findMultiColorInRegionFuzzy( 0xd7c765, "-1|1|0xcdbb58,25|-22|0xe9b18f,35|-29|0x684736,53|-26|0xecc852,66|-23|0xe6bb57,74|34|0xeaea84", 90, 142, 486, 1124, 666)
							nLog("铸币厂-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);
								tap_and_sleep(x,y);
							end
						end

						mSleep(2000);
						local kuang_index = math.random(1,2);
						if kuang_index == 1 then					  
							tap_and_sleep(    402,  720);--选择3级旷   
						else
							tap_and_sleep(    575,  719);--选择4级旷 
						end
						mSleep(1000);
						tap_and_sleep( 1153,  718);--点击搜索
						mSleep(1000);
						tap_and_sleep(640,400);--点击中心
						tap_and_sleep(640,400);--点击中心
						mSleep(1000);
						--tap_and_sleep(  633,  540);--点击采集

						text = ocrText(702, 357, 796, 389, 0)
						--nLog("text="..text)
						if string.len(text) >= 6 then
							nLog("大于1W")
							x,y = findMultiColorInRegionFuzzy( 0xfbfbfb, "22|3|0xf8f8f7,11|-16|0x775e3f,-92|-22|0x73573d,115|-22|0x73563e,115|23|0xa98e5d,-92|21|0xa78653", 90, 516, 499, 777, 574)
							nLog("采集对话框-x="..x)
							if x > -1 then
								tap_and_sleep(  635,  533);--点击采集\
							else
								goto search3
							end
							--tap_and_sleep(  635,  533);--点击采集
							mSleep(1500);

							x,y = findMultiColorInRegionFuzzy( 0xc2ae85, "1|-8|0xbba780,12|7|0xc4b086,36|8|0xc4b086,86|-4|0xbeaa83,-20|146|0xc8c8c8,-6|144|0xd5d5d6,-3|153|0xd4d4d4", 90, 293, 173, 984, 625)
							nLog("行军队列不足-x="..x)
							if x > -1 then
								tap_and_sleep(  956,  208);--关闭
								mSleep(1000);
								tap_and_sleep(  956,  208);--关闭
								mSleep(1000);
								tap_and_sleep(70,680); --回城	
							end

							x,y = findMultiColorInRegionFuzzy( 0xf0dfa7, "34|0|0xf7e6a3,17|-17|0xe4c483,17|17|0xfffcbb", 90, 190, 315, 267, 500)
							nLog("有兵-x="..x)
							if x > -1 then
								tap_and_sleep(  903,  679);--点击快速选择
								mSleep(1000);
								tap_and_sleep( 1116,  687);--点击出征
							else
								tap_and_sleep(1240,70)--点击关闭
								mSleep(1000);
								tap_and_sleep(70,680); --回城	
							end
						else
							goto search3;
						end	

						return
					elseif duilie ~= nil and duilie ~= "1" then
						tap_and_sleep(70,680); --回城	

					end
					
				end
				
				
				
			end	
		end
		
		x,y = findMultiColorInRegionFuzzy( 0xe5ca8c, "12|-3|0xe8cb8e,13|26|0xfae19d,29|26|0xffeaa8,42|40|0xfff7c6", 90, 724, 481, 927, 652)
		nLog("回城 - 任务-x="..x)
		if x > -1 then
			tap_and_sleep( 1088,  626);
			return
		end
		
		
		
		
		
		
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xe3c290, "-5|-5|0xefcd98,5|5|0xd0ae7d,-164|49|0xf7d7a6,-149|73|0xe7b26e,-114|43|0xefd7b6,-96|85|0xb88653,-92|52|0xdec6a7", 90, 791, 101, 1148, 260)
	nLog("战损补给对话框-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xdadbdc, "32|-2|0x38628a,-87|-19|0x365f89,117|21|0x406a92,-413|-17|0xfff8c9,-307|-15|0x775c3f,-420|10|0xe9e7e5,-481|-16|0x765d3f", 90, 263, 576, 980, 676)
	nLog("确认对话框-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
		return
	end	
	
	x,y = findMultiColorInRegionFuzzy( 0xe2c18e, "4|5|0xd9b887,-4|5|0xdab877,-6|-5|0xeccb97,-67|21|0x5c1d13,-91|20|0xfbdd97", 90, 969, 102, 1147, 211)
	nLog("广告的X-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xe2bf8d, "4|-4|0xecc98b,-6|-6|0xf0ce96,-6|6|0xd7b583,6|6|0xd6b481,-6|6|0xd7b583", 90, 1106, 197, 1161, 247)
	nLog("广告的X-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfdfccb, "-9|-72|0xecd191,8|-75|0xe8cd8e,0|-75|0xeace91,-6|-44|0xffe9a6,2|-50|0xfbe49f,17|-56|0xf9de9c,-26|-69|0xefce94", 90, 354, 547, 548, 728)
	nLog("免费建造的手指-x="..x)
	if x > -1 then
		tap_and_sleep( x,  y);
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xe3c98a, "7|20|0xeed593,33|42|0xfff1c1,54|49|0xfffbca,14|-3|0xe8cc8c,-9|24|0xeecc98,31|25|0xffe7a5", 90, 708, 497, 853, 629)
	nLog("任务提示那里的手指-x="..x)
	if x > -1 then
		tap_and_sleep( 1236,  622);
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xe3c88a, "-3|-13|0xe1c689,4|14|0xecd191,35|5|0xfdde99,48|42|0xffffc7,30|36|0xffffb3", 90, 760, 515, 1002, 692)
	nLog("任务提示那里的手指-x2="..x)
	if x > -1 then
		tap_and_sleep( 1236,  622);
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfef6c5, "-7|-63|0xe9ce91,-6|-45|0xf8de9a,6|-42|0xf9df9d,16|-48|0xf4da98,9|-84|0xe2c38d,-12|-66|0xe8ce90", 90, 481, 278, 726, 541)
	nLog("升级主堡那里的手指-x2="..x)
	if x > -1 then
		tap_and_sleep(  599,  436);
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xfdf2ce, "40|-9|0xf5edd3,65|-2|0xfaedcb,87|-4|0xeae2c0,135|0|0xd6cdab,174|-7|0xf3ebc9", 90, 1033, 12, 1265, 77)
	nLog("点击跳过-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfce49f, "60|-5|0xd9c98b,80|-2|0xdac588,160|-5|0xd5c58c,125|2|0xb7a780", 90, 1041, 56, 1253, 110)
	nLog("点击跳过2-x="..x)
	if x > -1 then
		tap_and_sleep(x,y)
		return
	end

	x,y = findMultiColorInRegionFuzzy( 0xb462dd, "40|117|0xad8473,121|29|0xc3a397,198|-7|0x7f878e,40|226|0x98764e,38|259|0x442f1d", 90, 492, 178, 779, 517) -- 解锁指挥官
	nLog("解锁指挥官A-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xb2b3b3, "6|1|0xa2a3a3,22|2|0xb6b7b7,22|-3|0xb8b9b9,88|-3|0xa7a8a8,128|4|0xbcbdbd,151|1|0xbbbcbc,150|2|0xb8b8b8", 93, 549, 695, 735, 733)
	nLog("点击任意位置关闭-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x8c8870, "20|1|0x8c8870,19|5|0x8a876f,42|6|0x8d8871,64|4|0x87836a,124|7|0x979379,159|0|0x847f69", 93, 528, 677, 756, 704)
	nLog("点击任意位置解锁指挥官-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
	end




	--[[x, y = findColorInRegionFuzzy(0x455465 , 100, 0, 0, 1280, 800); --提示框内的颜色值
	nLog("提示框内的颜色值-x="..x.."y="..y)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end]]



	--x1, y1 = findColorInRegionFuzzy(0xfefeca, 100, 0, 0, 1280, 800); --手指箭头
	x1, y1 = findColorInRegionFuzzy(0xfada99, 100, 0, 0, 1280, 800); --手指箭头
	nLog("中间向下的箭头-x1="..x1.."y1="..y1)
	if x1 > -1 then
		if isColor(x,y+20,0xffffff) == false then
			tap_and_sleep(x1,y1);
			return
		end
		
		
	end
	
	--[[x2, y2 = findColorInRegionFuzzy(0xc6b38a, 98, 1169, 677, 1238, 753); --对话向下箭头
	nLog("中间向下的箭头-x2="..x2)
	if x2 > -1 then
		tap_and_sleep(x2,y2);
		return
	end]]
	
	x3,y3 = findMultiColorInRegionFuzzy( 0x27272f, "272|-2|0x27272f,-490|125|0x27272f,772|120|0x27272f", 95, 1, 607, 1279, 774)
	if x3 > -1 then
		tap_and_sleep(1200,713);
		return
	end
	
	x4,y4 = findMultiColorInRegionFuzzy( 0x303a49, "-11|127|0x283749,843|3|0x2f3a49,846|134|0x283749,445|2|0x303a49,447|132|0x283849", 99, 75, 420, 995, 633)
	if x4 >-1 then
		tap_and_sleep(x4,y4);
		return
	end
	
	x5,y5 = findMultiColorInRegionFuzzy( 0x465667, "0|38|0x3f5069,210|-11|0x4c5365,422|1|0x455467,422|39|0x3f5069,245|15|0x58d660", 99, 213, 395, 696, 477)
	if x5 > -1 then
		tap_and_sleep(x5,y5);
		return
	end
	 
	x,y = findMultiColorInRegionFuzzy( 0x4f7f47, "19|0|0x588b51,36|0|0x517e46,36|38|0x436b39,1|38|0x406937,18|18|0xffffff", 90, 553, 641, 641, 722)
	--希拉
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xa9a9a9, "0|8|0x535353,109|8|0x424242,107|3|0x9d9d9d,21|95|0x75bc65,31|106|0x65a758,48|99|0x8abf6b,78|110|0x65a64a,114|105|0x66b658", 90, 1008, 545, 1227, 750)
	nLog("一键通关-x="..x)
	if x > -1 then
		tap_and_sleep( 1108,  636);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xdbdbdb, "34|5|0xd3aa60,45|62|0xfdfdfd,108|10|0x555555,22|95|0x9af587,42|108|0x8ce672,80|105|0x8ee373,114|105|0x88ee76", 90, 980, 534, 1205, 721)
	nLog("一键通关-x2="..x)
	if x > -1 then
		tap_and_sleep( 1108,  636);
		return
	end
	
	
	
	x,y = findMultiColorInRegionFuzzy( 0x455365, "266|-1|0x455364,271|73|0x3f5069,-3|67|0x405069,61|58|0x5bde61,60|65|0x59d662,90|64|0x5ee465,90|58|0x59d264,113|64|0x5be062", 90, 758, 387, 1122, 526)
	if x > -1 then
		tap_and_sleep( 1139,  568);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xb4b5b5, "12|0|0xb2b3b3,12|5|0xb4b5b5,24|-2|0xbbbcbc,35|1|0xb0b0b0,555|-64|0x66c3f5,651|-74|0xbe1c32", 90, 419, 1, 1204, 154)
	nLog("目标任务页-x="..x)
	if x > -1 then
		
		--[[x,y = findMultiColorInRegionFuzzy( 0xb2b3b4, "0|4|0xb4b6b6,20|4|0xa5a7a7,36|3|0xb9b9b9,61|10|0xc4c5c5,61|6|0xc5c6c6,58|2|0xb2b3b3", 90, 533, 458, 621, 495)
		nLog("击溃叛军-x="..x)
		if x > -1 then
			if find_value_from_table('guide_finished') ~= nil and find_value_from_table('guide_finished') == true then
				if isColor( 1103,  475, 0x345e86 ) then
					tap_and_sleep(1103,475);--点击 前往
					tap_and_sleep(   69,  679);--出城
					mSleep(20 * 1000);
					tap_and_sleep(  365,  699);--点击搜索
					mSleep(1000);
					tap_and_sleep( 1033,  706);--点击搜索
					tap_and_sleep(640,400);--点击中心
					mSleep(1000);
					tap_and_sleep(  699,  599);--点击战斗
				end
			end
		end]]
		
		x,y = findMultiColorInRegionFuzzy( 0xb5b6b6, "36|-4|0xb1b2b3,36|1|0xb6b8b8,94|-6|0xa2a5a7,95|3|0xa5a8ab,89|3|0xb9bbbb,93|-1|0x919499,92|0|0x8e9093,90|6|0xa0a1a4", 90, 634, 166, 855, 232)
		nLog("升级主堡至6级-x="..x)
		if x > -1 then
			x,y = findMultiColorInRegionFuzzy( 0x70c969, "0|73|0x70c969,620|-1|0x5be35f,620|70|0x5be35f", 90, 457, 141, 1254, 304)
			if x > -1 then --前两个任务已完成
				insert_into_table("guide_finished",true);
			end
		end	
		
		fight_rebels_task = false;
		
		if isColor(  1198,  193, 0x886d49) then --领取
			tap_and_sleep(1198,193);
		elseif 	isColor(  1198,  264, 0x886d49) then
			tap_and_sleep(1198,  264);
		elseif 	isColor(  1198,  338, 0x886d49) then
			tap_and_sleep(1198,  338);
		elseif 	isColor(  1198,  410, 0x886d49) then
			tap_and_sleep(1198,  410);	
		elseif 	isColor(  1198,  481, 0x886d49) then
			tap_and_sleep(1198,  481);	
		elseif 	isColor(  1198,  553, 0x886d49) then
			tap_and_sleep(1198,  553);	
		elseif 	isColor(  1208,  683, 0x886d49) then
			tap_and_sleep(1208,  683);	
		else 
			if isColor(  1198,  193, 0x335981) then --前往
				tap_and_sleep(1198,193);
				upgrade_build();--升级
			elseif 	isColor(  1198,  264, 0x335981) then
				tap_and_sleep(1198,  264);
				upgrade_build();--升级
			elseif 	isColor(  1198,  338, 0x335981) then
				tap_and_sleep(1198,  338);
			elseif 	isColor(  1198,  410, 0x335981) then
				x,y = findMultiColorInRegionFuzzy( 0xb5b6b6, "10|-2|0xa8aaad,40|-6|0xa7a8a8,39|1|0x888a8b,50|-3|0xadadaf,51|-4|0xabacad,59|-3|0xb3b4b5,71|-5|0xb3b4b5,97|2|0x87898b", 90, 631, 386, 759, 423)
				nLog("护盾-x="..x)
				if x > -1 then
					tap_and_sleep(1198,  410);	
					mSleep(1000);
					tap_and_sleep( 1253,  302);
					mSleep(1000);
					tap_and_sleep( 1056,  402);--查看
					mSleep(1000);
					tap_and_sleep( 1054,  291);--使用
					mSleep(1000);
					tap_and_sleep(1150,120);--关闭
					mSleep(1000);
					tap_and_sleep(1240,70);--关闭
				else
					tap_and_sleep(1198,  410);	
				end
			elseif 	isColor(  1198,  481, 0x335981) then
				x,y = findMultiColorInRegionFuzzy( 0xb2b3b4, "0|4|0xb4b6b6,20|4|0xa5a7a7,36|3|0xb9b9b9,61|10|0xc4c5c5,61|6|0xc5c6c6,58|2|0xb2b3b3", 90, 533, 458, 621, 495)
				nLog("击溃叛军-x="..x)
				if x > -1 then
					if find_value_from_table('guide_finished') ~= nil and find_value_from_table('guide_finished') == true then
						fight_rebels_task = true;
					end
				end
				tap_and_sleep(1198,  481);	
			elseif 	isColor(  1198,  553, 0x335981) then
				tap_and_sleep(1198,  553);	
			elseif 	isColor(  1208,  683, 0x335981) then
				tap_and_sleep(1208,  683);	
			end
		end
		return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0x4b5390, "136|-2|0x753b3f,532|-6|0x2e5477,542|3|0xffffff,738|-1|0x38618a,822|3|0x355d86,799|-43|0x2c82c2,888|-59|0xbe1b32", 90, 229, 39, 1273, 157)
	nLog("领主天赋页-x="..x)
	if x > -1 then
		tap_and_sleep( 1242,   71);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xa5a5a5, "27|-50|0xc2c2c2,54|-54|0xc3c3c3,86|-49|0xbebebe,172|-7|0x373e6d,308|-7|0x582b2e,-48|4|0xadadad,-47|3|0xafafaf,-17|0|0xa6a6a8", 90, 0, 37, 558, 150)
	nLog("领主天赋页2-x="..x)
	if x > -1 then
		tap_and_sleep( 8,  738);
		mSleep(2000)
		tap_and_sleep(  22,  165);
		return
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xfafafa, "-11|-3|0xf7f7f8,17|-2|0xf6f6f6,27|6|0xfefefe,328|2|0xb1b2b2,327|2|0xb4b5b5,298|-1|0xb2b3b3,238|-2|0xaeb0b0", 90, 2, 33, 614, 102)
	nLog("商城页-x="..x)
	if x > -1 then
		tap_and_sleep( 1242,   71);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xa89674, "12|-4|0xc1ad84,39|6|0xc0ac84,483|106|0x9d5b34,-505|-25|0x2c2f34,-502|571|0x27272f,545|578|0x27272f", 90, 80, 53, 1203, 728)
	nLog("商店-x="..x)
	if x > -1 then
		
		x,y = findMultiColorInRegionFuzzy( 0xf3e29e, "12|8|0xddc58d,3|8|0x9b7a4b,0|36|0x775644,24|17|0xad8f66,38|16|0xaf8e69,18|2|0xe3c98d,19|32|0x7c614a", 90, 158, 301, 232, 384)
		nLog("一件加速-x="..x);
		if x > -1 then
			tap_and_sleep( 1023,  337);--点击一键加速
			mSleep(1000);
			x,y = findMultiColorInRegionFuzzy( 0xb8a47e, "4|0|0xb7a37d,4|-3|0xb4a17b,21|-5|0xbaa77f,57|3|0xc2af85", 90, 572, 120, 704, 162)
			nLog("加速对话框-x="..x)
			if x > -1 then
				tap_and_sleep(  778,  620);--点击确定
				mSleep(1000);
			end


			tap_and_sleep(1150,120);--点击关闭
			--mSleep(1000);
			--tap_and_sleep(1240,70);--点击关闭

		else
			tap_and_sleep(1150, 120); --关闭页面
		end
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xb5a27c, "28|0|0xbaa67f,28|12|0xbdaa82,34|14|0xc2ae85,-9|14|0xbda981,7|14|0xc2ae85", 90, 604, 101, 679, 139)
	nLog("商店-x2="..x)
	if x > -1 then
		
		x,y = findMultiColorInRegionFuzzy( 0xf3e29e, "12|8|0xddc58d,3|8|0x9b7a4b,0|36|0x775644,24|17|0xad8f66,38|16|0xaf8e69,18|2|0xe3c98d,19|32|0x7c614a", 90, 158, 301, 232, 384)
		nLog("一件加速-x="..x);
		if x > -1 then
			tap_and_sleep( 1023,  337);--点击一键加速
			mSleep(1000);
			x,y = findMultiColorInRegionFuzzy( 0xb8a47e, "4|0|0xb7a37d,4|-3|0xb4a17b,21|-5|0xbaa77f,57|3|0xc2af85", 90, 572, 120, 704, 162)
			nLog("加速对话框-x="..x)
			if x > -1 then
				tap_and_sleep(  778,  620);--点击确定
				mSleep(1000);
			end


			tap_and_sleep(1150,120);--点击关闭
			--mSleep(1000);
			--tap_and_sleep(1240,70);--点击关闭

		else
			tap_and_sleep(1150, 120); --关闭页面
		end
		
		--tap_and_sleep(1148,  118);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x71583c, "4|40|0xa68b59,702|3|0x765d3e,1006|1|0x2c5579,165|-245|0x95504c,169|-263|0x9c6259,-197|-438|0x272f41", 90, 14, 199, 1278, 754)
	nLog("兵营-x="..x)
	if x > -1 then
		
		x,y = findMultiColorInRegionFuzzy( 0xfdfdca, "9|40|0xffeeb6,1|85|0xe6cb8d,-26|81|0xe5cc8a,27|73|0xefce8f,4|87|0xe3c98a,1|100|0xe0c689", 90, 631, 259, 1250, 535)
		nLog("手指图标-x="..x)
		if x > -1 then
			tap_and_sleep(x,y);
		end
		
		x,y = findMultiColorInRegionFuzzy( 0xfcfaca, "-5|-88|0xe3c88a,9|-87|0xe2c887,11|-56|0xfae19d,17|-57|0xfae09c,-26|-66|0xefd894,-7|-63|0xf3d999,26|-77|0xeecc98", 90, 625, 176, 1254, 528)
		nLog("手指图标2-x="..x)
		if x > -1 then
			tap_and_sleep(x,y);
		end
		
		
		if isColor(  976,  691, 0xfc4646 )  == false then
			mSleep(3000);
			x, y = findColorInRegionFuzzy(0xffd155, 98, 0, 0, 1280, 800); --手指箭头
			nLog("中间向下的箭头-x="..x.."-y="..y)
			if x > -1 then
				tap_and_sleep(x,y);
				
				mSleep(3000);
				--tap_and_sleep(  1142,  680); --点击训练	
				tap_and_sleep(  1142,  680); --点击训练	
				
				
				mSleep(2000);
				tap_and_sleep(  1242,   70); --点击关闭
				mSleep(2000);
				return
			end
		end
		
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x447699, "-67|-19|0x4d7b45,-62|-128|0xfefefe,-57|-119|0xfafafa,-41|-136|0xf8f8f8,-35|-136|0xfafafa,-43|-118|0xf5f5f5,900|-128|0x67bde1,-69|-71|0xb06b13,-124|5|0x99312c", 90, 2, 37, 1142, 251)
	nLog("兵营训练页-x="..x)
	if x > -1 then
		if isColor( 1032,  684, 0x91744f ) then
			tap_and_sleep(1032,  684);
			return
		end
	end	
	
	--insert_into_table("is_level_6",true)
	
	x,y = findMultiColorInRegionFuzzy( 0xc5b087, "-18|-3|0xc0ac84,-28|5|0xc2ae85,34|1|0xbda981,48|-2|0xc2ae86,61|-2|0xbeaa82,62|-2|0xbeaa83,53|5|0xb09d78", 90, 559, 95, 717, 139)
	nLog("学士进修-x="..x)
	if x > -1 then
		tap_and_sleep(1148,  118);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xb9a67e, "0|-2|0xb7a47d,26|-3|0xbca881,45|-3|0xb5a27b,61|-1|0xb8a47e,161|496|0x365e87,514|492|0x73593c,501|45|0xafb0af", 90, 59, 58, 1213, 722)
	nLog("庇护所-x="..x)
	if x > -1 then
		tap_and_sleep(1157,  118);--点击x
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xb4a07b, "31|-1|0xbdaa82,58|-4|0xbda982,94|1|0xb9a57f,-54|432|0x72593c,149|434|0x745b3f,30|446|0xc3260f,-48|469|0xa28856", 90, 378, 92, 898, 704)
	nLog("叛军营地-x="..x)
	if x > -1 then
		tap_and_sleep(  645,  594);--点击战斗
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xf9f9f9, "0|7|0xfdfdfd,0|13|0xfdfdfd,0|16|0xfdfdfd,20|4|0xfdfdfd,20|8|0xf1f1f2,30|7|0xfefefe,28|14|0xfafafa,970|2|0xacefff", 90, 4, 28, 1131, 104)
	nLog("主堡-x2="..x)
	if x > -1 then
		text = ocrText(656, 124, 708, 176, 0)
		nLog("text-x="..text)
		if text ~= nil and tonumber(text) >= 7 then
			insert_into_table('is_level_6',true);
		end
		
		x,y = findMultiColorInRegionFuzzy( 0x39834b, "95|-1|0x337744,0|18|0x3e884e,95|17|0x3c874d,26|5|0xdee4e0,60|10|0xf4f4f4,53|12|0xdaddda,38|11|0xe1e2e1", 90, 1118, 417, 1241, 587)
		if x > -1 then
			nLog("升级中-x="..x)
			tap_and_sleep( 1240,   71);--点击关闭
			tap_and_sleep( 1240,   71);--点击关闭
		else
			if isColor(  416,  672, 0x70583c  ) then --升级
				tap_and_sleep(214,672);
			end
		end
		 
		x,y = findMultiColorInRegionFuzzy( 0x407340, "45|2|0x3e7243,2|43|0x60b26e,46|43|0x5cae6b,11|17|0xe7e3da,7|15|0xe8e4dc,19|16|0xd7d8cd,35|16|0xdedcd1,34|21|0xf2eee5", 90, 503, 665, 566, 726)
		nLog("加速-x="..x)
		if x > -1 then
			nLog("升级中-x="..x)
			tap_and_sleep( 1240,   71);--点击关闭
			mSleep(200);
			tap_and_sleep( 1240,   71);--点击关闭
		end
		
		
		if isColor(  347,  677, 0x5d3e86 ) then --如果有免费升级
			tap_and_sleep(347,  677)
		else
			x,y = findMultiColorInRegionFuzzy( 0x355c88, "96|22|0x416a91,63|11|0xeeeff0,63|5|0xdcdcde", 90, 1112, 424, 1250, 592)
			nLog("前往-x="..x.."y="..y)
			if x > -1 then
				
				if isColor(x-291,y+2,0xcd4042) and isColor(x-283,y+2,0xe24647) and isColor(x-272,y+2,0xe54747) and isColor(x-263,y+1,0xe64647) then --解锁二级兵种
					tap_and_sleep(x,y);--点击前往
					mSleep(2000);
					tap_and_sleep(  894,  264);--点击二级勇士
					
				else
					tap_and_sleep(x,y);--点击前往
					upgrade_build();
				end
				
			else
				if isColor(  214,  672, 0x71583c ) then --升级
					tap_and_sleep(214,672);
				end
			end
		end
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfafafa, "0|8|0xfdfdfd,0|17|0xfdfdfd,20|5|0xfdfdfd,35|2|0xfafafa,30|8|0xfefefe,954|9|0x70c5e5,28|16|0xfdfdfd", 90, 0, 32, 1212, 103)
	nLog("主堡-x="..x)
	if x > -1 then  
		text = ocrText(656, 124, 708, 176, 0)
		--nLog("text-x="..text)
		if text ~= nil and tonumber(text) ~= nil and tonumber(text) >= 7 then
			insert_into_table('is_level_6',true);
		end
		
		x,y = findMultiColorInRegionFuzzy( 0x39834b, "95|-1|0x337744,0|18|0x3e884e,95|17|0x3c874d,26|5|0xdee4e0,60|10|0xf4f4f4,53|12|0xdaddda,38|11|0xe1e2e1", 90, 1118, 417, 1241, 587)
		if x > -1 then
			nLog("升级中-x="..x)
			tap_and_sleep( 1240,   71);--点击关闭
		else
			if isColor(  416,  672, 0x70583c  ) then --升级
				tap_and_sleep(214,672);
			end
		end
		 
		x,y = findMultiColorInRegionFuzzy( 0x407340, "45|2|0x3e7243,2|43|0x60b26e,46|43|0x5cae6b,11|17|0xe7e3da,7|15|0xe8e4dc,19|16|0xd7d8cd,35|16|0xdedcd1,34|21|0xf2eee5", 90, 503, 665, 566, 726)
		nLog("加速-x="..x)
		if x > -1 then
			nLog("升级中-x="..x)
			tap_and_sleep( 1240,   71);--点击关闭
			tap_and_sleep( 1240,   71);--点击关闭
		end
		
		
		if isColor(  347,  677, 0x5d3e86 ) then --如果有免费升级
			tap_and_sleep(347,  677)
		else
			x,y = findMultiColorInRegionFuzzy( 0x355c88, "96|22|0x416a91,63|11|0xeeeff0,63|5|0xdcdcde", 90, 1112, 424, 1250, 592)
			nLog("前往-x="..x.."y="..y)
			if x > -1 then
				
				if isColor(x-291,y+2,0xcd4042) and isColor(x-283,y+2,0xe24647) and isColor(x-272,y+2,0xe54747) and isColor(x-263,y+1,0xe64647) then --解锁二级兵种
					tap_and_sleep(x,y);--点击前往
					mSleep(2000);
					tap_and_sleep(  894,  264);--点击二级勇士
					
				else
					tap_and_sleep(x,y);--点击前往
					upgrade_build();
				end
				
			else
				if isColor(  214,  672, 0x71583c ) then --升级
					tap_and_sleep(214,672);
				end
			end
		end
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xf7f7f7, "0|9|0xfcfcfd,13|3|0xf9f9f9,15|8|0xfefefe,28|0|0xf2f2f2,40|0|0xfdfdfd,962|4|0x70c5e5", 90, 2, 38, 1140, 103)
	nLog("城墙-x="..x)
	if x > -1 then
		if isColor(  347,  677, 0x5d3e86 ) then --如果有免费升级
			tap_and_sleep(347,  677)
		else
			if isColor( 1132,  434, 0x355e87 ) then
				x,y = findMultiColorInRegionFuzzy( 0x355c88, "96|22|0x416a91,63|11|0xeeeff0,63|5|0xdcdcde", 90, 1117, 413, 1252, 504)
				if x > -1 then
					tap_and_sleep(x,y);--点击前往
				end
			else
				if isColor(  100,  683, 0x7c6344 ) then
					tap_and_sleep(   80,  675);--点击升级
				else
					tap_and_sleep(1242,70)--点击关闭
				end
			end
		end
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfbfbfb, "8|6|0xfefefe,7|7|0xfcfcfc,-3|19|0xf3f3f3,32|-1|0xf8f8f8,32|12|0xf3f3f4,956|8|0x6bc1e3,33|18|0xfcfcfc", 90, 0, 40, 1135, 105)
	nLog("仓库-x="..x)
	if x > -1 then
		if isColor(  347,  677, 0x5d3e86 ) then --如果有免费升级
			tap_and_sleep(347,  677)
		else
			if isColor( 1132,  434, 0x355e87 ) then
				x,y = findMultiColorInRegionFuzzy( 0x355c88, "96|22|0x416a91,63|11|0xeeeff0,63|5|0xdcdcde", 90, 1117, 413, 1252, 504)
				if x > -1 then
					tap_and_sleep(x,y);--点击前往
				end
			else
				if isColor(  100,  683, 0x7c6344 ) then
					tap_and_sleep(   80,  675);--点击升级
				else
					tap_and_sleep(1242,70)--点击关闭
				end
			end
		end
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xbba880, "0|7|0xbba77f,7|14|0xb9a57f,7|1|0xbca880,21|-2|0xbeaa82,56|7|0xbeaa82,64|16|0xc4b086,-502|-22|0x2c3037", 90, 90, 65, 725, 153)
	nLog("书签夹-x="..x)
	if x > -1 then
		tap_and_sleep(1146,117)--点击关闭
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xeaeaea, "1|10|0xfcfcfc,14|4|0xfcfcfc,40|3|0xfbfbfb,52|9|0xfdfdfd,93|2|0xfafafa,939|-6|0x9dedfc,52|8|0xfcfcfc", 90, 3, 33, 1114, 98)
	nLog("心树试炼-x="..x)
	if x > -1 then
		if isColor(  988,  614, 0x365f89 ) then
			tap_and_sleep( 988,  614);--点击挑战
			return
		end
		
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xffffff, "0|-1|0xfdfdfd,16|4|0xfafafa,34|3|0xfefefe,63|-6|0xeeeeee,54|-6|0xfcfcfc,51|4|0xf1f1f1,960|-3|0x6bc1e3", 90, 0, 32, 1144, 101)
	nLog("雅雀塔-x="..x)
	if x > -1 then
		if isColor(  344,  673, 0x5d3e86 ) then
			nLog("免费升级-x="..x)
			tap_and_sleep(344,  673)--点击免费升级s
			return
		end
		
		x,y = findMultiColorInRegionFuzzy( 0x73543f, "205|-1|0x745240,205|46|0xa68956,0|48|0xad8d5a,95|20|0xf6f6f6,89|16|0xfaf9f9,115|20|0xedecec,118|25|0xfafaf9", 90, 203, 663, 426, 725)
		nLog("升级-x="..x)
		if x > -1 then
			tap_and_sleep(x,y);
			return
		end
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xbaa77f, "13|-1|0xc3af85,6|9|0xc0ab83,36|5|0xbba780,40|12|0xc0ac84,62|10|0xc3ae86,100|3|0xbda981", 90, 262, 161, 1001, 643)
	nLog("星级奖励-x="..x)
	if x > -1 then
		if isColor(  629,  519, 0x23242b ) then
			tap_and_sleep(955,209);--点击关闭
		else
			tap_and_sleep(629,  519);--点击领取
		end
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xbca880, "0|-1|0xbda981,-4|6|0xbaa780,2|7|0xc2ae85,21|7|0xc2ae85,31|4|0xc6b188,50|5|0xc1ad84,82|16|0xbaa780", 90, 540, 88, 734, 145)
	nLog("军团信息-x="..x)
	if x > -1 then
		tap_and_sleep(1150,120)--点击关闭
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xf7f7f7, "-3|10|0xeff0f0,15|7|0xfcfcfc,9|11|0xf8f8f8,28|0|0xf2f2f2,28|9|0xfcfcfc,45|9|0xfbfbfb,961|3|0x56abdc", 90, 76, 39, 1103, 106)
	nLog("城墙-x="..x)
	if x > -1 then
		if isColor(  344,  673, 0x5d3e86 ) then
			nLog("免费升级-x="..x)
			tap_and_sleep(344,  673)--点击免费升级s
			
		else
			nLog("升级-x="..x)
			if isColor( 106,  694, 0x8d734c ) then
				tap_and_sleep(106,  694)--点击升级
			end
		end
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xb4a17c, "0|-3|0xb9a57e,-1|7|0xc1ac84,28|5|0xc2ae85,70|4|0xbba780,92|10|0xc1ad84", 90, 567, 95, 708, 138)
	nLog("科技研发-x="..x)
	if x > -1 then
		x,y = findMultiColorInRegionFuzzy( 0x315a8b, "102|1|0x2d547a,1|23|0x3e6790,102|22|0x3d6992,35|13|0xd6d8da,41|13|0xf4f4f5,66|11|0xf0f1f2,59|11|0xededee", 90, 477, 187, 598, 484)
		nLog("前往-x = "..x)
		if x > -1 then
			tap_and_sleep(x,y);
		else
			x,y = findMultiColorInRegionFuzzy( 0x5d3e85, "447|3|0x735a3e,0|41|0x654691,448|40|0xa78c5a,68|8|0x61b7df,102|10|0xcfccd7,120|6|0xcac8d1,176|19|0x5d3e86", 90, 622, 600, 1116, 681)
			nLog("免费研发-x="..x)
			if x > -1 then
				tap_and_sleep(  732,  647);--点击免费研究
			else
				tap_and_sleep(  988,  645);--点击研发
				tap_and_sleep(  1150,  120);--点击关闭
				tap_and_sleep(  1240,  70);--点击关闭
				tap_and_sleep(  1240,  70);--点击关闭
				tap_and_sleep(  1240,  70);--点击关闭
			end
		end
		return
	end	

	
	x,y = findMultiColorInRegionFuzzy( 0xb9a57e, "0|8|0xc1ac84,-1|10|0xc1ac84,14|11|0xbba780,28|8|0xc2ae85,38|1|0xc1ad84,70|7|0xbba780,88|4|0xbfab83,-477|-17|0x2c2f35", 90, 73, 61, 928, 155)
	nLog("一个关闭操作-x="..x)
	if x > -1 then
		tap_and_sleep( 1149,  117);
		return
	end
	

	x,y = findMultiColorInRegionFuzzy( 0xe9c695, "8|-9|0xeccb8a,-10|-9|0xeacb8f,-11|10|0xcaa976,9|10|0xccab77", 90, 1215, 35, 1271, 102)
	--如果上面的操作都没找到  点击x
	if x > -1 then
		tap_and_sleep(x,y)
	end
end


-- 6级以后分两条路，1采矿
function mining_task(...)
	
	x,y = findMultiColorInRegionFuzzy( 0xa38a5e, "-47|-27|0xe6cd9f,-26|-40|0xe6d0a0,-13|-22|0x1a232e,11|-16|0x1b242e,-21|7|0xaa9063,-47|0|0xc4ab81", 90, 3, 629, 138, 758)
    nLog("回城-x="..x)-- 在城外  挖矿	
	if x > -1 then
		duilie = ocrText(68, 542, 85, 555,0);
		if isColor (33,  564, 0x457a43)  and isColor (   75,  573, 0x45884d) and duilie ~= nil and tostring(duilie) ~= "1" then
			is_mining = true;
		else
			is_mining = false;
		end	
	end	
	

	
	
	nLog("回城-is_mining="..tostring(is_mining))
	x,y = findMultiColorInRegionFuzzy( 0xa38a5e, "-47|-27|0xe6cd9f,-26|-40|0xe6d0a0,-13|-22|0x1a232e,11|-16|0x1b242e,-21|7|0xaa9063,-47|0|0xc4ab81", 90, 3, 629, 138, 758)
    nLog("回城-x="..x)-- 在城外  挖矿	
	if x > -1 and is_mining == false then
		
		::search:: --定义一个标识
		tap_and_sleep(  362,  696); --点击搜索`
		mSleep(1000);
		if mining_type == 0 then
			tap_and_sleep(  421,  565);--点击农田
		elseif mining_type == 1 then
			tap_and_sleep(    572,  569);--点击伐木场
		elseif mining_type == 2 then
			tap_and_sleep(  712,  564);--点 采石场
		elseif mining_type == 3 then
			tap_and_sleep(  860,  566);--点 铁矿厂			
		elseif mining_type == 4 then
			tap_and_sleep(  1020,  567);--点 金币场				
		end

		mSleep(1000);
		--tap_and_sleep(  397,  719);--选择三级旷 
		local kuang_index = math.random(1,2);
		if kuang_index == 1 then					  
			tap_and_sleep(    402,  720);--选择3级旷   
		else
			tap_and_sleep(    575,  719);--选择4级旷 
		end
		tap_and_sleep( 1085,  714);--点击搜索
		mSleep(1000);
		tap_and_sleep(  640,  400);--点击屏幕正中间
		mSleep(1000);

		x,y = findMultiColorInRegionFuzzy( 0x2c3035, "656|21|0xd7b786,673|423|0x27272f,327|351|0xfafafa,349|353|0xf8f8f7,638|82|0x8f8f8f,639|141|0xc6c6c6,324|29|0xc5b087", 90, 288, 169, 1004, 629)
		if x > -1 then --采集对话框
			text = ocrText(702, 357, 796, 389, 0)
			nLog("text="..text)
			if string.len(text) >= 6 then
				nLog("大于1W")
				
				x,y = findMultiColorInRegionFuzzy( 0xfbfbfb, "22|3|0xf8f8f7,11|-16|0x775e3f,-92|-22|0x73573d,115|-22|0x73563e,115|23|0xa98e5d,-92|21|0xa78653", 90, 516, 499, 777, 574)
				nLog("采集对话框-x="..x)
				if x > -1 then
					tap_and_sleep(  635,  533);--点击采集\
				else
					goto search
				end
				
				
				mSleep(1000);
				tap_and_sleep(  903,  679);--点击快速选择
				mSleep(1000);
				tap_and_sleep(    173,  353);--点击减少一个
				mSleep(1000)
				tap_and_sleep(    173,  353);--点击减少一个
				mSleep(1000)
				tap_and_sleep( 1116,  687);--点击出征

				--重置 采集类型
				if mining_type == 0 then
					mining_type =1 ;
				elseif mining_type == 1 then
					mining_type =2 ;
				elseif mining_type == 2 then
					mining_type =3 ;
				elseif mining_type == 3 then
					mining_type =4 ;		
				elseif mining_type == 4 then
					mining_type =0 ;			
				end

				is_mining = true;
			else
				nLog("goto search")
				goto search;
			end

		end
		
	else
		x,y = findMultiColorInRegionFuzzy( 0xa38a5e, "-47|-27|0xe6cd9f,-26|-40|0xe6d0a0,-13|-22|0x1a232e,11|-16|0x1b242e,-21|7|0xaa9063,-47|0|0xc4ab81", 90, 3, 629, 138, 758)
		nLog("回城-x="..x)-- 在城外  挖矿	
		if x > -1 then
			if isColor (33,  564, 0x457a43)  and isColor (   75,  573, 0x45884d) and duilie ~= nil and tostring(duilie) ~= "1" then
				tap_and_sleep(70,680);--点击回城
			end
		end
		
	end
	
end
-- 6级以后分两条路，2造兵
function build_task(...)
	x,y = findMultiColorInRegionFuzzy( 0xc7b284, "-4|-11|0xd8c293,30|-5|0x11191a,14|-7|0xcfbe92,23|16|0xb69a6d,24|-9|0xd7bf90,-16|-9|0x162026", 90, 2, 621, 125, 753)
	nLog("出城-x="..x)-- 在城内  造兵
	if x > -1 then
		x,y = findMultiColorInRegionFuzzy( 0x7b413a, "-2|3|0x82483f,-18|33|0x6e3c32,82|1|0x814438,47|-28|0x9f9e9e,51|-30|0xa8a9a9,75|-34|0x929494,140|-1|0x9d4e4f", 90, 257, 610, 484, 738)
		nLog("驻扎地build_task-x="..x)
		if x <= -1 then
			tap_and_sleep(   66,  678);
			mSleep(20 * 1000);
			return
		else
			tap_and_sleep( 479,  448);--点击兵营
			mSleep(20 * 1000);
			is_zoom = true;
		end
		
		--[[if is_zoom == false then
			--moveZoomIn(403,469,537,391); --放大
			--is_zoom = true;
			--mSleep(20 * 1000);
			--tap_and_sleep(  469,  511); --点击兵营
			
			tap_and_sleep(473,  433);--点击兵营
			mSleep(20 * 1000);
			is_zoom = true;
		end

		
		x,y = findMultiColorInRegionFuzzy( 0xaa5947, "78|-24|0xb35e4d,20|40|0x506271,-34|73|0x8e4e3a,85|9|0xffffef,-15|57|0xddbaa3", 90, 377, 450, 596, 626)
		nLog("兵营-x="..x)
		if x > -1 then
			tap_and_sleep(  469,  511); --点击兵营
		end
		
		x,y = findMultiColorInRegionFuzzy( 0xb35f46, "31|-2|0xa15a3e,63|1|0xa3bef4,7|34|0x4f586f,-27|54|0x8e4e3a,-5|-29|0xacadad,10|-29|0x8e9090,-14|48|0xdcc8ad", 90, 300, 394, 614, 582)
		nLog("兵营2-x="..x)
		if x > -1 then
			tap_and_sleep(  x,  y); --点击兵营
		end
		x,y = findMultiColorInRegionFuzzy( 0xac5a43, "40|-2|0xa55a44,74|-25|0xc46c4c,84|-27|0xb35f4e,-38|78|0x8c4e3c,76|5|0xa8c2f3", 90, 327, 464, 623, 674)
		nLog("兵营3-x="..x)
		if x > -1 then
			tap_and_sleep(  x,  y); --点击兵营
		end
		return]]
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0xa38a5e, "-47|-27|0xe6cd9f,-26|-40|0xe6d0a0,-13|-22|0x1a232e,11|-16|0x1b242e,-21|7|0xaa9063,-47|0|0xc4ab81", 90, 3, 629, 138, 758)
	if x > -1 then-- 在城外  回城
		tap_and_sleep(x,y);--点击回城
		is_zoom = false;
		mSleep(20 * 1000);
		return
	end
	
end


-- 对话框 
function dialog_tap(...)
	x,y = findMultiColorInRegionFuzzy( 0xc7b38c, "28|0|0xc5b088,14|0|0xc6b38a,15|14|0xc6b38a", 90, 1176, 677, 1234, 758)
	nLog("下三角-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);--点击下三角
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x3c5067, "6|-43|0x455566,170|-43|0x455466,170|-6|0x405069,13|-5|0x405069,44|-21|0xd8d8d9,39|-18|0xdcddde,47|-30|0xe1e2e2,43|-19|0xcfcfd1", 90,290, 188, 1050, 629)
	nLog("请点击空地-x="..x)
	if x > - 1 then
		tap_and_sleep(x-20,y+5);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x3c4f67, "7|-43|0x455365,169|-42|0x455365,169|-7|0x405069,16|-9|0x3f5069,47|-31|0xe4e4e5,44|-29|0xb1b3b4,44|-19|0xd7d7d8,50|-27|0xbfc0c1",90, 396, 563, 749, 759)
	nLog("免费建造-x="..x);
	if x > -1 then
		tap_and_sleep(x-20,y+5);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x465667, "2|38|0x405069,90|48|0x3c4f69,180|3|0x455365,177|37|0x405069,40|13|0xe0e1e2,37|14|0xbcbdc0,43|13|0xbebfc1", 90, 1060, 191, 1279, 491)
	nLog("请选择长弓兵-x="..x)
	if x > -1 then
		tap_and_sleep(x+20,y+50);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x415169, "-170|-39|0x455365,-11|-42|0x445365,-168|-9|0x405069,-47|-31|0xeeeeee,-45|-24|0xe1e1e2,-88|-26|0xb5b5b8", 90, 859, 542, 1271, 759)
	nLog("请开始训练-x="..x)
	if x > -1 then
		tap_and_sleep(x+20,y+30);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xc1aa81, "0|15|0xbfa675,59|0|0xcebd90,119|13|0xe9d4af,186|13|0xc4b19d,234|14|0xbcaa7a", 90, 485, 62, 799, 140)
	nLog("指挥官解锁-x="..x)
	if x >-1 then
		tap_and_sleep(x+20,y+30);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xffffca, "-48|-41|0xe8cc8e,-39|-53|0xe6cb8c,-36|-27|0xfede98,-64|-49|0xe2c687,-19|-57|0xefcd96,-56|-19|0xeed494", 90, 854, 99, 1275, 517)
	nLog("前往 引导-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x3e4f67, "10|-44|0x455364,150|-45|0x455567,149|-8|0x3f5069,25|-7|0x405069,46|-32|0xdddede,46|-29|0xdadada,41|-24|0xc7c8c9,51|-24|0xd1d2d3", 90, 246, 173, 973, 659)
	nLog("点击主堡-x ="..x)
	if x > -1 then
		tap_and_sleep(x-10,y+10);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xf3c45d, "-8|8|0xddbb55,7|5|0xdbb150,-1|35|0xedca6d,178|13|0xeac15e,187|30|0xe1bf67", 90, 500, 201, 771, 284)
	nLog("章节奖励-x="..x)
	if x > -1 then
		tap_and_sleep(x,y-100);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfdca5e, "0|6|0xebc05e,0|18|0xe0bc60,201|12|0xe5ba5b,201|22|0xdebe64,144|6|0xf3c867", 90, 505, 140, 779, 212)
	nLog("玩法解锁-x="..x)
	if x > -1 then
		tap_and_sleep(x,y-100);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x3d5067, "10|-42|0x445365,188|-39|0x455365,186|-6|0x405069,23|-7|0x405069,49|-29|0xe5e6e6,44|-24|0xe0e1e1", 90, 198, 571, 626, 752)
	nLog("进入升级界面-x="..x)
	if x > -1 then
		tap_and_sleep(x-10,y-10);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xe7cc8d, "42|-41|0xfffbca,58|-58|0xffffcc,37|-23|0xffefbb,-20|-10|0xe6c482", 90, 1051, 10, 1279, 203)
	nLog("右上角引导手势-x="..x)
	if x > -1 then
		tap_and_sleep( 1242, 70); --点击x
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xe6cb8d, "-27|10|0xecd192,26|9|0xeece8e,-9|11|0xedd294,-1|82|0xfcfcc9,-10|40|0xffecae", 90, 24, 521, 612, 730)
	nLog("左下角 下 引导手势-x="..x..y)
	if x > -1 then
		tap_and_sleep( x, y+100); --点击x
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x303a49, "3|134|0x283849,848|133|0x283749,848|133|0x283749,506|49|0x56d25b,496|50|0x5fe963,528|57|0x5de462,547|50|0x5de962", 90, 47, 403, 994, 636)
	nLog("侦查敌情-x="..x)
	if x > -1 then
		tap_and_sleep(   651,  508); --点击侦查敌情
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x303a49, "3|134|0x283849,848|133|0x283749,848|133|0x283749,340|88|0x56d75c,354|82|0x5de661,364|87|0x5ce562,384|78|0x5be360", 90, 49, 424, 1008, 640)
	nLog("兵种克制关系-x="..x)
	if x > -1 then
		tap_and_sleep( 533,  543); --点击侦查敌情
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xb39154, "-180|-1|0xb8ab5d,-192|132|0xb7ac5f,-121|132|0xb8a35c,3|133|0xb59455,34|-7|0x977044", 90, 0, 270, 527, 585)
	nLog("解锁指挥官-x="..x)
	if x > -1 then
		tap_and_sleep( x,  y); --点击侦查敌情
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x3f5068, "-188|-40|0x455365,-19|-9|0x405069,-10|-39|0x445365,-192|-7|0x405069,-132|-30|0xe5e6e6,-153|-31|0xdcdddd,-116|-29|0xe5e5e6", 90, 315, 340, 961, 613)
	nLog("点击加入集结-x="..x)
	if x > -1 then
		tap_and_sleep( x,  y); --点击侦查敌情
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x475365, "5|41|0x3e4f6b,27|4|0x445365,212|8|0x455365,212|41|0x405069,68|17|0xf3f4f4,68|24|0xfafafa,47|24|0xf3f4f4,47|18|0xf6f6f6", 90, 88, 160, 356, 259)
	nLog("快速选择指挥官-x="..x)
	if x > -1 then
		tap_and_sleep( x,  y); --点击侦查敌情
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x435166, "14|-21|0x455667,173|-18|0x445365,172|18|0x3f5069,16|18|0x3f5069,50|-7|0xbfc1c3,56|-8|0xb5b6b9,57|2|0xd9d9da", 90, 124, 639, 377, 740)
	nLog("请点击出城-x="..x)
	if x > -1 then
		tap_and_sleep( x-30, y); --点击x
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfdfbca, "50|56|0xe7cb8c,50|43|0xedd394,29|66|0xefcd95,72|62|0xdec484,69|32|0xebd08f,28|17|0xfff0bd", 90, 757, 489, 1278, 796)	
	nLog("右下角手势引导-x="..x)
	if x > -1 then
		tap_and_sleep( x-30, y); 
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfef8c8, "-10|-9|0xfef7c4,-54|-52|0xe6c98d,-29|-66|0xedca92,-66|-31|0xeacc8b,-56|-20|0xf3d592,-42|-29|0xf8db99",90, 1015, 100, 1248, 525)
	nLog("领取奖励-x="..x)
	if x > -1 then
		tap_and_sleep( x+20, y); --领取
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x3d5067, "8|-42|0x455365,142|-40|0x455365,142|-5|0x3f5069,19|-6|0x3f5069,44|-30|0xe4e5e6,42|-21|0xbcbec0", 90, 17, 524, 665, 753)
	nLog("点击升级-x="..x)
	if x > -1 then
		tap_and_sleep( x, y); --点击x
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x2f3a49, "852|-8|0x303a49,852|135|0x2a3749,2|131|0x283849,497|77|0x5ee762,521|77|0x5de661,460|80|0x5be160,473|79|0x54d159", 90, 55, 408, 994, 628)
	nLog("升级城墙-x="..x)
	if x > -1 then
		tap_and_sleep(  577,  541); --点击升级
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfff8c7, "-16|-15|0xfef5c4,-57|-57|0xe4c98a,-73|-50|0xdfc582,-46|-32|0xf8db99,-27|-49|0xf8dc9a", 90, 1027, 145, 1262, 538)
	nLog("手势-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y); --点击手势
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfff8c7, "-16|-15|0xfef5c4,-57|-57|0xe4c98a,-73|-50|0xdfc582,-46|-32|0xf8db99,-27|-49|0xf8dc9a", 90, 748, 502, 1276, 662)
	nLog("手势-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y); --点击手势
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xffffd1, "-1|35|0xfff9ae,-5|73|0xe5ca8c,8|71|0xe7ca8e,-27|67|0xeecc8d,25|71|0xedcc89", 90, 630, 112, 1268, 763)
	nLog("手势操作-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y); --点击手势
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xffffe8, "-3|-65|0xe9cb8e,12|-63|0xebcc8c,16|-39|0xffeea4,-7|-40|0xffeda3,-25|-57|0xedd190,27|-60|0xeecd89", 90, 634, 404, 1278, 745)
	nLog("手势操作2-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y); --点击手势
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfefbc9, "9|10|0xfffbca,21|22|0xfff8c6,36|26|0xffedb7,30|53|0xfae1a0,64|60|0xe7ca8e,81|53|0xdccb87,71|75|0xdcc686", 90, 0, 36, 233, 203)
	nLog("点击头像手势操作-x="..x)
	if x > -1 then
		tap_and_sleep(  x,  y); --点击手势
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfefecb, "14|0|0xfffbca,27|0|0xfff8c6,50|-8|0xffe6a4,55|2|0xfae2a0,83|-1|0xe7cb8e,99|6|0xe1c583,76|26|0xefcf8b", 90, 17, 121, 211, 566)
	nLog("选择天赋手势操作-x="..x)
	if x > -1 then
		tap_and_sleep(  x-10,  y); --点击手势
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x3e4f67, "-217|-50|0x445465,-218|-14|0x405069,216|-48|0x455365,219|-14|0x405069,-181|-38|0xdadbdc,-72|-33|0xb9b9bb,-57|-38|0xd6d6d8", 90, 111, 352, 627, 444)
	nLog("强化军队实力-x="..x)
	if x > -1 then
		tap_and_sleep(x,y+5);
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x4c5365, "-220|13|0x455566,-218|49|0x3f5069,219|14|0x455366,217|48|0x405069,-57|25|0xdbdcdc,-117|25|0xe9eaea,36|32|0xe5e5e6", 90, 103, 455, 609, 547)
	nLog("提升发展速度-x="..x)
	if x > -1 then
		tap_and_sleep(x,y-5);
	end
	
	
	x,y = findMultiColorInRegionFuzzy( 0x2f3a49, "818|2|0x303a49,818|140|0x293849,-36|103|0x2c3849,416|81|0x5be160,448|88|0x5feb64,449|80|0x5ce25f,464|93|0x5adf5f", 90, 48, 426, 1018, 629)
	nLog("加速训练-x="..x)
	if x > -1 then
		tap_and_sleep(    602,  549); --点击 加速训练
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x303a49, "0|135|0x283849,847|137|0x283749,849|2|0x303a49,710|70|0x51c956,711|78|0x5adf5e,745|72|0x5ce360,765|68|0x5be160", 90, 80, 422, 995, 627)
	nLog("训练士兵-x="..x)
	if x > -1 then
		tap_and_sleep(  872,  524); --点击 训练士兵
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x303a49, "-2|129|0x283849,850|131|0x283849,845|-1|0x303a49,546|66|0x59da5f,574|66|0x54d05b,598|67|0x5ade5f,625|64|0x56d55d", 90, 76, 430, 1000, 628)
	nLog("安排伤兵治疗-x="..x)
	if x > -1 then
		tap_and_sleep(  732,  524); --点击 训练士兵
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xffeea0, "342|2|0xdab275,115|332|0xb6a37b,136|332|0xb7a37c,183|335|0xc0ac85,183|331|0xb7a47d,183|327|0xb4a27c", 90, 270, 67, 954, 768)
	nLog("升级对话框-x="..x)
	if x > -1 then
		tap_and_sleep( 639,  727); --点击 屏幕继续
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x37608a, "486|3|0x826945,180|-321|0xc6b288,176|-318|0xc3af86,208|-324|0xc7b288,224|-318|0xc3af85,234|-322|0xc7b288,277|-321|0xc6b188,311|-312|0xc6b288", 90, 289, 169, 1005, 642)
	nLog("网络环境提示-x="..x)
	if x >-1 then
		tap_and_sleep(800,540);--点击确定
		return
	end
	x,y = findMultiColorInRegionFuzzy( 0xc4b086, "11|7|0xc5b087,10|17|0xc1ac84,-1|17|0xc5b086,32|2|0xc1ad85,38|17|0xbda981,-509|-16|0x2c2f34,529|1|0xceaf81,548|580|0x27272f", 90, 87, 63, 1185, 721)
	nLog("公告-x="..x)
	if x >-1 then
		tap_and_sleep(1148,117);--点击x
		return
	end	
	x,y = findMultiColorInRegionFuzzy( 0xc0ac84, "34|-9|0xc5b087,58|-9|0xc3ae85,87|2|0xbeab83,-29|326|0x876b48,131|329|0x8a6f48,0|3|0xc1ad84", 90, 289, 170, 999, 636)
	nLog("实名认证-x="..x)
	if x > -1 then
		tap_and_sleep(650,550);--点击确定
		return
	end
	x,y = findMultiColorInRegionFuzzy( 0xfef3d1, "0|7|0xfdf2cc,6|4|0xfdf2cf,43|-4|0xf5edd3,68|-3|0xf6eecd,68|3|0xfaedcb,97|1|0xd8d0b6,142|-3|0xd4ccb1,177|-2|0xf3ebc9", 90, 1025, 8, 1258, 81)
	nLog("点击此处跳过-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);--点击跳过
		return
	end
end

function dialog_tap2(...)
	-- body
	
	x,y = findMultiColorInRegionFuzzy( 0xb5a27c, "28|0|0xbaa67f,28|12|0xbdaa82,34|14|0xc2ae85,-9|14|0xbda981,7|14|0xc2ae85", 90, 604, 101, 679, 139)
	nLog("商店-x2="..x)
	if x > -1 then
		tap_and_sleep(1148,  118);
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0x37608a, "486|3|0x826945,180|-321|0xc6b288,176|-318|0xc3af86,208|-324|0xc7b288,224|-318|0xc3af85,234|-322|0xc7b288,277|-321|0xc6b188,311|-312|0xc6b288", 90, 289, 169, 1005, 642)
	nLog("网络环境提示-x="..x)
	if x >-1 then
		tap_and_sleep(800,540);--点击确定
		return
	end
	x,y = findMultiColorInRegionFuzzy( 0xc4b086, "11|7|0xc5b087,10|17|0xc1ac84,-1|17|0xc5b086,32|2|0xc1ad85,38|17|0xbda981,-509|-16|0x2c2f34,529|1|0xceaf81,548|580|0x27272f", 90, 87, 63, 1185, 721)
	nLog("公告-x="..x)
	if x >-1 then
		tap_and_sleep(1148,117);--点击x
		return
	end	
	x,y = findMultiColorInRegionFuzzy( 0xc0ac84, "34|-9|0xc5b087,58|-9|0xc3ae85,87|2|0xbeab83,-29|326|0x876b48,131|329|0x8a6f48,0|3|0xc1ad84", 90, 289, 170, 999, 636)
	nLog("实名认证-x="..x)
	if x > -1 then
		tap_and_sleep(650,550);--点击确定
		return
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xf5cb41, "144|5|0xf9d35a,-145|-196|0xc64037,289|-224|0xc43f36,423|-320|0xdebc8a,-474|-121|0x82582c,335|24|0x7a5227", 90, 206, 134, 1174, 660)
	nLog("邀请好友-x="..x)
	if x > -1 then
		tap_and_sleep(1134,223);--点击
		return
	end	
end


-- 点击
function tap_and_sleep(x,y)
	-- body
	randomTap(x,y);
	mSleep(math.random(0.1 * 1000, 1 * 1000));
end

-- 获取当前界面
function get_page(page_list)
	-- body
	for k,v in pairs(page_list) do
		--nLog(v.."");
		x, y = findMultiColorInRegionFuzzy(v.features[2], v.features[3], v.features[4], v.features[5], v.features[6], v.features[7], v.features[8]); 
		if x > -1 or y > -1 then
			return v.features[1];
		end

	end

	return "没找到界面";
end


