require("TSLib")

is_red_point_clicked = false;


function tap_and_sleep(x,y)--点击
	if x~=nil and y~=nil and x>-1 and y>-1 then
		randomTap(x,y)
		mSleep(math.random(0.1*1000,1*1000))
	end
end
function red(...)
	x,y = findMultiColorInRegionFuzzy( 0xb42412, "0|5|0xbc2719,-4|3|0xb82516,3|2|0xb12816", 90, 737, 97, 1279, 265)--上
	x3,y3 = findMultiColorInRegionFuzzy( 0xb42412, "0|5|0xbc2719,-4|3|0xb82516,3|2|0xb12816", 90, 737, 291, 1279, 646)--上
	x1,y1 = findMultiColorInRegionFuzzy( 0xb42412, "0|5|0xbc2719,-4|3|0xb82516,3|2|0xb12816", 90, 673, 650, 899, 752)--左下
	x2,y2 = findMultiColorInRegionFuzzy( 0xb42612, "2|3|0xbb2615,16|-1|0xb52d16,13|7|0xc23421", 90, 1032, 663, 1181, 701)--右下
	x4,y4 = findMultiColorInRegionFuzzy( 0xe6792b, "10|-8|0xe27623,10|-4|0xd97224,4|1|0xe37b2d", 90, 836, 654, 906, 722)--邮件红点
	x5,y5 = findMultiColorInRegionFuzzy( 0xcbb286, "24|-16|0xcfb688,12|-3|0xc4ac7e,-8|19|0xb49b6d,33|19|0x977b51,33|-41|0xb22212", 90, 814, 656, 901, 749)--邮件红点
	
	youjian_x,youjina_y = findMultiColorInRegionFuzzy( 0xcaaf82, "15|-15|0xd2ba8d,9|0|0xc0a678,13|-23|0xddcc9a,-15|20|0xb49d70,46|-33|0xb92515,23|-34|0xb72513", 90, 816, 656, 904, 748)
	
	
	if x>-1 then
		--toast("上面有红色",1)
		tap_and_sleep(x,y)
		mSleep(3000)

	elseif  x1>-1 then
		--toast("左下有红色",1)
		tap_and_sleep(x1,y1)
		mSleep(3000)

	elseif x2>-1 then
		--toast("右下有红色",1)
		tap_and_sleep(x2,y2)
		mSleep(3000)
	elseif x3>-1 then
		--toast("上面2有红色",1)
		tap_and_sleep(x3,y3)
		mSleep(3000)
		--[[else
		for var= 1, 2 do
			x3,y3 = findMultiColorInRegionFuzzy( 0xb42612, "2|3|0xbb2615,16|-1|0xb52d16,13|7|0xc23421", 90, 960, 659, 999, 685)--任务
			if x3>-1 then 
				tap_and_sleep(x,y)
				mSleep(3000)
			end]]
	elseif x4>-1 then
		--toast("找到邮件",1)
		tap_and_sleep(x4,y4)
		mSleep(3000)	
	elseif x5>-1 then
		--toast("找到邮件",1)
		tap_and_sleep(x5,y5)
		mSleep(3000)		
	elseif youjian_x > -1 then
		tap_and_sleep(youjian_x,youjina_y)
		mSleep(3000);
	else

		
		x,y = findMultiColorInRegionFuzzy( 0xc7b284, "-4|-11|0xd8c293,30|-5|0x11191a,14|-7|0xcfbe92,23|16|0xb69a6d,24|-9|0xd7bf90,-16|-9|0x162026", 90, 2, 621, 125, 753)
		nLog("红点出城-x="..x)-- 在城内  造兵
		x1,y2 = findMultiColorInRegionFuzzy( 0xa38a5e, "-47|-27|0xe6cd9f,-26|-40|0xe6d0a0,-13|-22|0x1a232e,11|-16|0x1b242e,-21|7|0xaa9063,-47|0|0xc4ab81", 90, 3, 629, 138, 758)
		nLog("红点回城-x="..x1)-- 在城外  挖矿	
		if x > -1 or x1 > -1 then
			is_red_point_clicked = true;
		else
			--toast("右半边屏幕没有红点",1)
			tap_and_sleep(1240,70)--右半边屏幕没有红点。点X
			mSleep(3000)
		end
		
		
		--[[x,y = findMultiColorInRegionFuzzy( 0xa38a5e, "-47|-27|0xe6cd9f,-26|-40|0xe6d0a0,-13|-22|0x1a232e,11|-16|0x1b242e,-21|7|0xaa9063,-47|0|0xc4ab81", 90, 3, 629, 138, 758)
		nLog("红点出城-x="..x)-- 在城外  挖矿	
		if x > -1 then
			is_red_point_clicked = true;
		end]]
		
	end
	
	return is_red_point_clicked;
	
end
function tapscreencontinue(...)

	x,y = findMultiColorInRegionFuzzy( 0x838383, "22|-3|0x878787,21|-3|0x858585,21|2|0x848484,47|2|0x7f7f7f,62|3|0x868686", 93, 571, 707, 717, 742)
	nLog("点击屏幕继续-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end

	x,y = findMultiColorInRegionFuzzy( 0x807f7f, "0|3|0x7e7e7e,20|5|0x858585,44|5|0x848484,44|9|0x848484,55|9|0x858585,79|2|0x6d6d6d,103|0|0x7e7e7e", 93, 563, 712, 725, 755)
	nLog("点击屏幕继续-x2="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end

	x,y = findMultiColorInRegionFuzzy( 0x868686, "-5|9|0x777778,22|5|0x8e8e8e,22|13|0x878787,47|10|0x8c8c8c,110|-1|0x898989,90|4|0x8e8e8e", 93, 571, 690, 719, 728)
	nLog("点击屏幕继续-x3="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end

	x,y = findMultiColorInRegionFuzzy( 0x7a7a7b, "0|2|0x7b7b7c,21|5|0x858585,20|0|0x838384,45|5|0x898989,84|4|0x8d8d8d,103|-1|0x828282", 93, 580, 692, 707, 719)
	nLog("点击屏幕继续-x4="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end
end
function hongdian(...)--等级到达6级，进行一波点红点操作

	x,y = findMultiColorInRegionFuzzy( 0x6a1413, "-120|-10|0x751214,85|-20|0xb69762,108|-24|0xbd9a64", 90, 0, 97, 303, 163)--主页面
	if x>-1 then	
		--toast("主屏幕",1)
		red()
	else
		--toast("未识别主屏幕",1)
	end



	x,y = findMultiColorInRegionFuzzy( 0xaea5b6, "0|19|0x575060,8|17|0x788898,19|19|0x8999b1,55|20|0x342c35,50|8|0x292129,53|24|0x2a222a", 90, 240, 132, 324, 199)--任务页面不需要识别红点
	if x>-1 then
		tap_and_sleep(x,y)--点击领取活跃奖励
		mSleep(3000)
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xf0ceab, "16|-4|0xe3cf9f,31|0|0xd7ba90,35|16|0xb59772,30|29|0xa98866,15|36|0xa98865,0|32|0xb89f76", 90, 472, 663, 813, 734)
	nLog("更多的图标-x="..x)
	if x <= -1 then
		tapscreencontinue(...)
	end
	


	--1,点击外交
	x,y = findMultiColorInRegionFuzzy( 0xf8f8f8, "8|8|0xf4f4f4,32|3|0xf3f3f3,33|-11|0xf9f9f9,60|-11|0xf7f7f7,69|7|0xfcfcfc,92|-1|0xf9f9f9", 90, 93, 59, 204, 85)--外交大厅页面
	if x>-1 then
		x,y = findMultiColorInRegionFuzzy( 0xc57b49, "-5|33|0x9e5c33,-26|15|0xc7b3ad,10|18|0xede8e6", 90, 99, 628, 961, 721)--识别最下面一行出现领取奖励
		if x>-1 then
			--toast("识别领取奖励",1)
			tap_and_sleep(x,y)--点击领取奖励
			mSleep(3000)
		else 
			--toast("未识别",1)
			--tap_and_sleep(1240,70)--点X

		end
	end
	x,y = findMultiColorInRegionFuzzy( 0x8c714a, "82|0|0x8b704a,37|-16|0x755c3c,20|-5|0xf3f3f3,25|-6|0xf8f7f7,48|5|0xf9f9f9", 90, 920, 349, 1135, 407)--家族详情页，权力，冷淡出现红点点击升级
	if x>-1 then
		x,y = findMultiColorInRegionFuzzy( 0xb42412, "-3|2|0xb72415,0|6|0xc12826", 90, 89, 165, 105, 187)
		if x>-1 then
			--toast("左边有红点",1)
			tap_and_sleep(1029,377)--如果识别到升级并且识别左边有红点，点击升级
			mSleep(3000)
		else
			--toast("左边没有红点",1)
			--tap_and_sleep(1240,70)--否则点X

		end
	end
	--[[x,y = findMultiColorInRegionFuzzy( 0x7c7b7b, "-5|4|0x737272,20|2|0x868686,20|-2|0x828282,45|2|0x8a8a8a,85|1|0x898989,103|-3|0x828282", 90, 579, 728, 701, 753)--点击屏幕继续
	if x>-1 then
		tap_and_sleep(x,y)--点击屏幕继续
		mSleep(3000)
	end]]
--2,任务

	x,y = findMultiColorInRegionFuzzy( 0xfcfcfc, "0|9|0xededee,11|-5|0xfefefe,40|12|0xfbfbfb,43|1|0xf9f9f9", 90, 93, 54, 148, 87)--识别任务页面
	if x>-1  then

		--toast("识别到任务页面",1)
		red()
	end
--[[if (isColor(1214,  171, 0xc6b68d, 85) and 
	isColor(1206,  131, 0xb3a37d, 85) and 
	isColor(1267,  166, 0x4f4532, 85)) then
	x,y = findMultiColorInRegionFuzzy( 0x375e86, "62|1|0x345e85,31|-10|0x30567d,14|7|0xd5d6d7,39|8|0xe8e8e9", 90, 993, 299, 1140, 633)
	if x>-1 then
		tap_and_sleep(x,y)--点击前往
		mSleep(3000)
	end
end]]
--2.1在商城中购买特惠礼包1次
	x,y = findMultiColorInRegionFuzzy( 0xebcd8b, "6|-6|0xf7dc99,-11|-2|0xf3da98,-17|1|0xf1d38f", 90, 1164, 190, 1235, 261)--识别主页面商城下面的手指
	if x>-1 then
		--toast("识别到手指",1)
		tap_and_sleep(1208,151)
		mSleep(3000)
	end
--进入商城页面，每日特惠，领取宝箱
	x,y = findMultiColorInRegionFuzzy( 0x9e7d5f, "22|-4|0x80806f,23|-15|0xdab998,50|-22|0xeccbb0", 90, 917, 108, 1030, 230)--免费领取宝箱
	if x>-1 then
		tap_and_sleep(x,y)
		mSleep(3000)
	end
--2.1目标任务
	x,y = findMultiColorInRegionFuzzy( 0x846a46, "0|10|0x997d51,70|7|0x92764e,81|-1|0x826845,47|4|0xd9d8d7,30|7|0xe1dfdd", 90, 1010, 224, 1148, 710)--区域内有领取
	if x>-1 then
		for var= 1, 5 do
			x,y = findMultiColorInRegionFuzzy( 0x846a46, "0|10|0x997d51,70|7|0x92764e,81|-1|0x826845,47|4|0xd9d8d7,30|7|0xe1dfdd", 90, 1010, 224, 1148, 710)
			if x > -1 then
				tap_and_sleep(x,y);

			end
		end
		tap_and_sleep(1240,70)
	end
--2.2联盟任务
	if (isColor(1213,  257, 0xccbc92, 85) and 
		isColor(1214,  225, 0xa49373, 85) and 
		isColor(1269,  247, 0x4e4533, 85)) then
		x,y = findMultiColorInRegionFuzzy( 0x375f86, "42|-9|0x325980,99|6|0x386088,30|8|0xe9eaeb,58|-2|0xe7e8ea,78|1|0xf1f2f2", 90, 1007, 224, 1150, 653)
		if x>-1 then
			tap_and_sleep(x,y)
			mSleep(3000)
		end
	end
--2联盟
	
	x,y = findMultiColorInRegionFuzzy( 0x8b6f49, "38|13|0xab905b,143|-5|0x826845,-96|5|0x3a658d,-247|8|0x3d6993,-173|-15|0x31577e,-158|8|0xedeef0,39|3|0xebeae7", 90, 538, 515, 995, 570)--加入联盟
	if x>-1 then
		--toast("加入联盟",1)
		tap_and_sleep(904,544)
		mSleep(3000)
	end
	x,y = findMultiColorInRegionFuzzy( 0x182f62, "13|-23|0x1c579b,10|9|0x1a3f8c,29|-16|0x245697,-33|262|0x997d51,72|258|0x8d734c,-34|-185|0xfeca67,190|-177|0xffd57b", 90, 463, 144, 827, 666)--首次加入联盟奖励
	if x>-1 then
		tap_and_sleep(626,616)
		mSleep(2000)
	end
	x,y = findMultiColorInRegionFuzzy( 0xf4f4f4, "0|8|0xfcfcfc,5|7|0xf9f9f9,14|3|0xf8f8f8,46|-8|0xf7f7f7,34|1|0xf6f6f6", 90, 92, 58, 146, 86)--识别联盟
	if x>-1 then
		--toast("联盟",1)
		x,y = findMultiColorInRegionFuzzy( 0xb82616, "6|-8|0xb02512,11|-7|0xb12410,14|-1|0xb72515,19|-1|0xb72515", 90, 809, 505, 1006, 543)--识别联盟礼物和联盟帮助红色
		if x>-1 then 
			tap_and_sleep(x,y)
			mSleep(2000)
		end
		while (true) do
			x,y = findMultiColorInRegionFuzzy( 0x3a648d, "56|-4|0x366089,-6|-16|0x345b84,80|10|0x3e6890,21|-5|0xf4f5f6,38|-2|0xeeeef0", 90, 1062, 347, 1189, 397)
			if x>-1 then
				tap_and_sleep(x,y)--点击帮助 
				mSleep(2000)
			end
		end
		x,y = findMultiColorInRegionFuzzy( 0xcebd94, "49|9|0x534a36,56|-17|0x4f4634,9|-28|0x837253,-547|445|0x836945,-667|452|0x90744c,-600|451|0xd2d0ce", 90, 463, 144, 827, 666)--加入联盟
		if x>-1 then
			tap_and_sleep(582,704)--点击一键加入
			mSleep(2000)
		end
	end
	
	
--3指挥官
	x,y = findMultiColorInRegionFuzzy( 0x393f47, "-52|24|0x541718,-52|-86|0x313031,-106|34|0xb0474c,-15|34|0x3f3636,-24|-48|0x6d6067", 90, 84, 166, 304, 369)--识别指挥官页面
	if x>-1 then
		--toast("找到指挥官页面",1)
		x,y = findMultiColorInRegionFuzzy( 0xd59022, "0|-8|0xe19928,49|-8|0xd88226,63|12|0xc96908", 90, 234, 165, 1144, 198)--人物头像上有品质提升的，点那个人物
		if x>-1 and y>-1 then
			tap_and_sleep(x,y)--选择一名指挥官
			mSleep(3000)
		end
		x,y = findMultiColorInRegionFuzzy( 0x907245, "106|0|0x997a45,124|13|0xa88853,45|-15|0x80643c,24|9|0xf1efed,45|-3|0xf7f7f6,86|-3|0xfdfcf8", 90, 949, 655, 1165, 718)
		if x>-1 then
			tap_and_sleep(1041,675)
			mSleep(3000)
		end
	else
		--toast("未找到指挥官页面",1)
		--tap_and_sleep(1240,70)--点X
	end
--4邮件
	x,y = findMultiColorInRegionFuzzy( 0x39628b, "50|1|0x3a658d,60|-7|0x345981,-15|4|0x38628c,14|3|0xe4e7e9,32|4|0xe0e1e2", 90, 306, 687, 398, 722)--邮件页面,识别管理
	if x>-1  then 

		--toast("识别到邮件页面",1)
		tap_and_sleep(252,700)

		while (true) do
			x,y = findMultiColorInRegionFuzzy( 0xb42411, "0|7|0xbe271d,3|3|0xb72515,19|3|0xb72515,23|3|0xb42616,18|-3|0xb02410,18|9|0xc1281b", 90, 1193, 111, 1279, 589)
			if x > -1 then
				tap_and_sleep(x,y);
			else
				break
			end
		end
	
	end
--5福利
--5.1游戏更新
	x,y = findMultiColorInRegionFuzzy( 0x38628a, "72|-2|0x386088,22|5|0xf8f9f9,48|-3|0xe7e7e7,309|2|0x8e724b,419|0|0x896e49,353|5|0xe9e8e7,389|4|0xedebeb", 90, 362, 517, 909, 572)
	if x>-1 then 
		tap_and_sleep(808,562)
		mSleep(10*1000)
	end
	x,y = findMultiColorInRegionFuzzy( 0xf9f9f9, "-5|0|0xeaeaea,6|4|0xfbfbfb,11|7|0xfbfbfb,24|1|0xfafafa,25|-9|0xf7f7f7,38|8|0xf9f9f9", 90, 91, 55, 148, 85)--福利页面
	if x>-1 then 
		--toast("福利页面",1)
		x,y = findMultiColorInRegionFuzzy( 0xbb8d49, "-5|38|0xba924e,70|35|0x705038,67|17|0x735238", 90, 1163, 325, 1275, 428)--选中幸运直购
		if x>-1 then 
			x,y = findMultiColorInRegionFuzzy( 0xa77f67, "35|-2|0xb99777,41|-29|0x463e36,61|3|0x302118", 90, 691, 128, 774, 205)--识别领取宝箱
			if x>-1 then 
				tap_and_sleep(719,168)
				mSleep(3000)
			end
		end
		x,y = findMultiColorInRegionFuzzy( 0xc79e55, "-5|34|0xcaa462,66|15|0x745138,79|-1|0x735239", 90, 1163, 426, 1279, 529)--选中勇士征召
		if x>-1 then
			--toast("勇士征召",1)
			if (isColor( 751,  383, 0x61418b, 85) and 
				isColor( 871,  383, 0x62438b, 85) and 
				isColor( 817,  366, 0x56397c, 85) and 
				isColor( 811,  402, 0xa075d3, 85)) then
				tap_and_sleep(811,384)
				mSleep(3000)
			end
		end
		x,y = findMultiColorInRegionFuzzy( 0xb8904b, "-1|-33|0xc49a51,67|-19|0x745238,49|6|0x835e38", 90, 1164, 221, 1279, 323)--随选特卖会
		if x>-1 then
			if (isColor( 984,  204, 0x5e3f86, 85) and 
				isColor(1087,  208, 0x61418a, 85) and 
				isColor(1035,  224, 0x8c64bd, 85) and 
				isColor(1031,  192, 0x563a7c, 85)) then
				tap_and_sleep(992,202)
				mSleep(3000)
			end
		end
	end
	x,y = findMultiColorInRegionFuzzy( 0x886d48, "18|14|0xecebea,66|16|0xf4f2f1,25|9|0xf3f3f2,411|0|0x37608a,445|2|0xd0d1d2,470|1|0xe9eaec", 90, 323, 615, 869, 672)--恭喜获得
	if x>-1 then
		--toast("获得奖励",1)
		tap_and_sleep(856,646)
		mSleep(3000)
	else
		--toast("未识别获得奖励",1)
	end
--背包
	x,y = findMultiColorInRegionFuzzy( 0xefefef, "1|4|0xfbfbfb,1|9|0xfcfcfc,18|10|0xfbfbfb,34|11|0xfdfdfd,19|-8|0xfbfbfb", 90, 90, 57, 148, 90)--背包
	if x>-1 then
		--toast("背包页面",1)
		if (isColor(1208,  169, 0xd3c299, 85) and 
			isColor(1254,  177, 0x554c37, 85) and 
			isColor(1267,  194, 0x4d4532, 85) and 
			isColor(1267,  139, 0x4e4532, 85) and 
			isColor(1235,  126, 0x5e563e, 85)) then
			--toast("点击资源",1)
			tap_and_sleep(308,139)
			mSleep(3000)
			for var= 1, 50 do
				x,y = findMultiColorInRegionFuzzy( 0x38618b, "-65|0|0x38618a,-34|-14|0x30587e,-29|18|0x5586b2,-47|1|0xebebeb,-40|7|0xeff0f1", 90, 751, 162, 1136, 746)
				if x>-1 then
					tap_and_sleep(x,y)
					mSleep(200)
				end
			end

			tap_and_sleep(845,139)
			mSleep(3000)
		end
		x,y = findMultiColorInRegionFuzzy( 0xa2926d, "68|-11|0x86785a,91|-11|0x766951,-39|-17|0x5b5343", 90, 766, 115, 951, 160)--宝箱
		if x>-1 then
			for var= 1, 50 do
				x,y = findMultiColorInRegionFuzzy( 0x38618b, "-65|0|0x38618a,-34|-14|0x30587e,-29|18|0x5586b2,-47|1|0xebebeb,-40|7|0xeff0f1", 90, 751, 162, 1136, 746)
				if x>-1 then
					tap_and_sleep(x,y)
					mSleep(500)
					tap_and_sleep(716,597)
				end

			end
		end
	end
	
	x,y = findMultiColorInRegionFuzzy( 0xfcfcfc, "0|-5|0xfcfcfc,5|8|0xfbfbfb,34|5|0xf4f5f5,-11|9|0xfcfcfc,16|7|0xf3f3f3", 90, 94, 54, 143, 86)
	if x>-1 then
		--toast("活动页面",1)
		x,y = findMultiColorInRegionFuzzy( 0xeb7964, "-2|20|0xaa403f,0|24|0xb34543,10|9|0xd6a74f,2|-10|0xe26967", 90, 212, 134, 829, 213)
		if x>-1 then
			--toast("右上角有宝箱",1)
			tap_and_sleep(x,y)
			mSleep(3000)
			
			while (true) do
				x,y = findMultiColorInRegionFuzzy( 0x987b50, "8|-20|0x775e41,40|-20|0x775e3f,72|-2|0x8f744e,21|-3|0xd4d2d0,44|-5|0xdad8d6", 90, 968, 208, 1120, 445)--领取
				if x>-1 then
					--toast("领取奖励",1)
					tap_and_sleep(x,y)
					mSleep(1000)
				else
					break
				end
			end
		end
	end
	

	
end


function set_clicked_false()
	is_red_point_clicked = false;
end

function red_point_click(...)
	while (true) do
		if is_red_point_clicked then
			break
		else
			hongdian();
			red();
		end

	end
end
