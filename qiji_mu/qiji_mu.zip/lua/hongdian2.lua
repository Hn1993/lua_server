require("TSLib")

is_red_point_clicked = false;

-- 滑动
function swipe(x,y)
	-- body
	moveTo(1225,550,1125,250)
	
end

-- 点击
function tap_and_sleep(x,y)
	-- body
	randomTap(x,y);
	mSleep(math.random(0.1 * 1000, 1 * 1000));
end

function set_red_point_clicked(...)
	-- body
	is_red_point_clicked = false;
end

function tapscreencontinue(...)

	x,y = findMultiColorInRegionFuzzy( 0x838383, "22|-3|0x878787,21|-3|0x858585,21|2|0x848484,47|2|0x7f7f7f,62|3|0x868686", 93, 571, 707, 717, 742)
	nLog("点击屏幕继续-x="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end

	x,y = findMultiColorInRegionFuzzy( 0x807f7f, "0|3|0x7e7e7e,20|5|0x858585,44|5|0x848484,44|9|0x848484,55|9|0x858585,79|2|0x6d6d6d,103|0|0x7e7e7e", 93, 563, 712, 725, 755)
	nLog("点击屏幕继续-x2="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end

	x,y = findMultiColorInRegionFuzzy( 0x868686, "-5|9|0x777778,22|5|0x8e8e8e,22|13|0x878787,47|10|0x8c8c8c,110|-1|0x898989,90|4|0x8e8e8e", 93, 571, 690, 719, 728)
	nLog("点击屏幕继续-x3="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end

	x,y = findMultiColorInRegionFuzzy( 0x7a7a7b, "0|2|0x7b7b7c,21|5|0x858585,20|0|0x838384,45|5|0x898989,84|4|0x8d8d8d,103|-1|0x828282", 93, 580, 692, 707, 719)
	nLog("点击屏幕继续-x4="..x)
	if x > -1 then
		tap_and_sleep(x,y);
		return
	end
end

--点击红点方法
function click_red_point(...)
	-- body
	
	while (true) do
		--::find_red_point::
		x,y = findMultiColorInRegionFuzzy( 0xf0ceab, "16|-4|0xe3cf9f,31|0|0xd7ba90,35|16|0xb59772,30|29|0xa98866,15|36|0xa98865,0|32|0xb89f76", 90, 472, 663, 813, 734)
		nLog("更多的图标-x="..x)
		if x <= -1 then
			tapscreencontinue(...)
		end
		
		--1.判断是不是在首页
		chengnei_x,chengnei_y = findMultiColorInRegionFuzzy( 0xc7b284, "-4|-11|0xd8c293,30|-5|0x11191a,14|-7|0xcfbe92,23|16|0xb69a6d,24|-9|0xd7bf90,-16|-9|0x162026", 90, 2, 621, 125, 753)
		nLog("出城-x="..chengnei_x)-- 在城内  造兵
		huodong_x,huodong_y = findMultiColorInRegionFuzzy( 0xb82616, "-22|25|0xfff0c5,-32|16|0xfdebc0,-39|24|0xfff2c2,-12|29|0xfff4c6,1|13|0xffe9bd", 90, 968, 102, 1045, 176)
		fuli_x,fuli_y = findMultiColorInRegionFuzzy( 0xb82616, "-23|7|0xffe6b8,-20|7|0xffe6b8,-21|13|0xffeeba,-31|31|0xfff4c6,-12|29|0xfff3c6,-34|14|0xffeabb", 90, 1047, 101, 1120, 176)
		shangcheng_x,shangcheng_y = findMultiColorInRegionFuzzy( 0xbb2118, "-3|-2|0xb82212,0|-5|0xb6210f,4|-2|0xb62111,2|-1|0xba2114,0|-2|0xb82212", 90, 1258, 100, 1279, 117)
		--lianmeng_x,lianmeng_y = findMultiColorInRegionFuzzy( 0xefd8a9, "-1|31|0xbea478,25|26|0xad9264,12|-3|0xedcba9,29|-8|0xba2414,54|-9|0xb12a19", 90, 724, 650, 808, 734)
		youjian_x,youjian_y = findMultiColorInRegionFuzzy( 0xcbb183, "10|-11|0xd2ba8d,11|-19|0xdec697,-17|24|0xb69b6c,24|-36|0xb22211", 90, 813, 653, 901, 727)
		--zhihui_x,zhihui_y= findMultiColorInRegionFuzzy( 0xceb487, "8|1|0xc8ad7f,-9|18|0xbba174,16|18|0xaa8d60,19|-22|0xba2414,44|-22|0xb72a19", 90, 1100, 655, 1194, 750)
		
		chengwai_x,chengwai_y = findMultiColorInRegionFuzzy( 0xa38a5e, "-47|-27|0xe6cd9f,-26|-40|0xe6d0a0,-13|-22|0x1a232e,11|-16|0x1b242e,-21|7|0xaa9063,-47|0|0xc4ab81", 90, 3, 629, 138, 758)
		nLog("回城-x="..x)-- 在城内  造兵
		
		if huodong_x <= -1 and fuli_x <= -1  and shangcheng_x <= -1  and youjian_x <= -1 and  chengnei_x > -1 then
			break
		elseif huodong_x <= -1 and fuli_x <= -1  and shangcheng_x <= -1  and youjian_x <= -1 and  chengwai_x > -1 then
			break
		else
			--[[x,y = findMultiColorInRegionFuzzy( 0xc7b284, "-4|-11|0xd8c293,30|-5|0x11191a,14|-7|0xcfbe92,23|16|0xb69a6d,24|-9|0xd7bf90,-16|-9|0x162026", 90, 2, 621, 125, 753)
			nLog("出城-x="..x)-- 在城内  造兵
			if x <= -1 then
				tap_and_sleep(1240,70);--点击关闭
				mSleep(2000);
			end]]
			
			if chengnei_x <= -1 and chengwai_x <= -1 then
				tap_and_sleep(1240,70);--点击关闭
				mSleep(2000);
			end
			
			
			
			x,y = findMultiColorInRegionFuzzy( 0xb82616, "-22|25|0xfff0c5,-32|16|0xfdebc0,-39|24|0xfff2c2,-12|29|0xfff4c6,1|13|0xffe9bd", 90, 968, 102, 1045, 176)
			nLog("活动红点-x="..x)
			if x > -1 then
				local has_huodong_swpie = false;
				tap_and_sleep(x-20,y+10);--点击红点
				mSleep(2000);
				x,y = findMultiColorInRegionFuzzy( 0xfcfcfc, "0|4|0xfcfcfc,-11|14|0xfcfcfc,16|12|0xf5f5f5,44|9|0xf7f8f8,72|9|0xf8f8f8,86|15|0xfefefe,34|3|0xfbfbfb", 90, 82, 42, 219, 93)
				nLog("活动中心-x="..x)
				if x > -1 then
					while (true) do
						::huodong_hongdian::
											
						x,y = findMultiColorInRegionFuzzy( 0xb72414, "19|0|0xb72414,15|-1|0xb62413,14|3|0xba2618,3|2|0xb82516,4|0|0xb72414,2|-2|0xb42412,-1|-2|0xb42412", 90, 1229, 111, 1274, 682)
						nLog("右侧红点-x="..x)
						if x > -1 then
							tap_and_sleep(x,y);
							mSleep(500);
							
							x,y = findMultiColorInRegionFuzzy( 0xb62514, "-7|0|0xb62514,-4|-2|0xb32411,-4|5|0xc02724,-6|3|0xbc261a,-4|1|0xb72415,-3|1|0xb72415,-1|3|0xbc261a", 90, 638, 126, 1163, 176)
							nLog("上面红点-x="..x)
							if x > -1 then
								tap_and_sleep(x-20,y+5);--点击红点
							end
							
							
							x,y = findMultiColorInRegionFuzzy( 0x735a3c, "139|3|0x765d3d,2|43|0xa68d5b,144|41|0xa28a58,61|20|0xdbd9d7,66|21|0xd4d3d2,76|24|0xeeedea,86|23|0xeeeeed", 90, 961, 161, 1148, 743)
							nLog("领取按钮-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);--点击领取
							end
							
							x,y = findMultiColorInRegionFuzzy( 0x786040, "127|0|0x785e40,5|36|0xac8f5c,125|33|0xaa8d5a,57|20|0xd3d1ce,67|20|0xa28455", 90, 947, 280, 1155, 695)
							nLog("领取按钮-x2="..x)
							if x > -1 then
								tap_and_sleep(x,y);--点击领取
							end
							
							x,y = findMultiColorInRegionFuzzy( 0xf1f0f0, "23|-10|0xcdcdcd,18|-9|0xdedede,-62|-22|0x605b5c,80|-21|0x585353,81|9|0x6d6a6a,-60|7|0x646464,7|-15|0x5d5a59", 90, 955, 251, 1155, 746)
							nLog("灰色兑换按钮-x2="..x)
							if x > -1 then
								moveTo(1058,733,1058,233)
								mSleep(1500)
								
								x,y = findMultiColorInRegionFuzzy( 0xdfdcd9, "24|-4|0xd2d0ce,22|1|0xefefee,-64|-17|0x785f3f,83|-18|0x775d3f,83|17|0xab8f5b,-63|17|0xa98e5b", 90, 973, 251, 1147, 755)
								nLog("金色兑换按钮-x2="..x)
								if x > -1 then
									tap_and_sleep(x,y);
									mSleep(1000);
									tap_and_sleep(778,553);--点击确定
								end
							end
							
							
						else
							
							if has_huodong_swpie == false then
								mSleep(1000);
								moveTo(1225,550,1225,250)
								mSleep(1000);
								has_huodong_swpie = true;
								goto huodong_hongdian; --重新查找红点
							end
							
							
							
							
							if has_huodong_swpie then
								
								tap_and_sleep( 1240,   70);--点击关闭
								break
							end
							
							--tap_and_sleep( 1240,   70);--点击关闭
							--break	
						end	
					end
				
					
				end
				
				--goto find_red_point;
			end
			
			x,y = findMultiColorInRegionFuzzy( 0xb82616, "-23|7|0xffe6b8,-20|7|0xffe6b8,-21|13|0xffeeba,-31|31|0xfff4c6,-12|29|0xfff3c6,-34|14|0xffeabb", 90, 1047, 101, 1120, 176)
			nLog("福利红点-x="..x)
			if x > -1 then
				local has_swpie = false;
				tap_and_sleep(x-20,y+10);--点击红点
				mSleep(2000);
				x,y = findMultiColorInRegionFuzzy( 0xf9f9f9, "7|2|0xfcfcfc,4|0|0xf0f0f0,30|1|0xfefefe,31|-9|0xf9f9f9,45|8|0xfdfdfd", 90, 86, 48, 150, 87)
				nLog("福利界面-x="..x)
				if x > -1 then
					
					while (true) do
						::fuli_hongdian::
						
						x,y = findMultiColorInRegionFuzzy( 0xdadbdc, "32|-2|0x38628a,-87|-19|0x365f89,117|21|0x406a92,-413|-17|0xfff8c9,-307|-15|0x775c3f,-420|10|0xe9e7e5,-481|-16|0x765d3f", 90, 263, 576, 980, 676)
						nLog("确认对话框-x="..x)
						if x > -1 then
							tap_and_sleep(x,y)
						end	
						
						
						
						x,y = findMultiColorInRegionFuzzy( 0xb72414, "19|0|0xb72414,15|-1|0xb62413,14|3|0xba2618,3|2|0xb82516,4|0|0xb72414,2|-2|0xb42412,-1|-2|0xb42412", 90, 1229, 111, 1274, 682)
						nLog("右侧红点-x="..x)
						if x > -1 then
							tap_and_sleep(x,y)
							mSleep(500);
							x,y = findMultiColorInRegionFuzzy( 0x71563d, "146|2|0x73593f,1|47|0xa38a58,147|47|0xa88f5e,82|27|0xf2f0ef,92|26|0xf5f5f5,62|24|0xe8e7e6", 90, 982, 286, 1151, 610)
							nLog("领取按钮-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);--点击领取
							end
							
							
							x,y = findMultiColorInRegionFuzzy( 0x54387c, "-102|-3|0x5d3e86,-102|39|0x664791,100|38|0x6a4997,105|-6|0xbb2518,86|15|0x5d3e86", 90, 538, 100, 1146, 715)
							nLog("免费按钮-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);--点击领取
							end
							
							x,y = findMultiColorInRegionFuzzy( 0x563a7c, "-82|-5|0x5e3f86,-80|34|0x674791,83|35|0x6a4994,92|-8|0xbc261a,94|-10|0xb72415,-15|19|0xf8f8f9,13|8|0xf0eff1", 90, 934, 163, 1141, 249)
							nLog("试试手气-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);--试试手气
							end
							
							x,y = findMultiColorInRegionFuzzy( 0xe4c2aa, "2|8|0xd0a78f,28|1|0xf5d0af,50|46|0x806047,45|55|0x765b43", 90, 22, 482, 160, 590)
							nLog("箱子免费领取-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);
							end	
							
						else
							if has_swpie == false then
								mSleep(1000);
								moveTo(1225,550,1125,250)
								mSleep(1000);
								has_swpie = true;
								goto fuli_hongdian; --重新查找红点
							end
							
							
							
							
							if has_swpie then
								
								tap_and_sleep( 1240,   70);--点击关闭
								break
							end
						end
						mSleep(500);
					end
				end
				--goto find_red_point;
			end
			
			x,y = findMultiColorInRegionFuzzy( 0xbb2118, "-3|-2|0xb82212,0|-5|0xb6210f,4|-2|0xb62111,2|-1|0xba2114,0|-2|0xb82212", 90, 1258, 100, 1279, 117)
			nLog("商城红点-x="..x)
			if x > -1 then
				tap_and_sleep(x-20,y+10);--点击红点
				mSleep(2000);
				x,y = findMultiColorInRegionFuzzy( 0xf5f5f6, "4|4|0xfafafa,-1|9|0xf8f8f8,3|17|0xfdfdfd,31|10|0xfefefe,29|5|0xf9f9f9,16|2|0xf8f8f8,21|12|0xebebeb", 90, 79, 41, 162, 97)
				nLog("商城界面-x="..x)
				if x > -1 then
					while (true) do
						x,y = findMultiColorInRegionFuzzy( 0xb52413, "4|0|0xb52413,4|4|0xb92617,17|4|0xb92617,17|0|0xb52413,21|0|0xb52413,21|3|0xb82516,3|6|0xbf2719", 90, 1211, 117, 1268, 523)
						nLog("右侧红点-x="..x)
						if x > -1 then
							tap_and_sleep(x,y)
							mSleep(500);
							x,y = findMultiColorInRegionFuzzy( 0xe3c2ab, "3|10|0xd9b197,5|21|0xcea687,64|9|0xededed,58|9|0xc7a68b,53|17|0xe6c9ac,66|77|0x9d53bd", 90, 904, 101, 1034, 226)
							nLog("领取的箱子-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);--点击领取
							end
							
							x,y = findMultiColorInRegionFuzzy( 0xe0bfa8, "63|13|0xedf0ed,48|52|0x87654d,14|49|0x99785f,46|10|0xf3d2b6,-3|1|0xe4c2a7", 90, 911, 103, 1039, 224)
							nLog("领取的箱子-x2="..x)
							if x > -1 then
								tap_and_sleep(x,y);--点击箱子
							end
						else
							tap_and_sleep( 1240,   70);--点击关闭
							break
						end
						mSleep(500);
					end
				end
				--goto find_red_point;
			end
			
			
			--[[x,y = findMultiColorInRegionFuzzy( 0xefd8a9, "-1|31|0xbea478,25|26|0xad9264,12|-3|0xedcba9,29|-8|0xba2414,54|-9|0xb12a19", 90, 724, 650, 808, 734)
			nLog("联盟红点-x="..x)
			if x > -1 then
				tap_and_sleep(x,y);--点击红点
				mSleep(2000);
				
				x,y = findMultiColorInRegionFuzzy( 0x355f88, "2|45|0x3a648c,445|-1|0x73543f,447|45|0xa58b59,94|22|0xf1f1f2,424|22|0x8d714c", 90, 526, 501, 1012, 582)
				nLog("加入联盟提示-x="..x)
				if x > -1 then
					tap_and_sleep(966,  541);--点击加入
					mSleep(3000)
					tap_and_sleep(  594,  695);--点击一键加入
					mSleep(3000);
				end
				
				x,y = findMultiColorInRegionFuzzy( 0xf9f9f9, "-5|1|0xfcfcfc,9|-3|0xf9f9f9,13|4|0xfafafa,29|-11|0xf8f8f8,34|-9|0xf9f9f9,40|-5|0xfcfcfc", 90, 84, 50, 154, 87)
				nLog("联盟界面-x="..x)
				if x > -1 then
					while (true) do
						x,y = findMultiColorInRegionFuzzy( 0xb72414, "19|0|0xb72414,15|-1|0xb62413,14|3|0xba2618,3|2|0xb82516,4|0|0xb72414,2|-2|0xb42412,-1|-2|0xb42412", 90, 1229, 111, 1274, 682)
						nLog("右侧红点-x="..x)
						x1,y1 = findMultiColorInRegionFuzzy( 0xb92514, "24|0|0xb62515,24|2|0xb72617,0|-1|0xb62513", 90, 1239, 116, 1277, 663)
						if x > -1 or x1 > -1  then
							if x > -1 then
								tap_and_sleep(x,y)
							else
								tap_and_sleep(x1,y1)
							end
							
							
							mSleep(2000);
							x,y = findMultiColorInRegionFuzzy( 0xb42412, "0|5|0xba2617,23|5|0xb92617,23|2|0xb62414,20|-3|0xb02411", 90, 616, 490, 1167, 737)
							nLog("联盟-内容里有红点-x="..x)
							if x > -1 then
								tap_and_sleep(x,y);
								mSleep(2000);
								
								x,y = findMultiColorInRegionFuzzy( 0x71583c, "205|-1|0x72553f,0|42|0xa58c59,205|41|0xa58b59,127|25|0xf2f0ef", 90, 528, 655, 756, 725)
								nLog("全部帮助-x="..x)
								if x > -1 then
									tap_and_sleep(x,y);
									tap_and_sleep(x,y);
									tap_and_sleep(x,y);
									tap_and_sleep( 1240,   70);--点击关闭
								end
								
								x,y = findMultiColorInRegionFuzzy( 0x72573d, "206|1|0x73593f,2|43|0xa58c5a,206|43|0xa18856,128|24|0xefedec,107|35|0xb99b63", 90, 756, 630, 992, 700)
								nLog("全部领取-x="..x)
								if x > -1 then
									tap_and_sleep(x,y);
									tap_and_sleep(x,y);
									tap_and_sleep(x,y);
									tap_and_sleep( 1240,   70);--点击关闭
								end
								
							end
						
							
						else
							tap_and_sleep( 1240,   70);--点击关闭
							break
						end
					end
					
					
				end
				
				--goto find_red_point;
				
			end
			]]
			
			x,y = findMultiColorInRegionFuzzy( 0xe6cd9f, "-2|22|0xbea779,28|21|0xa2895d,26|-4|0xd4ba8d,31|-25|0xb12615", 90, 1000, 653, 1099, 749)
			nLog("背包红点-x="..x)
			if x > -1 then
				tap_and_sleep(x,y);
				mSleep(2000);
				x,y = findMultiColorInRegionFuzzy( 0xe9e9e9, "6|1|0xf8f8f8,9|6|0xf1f1f1,9|9|0xfafafa,-2|10|0xf9f9f9,25|5|0xfbfbfb,39|1|0xfdfdfd,42|17|0xfdfdfd", 90, 81, 42, 153, 94)
				nLog("背包界面-x="..x)
				if x > -1 then
					tap_and_sleep(  337,  141); --点击资源
					mSleep(1000);
					while (true) do
						x,y = findMultiColorInRegionFuzzy( 0x355f89, "173|2|0x2f5279,0|47|0x386b94,174|43|0x3d6790,69|19|0xecedef,97|17|0xdadde3,88|35|0x5280ac", 90, 714, 171, 1151, 663)
						nLog("使用-x="..x)
						if x > -1 then
							tap_and_sleep(x,y);--点击使用
						else
							break
						end
					end
					
					
					tap_and_sleep(  674,  137)--点击战斗
					mSleep(1000);
					while (true) do
						x,y = findMultiColorInRegionFuzzy( 0x355f89, "173|2|0x2f5279,0|47|0x386b94,174|43|0x3d6790,69|19|0xecedef,97|17|0xdadde3,88|35|0x5280ac", 90, 714, 171, 1151, 663)
						nLog("使用-x="..x)
						if x > -1 then
							tap_and_sleep(x,y);--点击使用
						else
							tap_and_sleep( 1240,   70);--点击关闭
							break
						end
					end
					
				end
			end
			
			x,y = findMultiColorInRegionFuzzy( 0xcbb183, "10|-11|0xd2ba8d,11|-19|0xdec697,-17|24|0xb69b6c,24|-36|0xb22211", 90, 813, 653, 901, 727)
			nLog("邮件红点-x="..x)
			if x > -1 then
				tap_and_sleep(x,y)
				mSleep(2000);
				x,y = findMultiColorInRegionFuzzy( 0xfafafa, "15|7|0xfbfbfb,26|-2|0xfafafa,38|-4|0xfdfdfd,26|-2|0xfafafa,16|5|0xfafafa", 90, 85, 48, 148, 90)
				if x > -1 then
					while (true) do
						x,y = findMultiColorInRegionFuzzy( 0xb72514, "1|-3|0xb32411,12|-7|0xb02310,12|8|0xc32a19,25|-1|0xb22514", 90, 1185, 107, 1232, 580)
						nLog("右侧红点-x="..x)
						if x > -1 then
							tap_and_sleep(x+20,y+10);
							mSleep(1000);
							x,y = findMultiColorInRegionFuzzy( 0x73553f, "0|25|0xa68d5b,100|25|0xa78e57,100|2|0x765b3f,48|24|0xdcba76", 90, 129, 687, 407, 728)
							if x > -1 then
								tap_and_sleep(x,y);--点击一键已读
							end
						else
							tap_and_sleep( 1240,   70);--点击关闭
							break
						end
					end
				end
				--goto find_red_point;
			end
			
			
			--[[x,y = findMultiColorInRegionFuzzy( 0xceb487, "8|1|0xc8ad7f,-9|18|0xbba174,16|18|0xaa8d60,19|-22|0xba2414,44|-22|0xb72a19", 90, 1100, 655, 1194, 750)
			nLog("指挥官红点-x="..x)
			if x > -1 then
				tap_and_sleep(x,y)
				mSleep(2000);
				x,y = findMultiColorInRegionFuzzy( 0xfafafa, "2|0|0xfdfdfd,2|8|0xf6f6f6,18|1|0xfbfbfb,31|-8|0xf9f9f9,30|0|0xfdfdfd,71|-4|0xf8f8f8", 90, 79, 47, 188, 93)
				nLog("指挥官界面-x="..x)
				if x > -1 then
					
					x,y = findMultiColorInRegionFuzzy( 0x765d3f, "-1|40|0xa28a58,199|36|0xa98d5b,199|3|0x795f41,53|15|0xe4e2e2,62|15|0xe2e1e1,78|16|0xdedddc", 90, 827, 651, 1063, 739)
					nLog("解锁指挥官-x="..x)
					if x > -1 then
						tap_and_sleep(x,y);
					end
					
					while (true) do
						x,y = findMultiColorInRegionFuzzy( 0xb62413, "14|0|0xb62413,3|-3|0xb22410,18|3|0xb82616,-1|4|0xba2618", 90, 1232, 107, 1279, 391)
						nLog("右侧红点-x="..x)
						if x > -1 then
							tap_and_sleep(x,y);
							mSleep(1000)
							hd_x,hd_y = findMultiColorInRegionFuzzy( 0xdd3236, "4|-4|0xec4242,4|7|0xc61a1c,10|1|0xda2e33,3|1|0xd92e32", 90, 273, 157, 1171, 205)
							nLog("人物红点-x="..hd_x)
							pz_x,pz_y = findMultiColorInRegionFuzzy( 0xda9728, "5|-11|0xde982b,37|-14|0xdd8c20,86|-13|0xeb8121,87|8|0xdf761a", 90, 185, 149, 1172, 218)
							nLog("品质提升-x="..pz_x)
							if hd_x > -1 or pz_x > -1 then
								
								if hd_x > -1 then
									tap_and_sleep(hd_x-50,hd_y+30)
								else
									tap_and_sleep(pz_x-50,pz_y+30)
								end
								
								mSleep(6000);

								x,y = findMultiColorInRegionFuzzy( 0x765d3f, "-1|40|0xa28a58,199|36|0xa98d5b,199|3|0x795f41,53|15|0xe4e2e2,62|15|0xe2e1e1,78|16|0xdedddc", 90, 827, 651, 1063, 739)
								nLog("解锁指挥官-x="..x)
								if x > -1 then
									tap_and_sleep(x,y);
								end
								
								
								if hd_x > -1 then
									if isColor(  978,  477, 0x997844 ) then
										tap_and_sleep(978,  477);--点击一键穿戴
										tap_and_sleep(  533,  734);
										tap_and_sleep(978,  477);--点击一键穿戴
										tap_and_sleep(  533,  734);
										tap_and_sleep(978,  477);--点击一键穿戴
										tap_and_sleep(  533,  734);
										mSleep(1000)
									else
										tap_and_sleep( 1240,   70);--点击关闭
									end	
								end
								
								
								if pz_x > -1 then
									if isColor(  967,  669, 0x91703f ) then
										tap_and_sleep(967,  669);--点击突破
										tap_and_sleep(  533,  734);
										tap_and_sleep(967,  669);--点击突破
										tap_and_sleep(  533,  734);
										tap_and_sleep(967,  669);--点击突破
										tap_and_sleep(  533,  734);
										mSleep(1000)
									else
										tap_and_sleep( 1240,   70);--点击关闭
									end	
								end
								
								
								
							else
								tap_and_sleep(1240,   70);--点击关闭
							end
						else
							tap_and_sleep( 1240,   70);--点击关闭
							break
						end
					end
				end
				mSleep(1000);
				
				
				
				--goto find_red_point;
			end
			]]
			
			
			--is_red_point_clicked = true;
			
		end
	end
	

end